﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Enums;

namespace SabberStoneCoreAi.Competition.Agents
{
	class GreedyTony : AbstractAgent
	{
		public GreedyTony()
		{
			preferedDeck = Decks.MidrangeJadeShaman;
			preferedHero = CardClass.SHAMAN;
		}

		public override void InitializeAgent() { }

		public override void InitializeGame() { }

		public override void FinalizeAgent() { }

		public override void FinalizeGame() { }

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			if (poGame.FirstPlayer == poGame.CurrentPlayer)
			{
				List<PlayerTask> options = poGame.CurrentPlayer.Options();
				Score.Score my_Score = new TonyP1Score();
				my_Score.Controller = poGame.CurrentPlayer;
				PlayerTask best_Task = options[0];
				int best_Score = GetNewP1Score(poGame, my_Score);
				int new_Score = 0;

				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD || task.PlayerTaskType == PlayerTaskType.HERO_POWER)
					{
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGame.Simulate(new List<PlayerTask> { task });
						my_Score.Controller = simulated_Dic[task].CurrentPlayer;
						new_Score = GetNewP1Score(simulated_Dic[task], my_Score);
						if (new_Score > best_Score)
						{
							best_Score = new_Score;
							best_Task = task;
						}
					}
				}
				if (best_Task != null && best_Task != options[0]) return best_Task;

				/*
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
					{
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGame.Simulate(new List<PlayerTask> { task });
						my_Score.Controller = simulated_Dic[task].CurrentPlayer;
						new_Score = GetNewScore(simulated_Dic[task], my_Score);
						if (new_Score > best_Score)
						{
							best_Score = new_Score;
							best_Task = task;
						}
					}
				}
				if (best_Task != null && best_Task != options[0]) return best_Task;
				*/

				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK || task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
					{
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGame.Simulate(new List<PlayerTask> { task });
						my_Score.Controller = simulated_Dic[task].CurrentPlayer;
						new_Score = GetNewP1Score(simulated_Dic[task], my_Score);
						if (new_Score > best_Score)
						{
							best_Score = new_Score;
							best_Task = task;
						}
					}
				}
				if (best_Task != null && best_Task != options[0]) return best_Task;


				if (best_Task == null) best_Task = options[0];
				return best_Task;
			}
			else
			{
				List<PlayerTask> options = poGame.CurrentPlayer.Options();
				Score.Score my_Score = new TonyP2Score();
				my_Score.Controller = poGame.CurrentPlayer;
				PlayerTask best_Task = options[0];
				int best_Score = GetNewP2Score(poGame, my_Score);
				int new_Score = 0;

				int coin_Score = -999999;
				PlayerTask coin_Task = options[0];


				foreach (PlayerTask task in options)
				{
					if (task.HasSource
						&& task.Source.Card.Id == "GAME_005" && poGame.CurrentPlayer.BaseMana > 1)
					{
						POGame.POGame poGameCoin = poGame.Simulate(new List<PlayerTask>() { task })[task];
						List<PlayerTask> optionsCoin = poGameCoin.CurrentPlayer.Options();
						foreach (PlayerTask coinTask in optionsCoin)
						{
							if (coinTask.PlayerTaskType == PlayerTaskType.PLAY_CARD || coinTask.PlayerTaskType == PlayerTaskType.HERO_POWER)
							{
								Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGameCoin.Simulate(new List<PlayerTask> { coinTask });
								my_Score.Controller = simulated_Dic[coinTask].CurrentPlayer;
								new_Score = GetNewP2Score(simulated_Dic[coinTask], my_Score);
								if (new_Score > coin_Score)
								{
									coin_Score = new_Score;
									coin_Task = coinTask;
								}
							}
						}
					}


					if ((task.PlayerTaskType == PlayerTaskType.PLAY_CARD || task.PlayerTaskType == PlayerTaskType.HERO_POWER)
						&& task.HasSource && task.Source.Card.Id != "GAME_005")
					{
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGame.Simulate(new List<PlayerTask> { task });
						my_Score.Controller = simulated_Dic[task].CurrentPlayer;
						new_Score = GetNewP2Score(simulated_Dic[task], my_Score);
						if (new_Score >= best_Score)
						{
							best_Score = new_Score;
							best_Task = task;
						}
					}
				}
				if (coin_Score > best_Score) best_Task = coin_Task;
				if (best_Task != null && best_Task != options[0]) return best_Task;


				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK || task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
					{
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated_Dic = poGame.Simulate(new List<PlayerTask> { task });
						my_Score.Controller = simulated_Dic[task].CurrentPlayer;
						new_Score = GetNewP2Score(simulated_Dic[task], my_Score);
						if (new_Score >= best_Score)
						{
							best_Score = new_Score;
							best_Task = task;
						}
					}
				}
				if (best_Task != null && best_Task != options[0]) return best_Task;


				if (best_Task == null) best_Task = options[0];
				return best_Task;
			}
		}

		public int GetNewP1Score(SabberStoneCoreAi.POGame.POGame poGame, Score.Score myScore)
		{
			int new_Score = myScore.Rate();

			new_Score += poGame.CurrentPlayer.Hero.Armor;                                                                         //Armor
			new_Score -= poGame.CurrentOpponent.Hero.Armor;
			new_Score += poGame.CurrentPlayer.SecretZone.Count * 3;

			if (poGame.CurrentPlayer.Hero.Weapon != null) new_Score += 2 * poGame.CurrentPlayer.Hero.Weapon.AttackDamage * poGame.CurrentPlayer.Hero.Weapon.Durability;
			if (poGame.CurrentOpponent.Hero.Weapon != null) new_Score -= 3 * poGame.CurrentOpponent.Hero.Weapon.AttackDamage * poGame.CurrentOpponent.Hero.Weapon.Durability;

			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.CurrentPlayer.BoardZone)
			{
				if (minion.HasWindfury) new_Score += minion.AttackDamage;
				if (minion.HasDivineShield) new_Score += minion.Health;
				if (minion.HasTaunt) new_Score += 4;
				if (minion.HasInspire) new_Score += 1;
				if (minion.HasCharge) new_Score += 3;
				if (minion.HasStealth) new_Score += 3;
				if (minion.Poisonous) new_Score += 3;
			}

			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.CurrentOpponent.BoardZone)
			{
				if (minion.HasWindfury) new_Score -= (minion.AttackDamage * 2);
				if (minion.HasDivineShield) new_Score -= minion.Health;
				if (minion.HasTaunt) new_Score -= 3;
				if (minion.HasInspire) new_Score -= 1;
				if (minion.HasStealth) new_Score -= 2;
				if (minion.Poisonous) new_Score -= 5;
			}

			return new_Score;
		}

		public int GetNewP2Score(SabberStoneCoreAi.POGame.POGame poGame, Score.Score myScore)
		{
			int new_Score = myScore.Rate();
			new_Score += poGame.CurrentPlayer.SecretZone.Count * 20;

			if (poGame.CurrentPlayer.Hero.Weapon != null) new_Score += 2 * poGame.CurrentPlayer.Hero.Weapon.AttackDamage * poGame.CurrentPlayer.Hero.Weapon.Durability;
			if (poGame.CurrentOpponent.Hero.Weapon != null) new_Score -= 3 * poGame.CurrentOpponent.Hero.Weapon.AttackDamage * poGame.CurrentOpponent.Hero.Weapon.Durability;

			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.CurrentPlayer.BoardZone)
			{
				if (minion.HasWindfury) new_Score += minion.AttackDamage * 3;
				if (minion.HasDivineShield) new_Score += minion.Health * 3;
				if (minion.HasTaunt) new_Score += 5;
				if (minion.HasInspire) new_Score += 1;
				if (minion.HasCharge) new_Score += 5;
				if (minion.HasStealth) new_Score += 3;
				if (minion.Poisonous) new_Score += 7;
			}

			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.CurrentOpponent.BoardZone)
			{
				if (minion.HasWindfury) new_Score -= (minion.AttackDamage * 4);
				if (minion.HasDivineShield) new_Score -= minion.Health * 3;
				if (minion.HasTaunt) new_Score -= 3;
				if (minion.HasInspire) new_Score -= 1;
				if (minion.HasStealth) new_Score -= 2;
				if (minion.Poisonous) new_Score -= 9;
			}

			return new_Score;
		}
	}
}
