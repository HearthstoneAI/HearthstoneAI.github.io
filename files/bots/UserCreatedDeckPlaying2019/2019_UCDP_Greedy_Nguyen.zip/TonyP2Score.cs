﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class TonyP2Score : Score
	{
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return 999999;

			if (HeroHp < 1)
				return -999999;

			int new_Score = 0;

			if (OpHeroHp < 6 && HeroHp > 19 && OpBoardZone.Count - BoardZone.Count < 2)
				new_Score += 100;

			if (OpBoardZone.Count == 0 && BoardZone.Count == 1)
				new_Score += 200;

			if (OpBoardZone.Count == 0 && BoardZone.Count == 2)
				new_Score += 300;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 2)
				new_Score += 400;

			if (OpBoardZone.Count == 1 && BoardZone.Count == 0)
				new_Score -= 200;

			if (OpBoardZone.Count == 2 && BoardZone.Count == 0 && OpHeroHp > 5)
				new_Score -= 300;

			if (OpBoardZone.Count > 2 && BoardZone.Count == 0 && OpHeroHp > 5)
				new_Score -= 400;

			new_Score += (BoardZone.Count - OpBoardZone.Count) * 10;
			new_Score += (HeroHp - OpHeroHp);
			new_Score += (MinionTotHealth - OpMinionTotHealth) * 20;
			new_Score += (MinionTotAtk - OpMinionTotAtk) * 30;


			return new_Score;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
