﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Enums;

namespace SabberStoneCoreAi.Agent
{
	class BotShyti : AbstractAgent
	{
		private Random Rnd = new Random();

		public BotShyti()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			var player = poGame.CurrentPlayer;
			var bestScore = int.MinValue;
			var bestAction = poGame.CurrentPlayer.Options()[0];

			List<PlayerTask> simulatedactions = new List<PlayerTask>();
			simulatedactions.AddRange(poGame.CurrentPlayer.Options());
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> sim = poGame.Simulate(simulatedactions);

			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame>.KeyCollection keyColl = sim.Keys;

			foreach (PlayerTask key in keyColl)
			{
				if (key.PlayerTaskType == PlayerTaskType.END_TURN && sim[key] == null)
					continue;

				SabberStoneCoreAi.POGame.POGame next_state = sim[key];

				
				var score1 = Score(next_state, player.PlayerId);
				if (score1 > bestScore)
				{
					bestScore = score1;
					bestAction = key;
				}

				/*

				List<PlayerTask> simulatedactions_next_state = new List<PlayerTask>();
				simulatedactions_next_state.AddRange(next_state.CurrentPlayer.Options());
				Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> sim_2 = next_state.Simulate(simulatedactions_next_state);


				Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame>.KeyCollection keyColl2 = sim_2.Keys;
				foreach (PlayerTask key2 in keyColl2)
				{
					if (key2.PlayerTaskType == PlayerTaskType.END_TURN && sim_2[key2]==null)
						continue;

					SabberStoneCoreAi.POGame.POGame next_state2 = sim_2[key2];
					var score = Score(next_state2, player.PlayerId);
					if ( score > bestScore)
					{
						bestScore = score;
						bestAction = key;
					}

				}*/
				
			}

			return bestAction;
		}

		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new RampScoreShyti { Controller = p }.Rate();
				case CardClass.MAGE: return new RampScoreShyti { Controller = p }.Rate();
				default: return new RampScoreShyti { Controller = p }.Rate();
			}
		}

		public override void InitializeAgent()
		{
			

			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}
	}
}
