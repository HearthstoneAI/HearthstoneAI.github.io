﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;

using System.Threading;
using System.Threading.Tasks;

namespace SabberStoneCoreAi.Agent
{
	class BotHoffmann : AbstractAgent
	{
		private Random Rnd = new Random();

		public BotHoffmann()
		{
			preferedDeck = Decks.RenoKazakusMage;
			preferedHero = CardClass.MAGE;
		}


		public DynamicScore score { get; set; }

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		private double do_rollout(POGame.POGame start_state, PlayerTask first_action)
		{
			int our_id = start_state.CurrentPlayer.PlayerId;

			POGame.POGame rollout_game = start_state.getCopy();

			// we must not execute END_TURN, otherwise stats are resetted
			int n_actions = 0;
			PlayerTask next_action = first_action;
			while (next_action.PlayerTaskType != PlayerTaskType.END_TURN && rollout_game.CurrentPlayer.PlayerId == our_id && rollout_game.State == State.RUNNING)
			{
				try
				{
					n_actions++;
					rollout_game.Process(next_action);
				}
				catch (Exception)
				{
					return double.NaN;
				}

				List<PlayerTask> options = rollout_game.CurrentPlayer.Options();
				next_action = options[Rnd.Next(options.Count)];
			}

			return Score(rollout_game, our_id);
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			int N_ROLLOUTS = 12;

			int our_id = poGame.CurrentPlayer.PlayerId;

			List<PlayerTask> avail_actions = poGame.CurrentPlayer.Options();
			Dictionary<PlayerTask, double> q_values = new Dictionary<PlayerTask, double>();

			foreach (PlayerTask action in avail_actions)
			{
				double q = 0;

				// check if action is available
				try
				{
					poGame.getCopy().Process(action);
				}
				catch(Exception)
				{
					q_values.Add(action, double.MinValue);
					continue;
				}

				// check if we have END_TURN
				if (action.PlayerTaskType == PlayerTaskType.END_TURN)
				{
					q_values.Add(action, Score(poGame, our_id));
					continue;
				}

				// Do Rollouts
				int valid_trials = 0;
				for (int i = 0; i < N_ROLLOUTS; i++)
				{
					double episode_q = do_rollout(poGame, action);

					if (!double.IsNaN(episode_q))
					{
						q += episode_q;
						valid_trials++;
					}
				}

				if (valid_trials > 0)
					q = q / valid_trials;
				else
					q = Double.MinValue;

				q_values.Add(action, q);
			}

			// Search for max_q
			double max = double.MinValue;
			PlayerTask best_action = null;

			foreach (var item in q_values)
			{
				double q = item.Value;

				// null check is important here, q become double.MinValue in some edge case (even for endturn) 
				if (q > max || best_action == null)
				{
					max = q;
					best_action = item.Key;
				}
			}

			return best_action;
		}

		private double Score(POGame.POGame state, int playerId)
		{
			var controller = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			return score.Rate(controller);
		}

		public override void InitializeAgent()
		{
			

			Rnd = new Random();

			double[] BEST_MAGE_FACTORS = { 2.064, 1.854, -6.517, -0.734, 38.788, -4.881, -29.19, -1.367, 19.661, -0.824, -9.486, -0.657, 68.114, 0.658, -57.868, 2.711, 51.114, 2.585, -37.386, -5.283, -9.513, -1.954, 8.374, 0.602, -16.299, 0.568, 2.821, -0.285, -33.012, 0.355, -4.709, 0.58, 1.044, 0.644, -15.053, 0.761, -55.557, -0.378, 39.834, 1.177, 32.372, 2.448, 29.804, 0.195, -24.616 };
			this.score = new DynamicScore { factors = BEST_MAGE_FACTORS }; ;
		}

		public override void InitializeGame()
		{
		}
	}
}
