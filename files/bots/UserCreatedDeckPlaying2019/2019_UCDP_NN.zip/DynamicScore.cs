﻿using MathNet.Numerics.Distributions;
using SabberStoneCore.Model.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SabberStoneCoreAi.Score
{
	public class DynamicScore : ScoreHoffmann
	{
		public DynamicScore()
		{
			factors = new double[45];
		}

		public override double Rate(Controller contr)
		{
			Controller = contr;

			if (OpHeroHp < 1)
				return int.MaxValue;

			if (HeroHp < 1)
				return -5000;

			double result = 0;

			result += health_factor * HeroHp;
			result += health_factor_p2 * HeroHp * HeroHp;

			result += boardzone_factor * BoardZone.Count;
			result += boardzone_factor_p2 * BoardZone.Count * BoardZone.Count;

			result += tot_hp_factor * MinionTotHealth;
			result += tot_hp_factor_p2 * MinionTotHealth * MinionTotHealth;

			result += tot_taunt_hp_factor * MinionTotHealthTaunt;
			result += tot_taunt_hp_factor_p2 * MinionTotHealthTaunt * MinionTotHealthTaunt;

			result += tot_atk_factor * MinionTotAtk;
			result += tot_atk_factor_p2 * MinionTotAtk * MinionTotAtk;

			result += deckcount_factor * DeckCnt;
			result += deckcount_factor_p2 * DeckCnt * DeckCnt;

			result += handcount_factor * HandCnt;
			result += handcount_factor_p2 * HandCnt * HandCnt;

			///////////////////////////////////////

			result += health_factor_op * OpHeroHp;
			result += health_factor_op_p2 * OpHeroHp * OpHeroHp;

			result += boardzone_factor_op * OpBoardZone.Count;
			result += boardzone_factor_op_p2 * OpBoardZone.Count * OpBoardZone.Count;

			result += tot_hp_factor_op * OpMinionTotHealth;
			result += tot_hp_factor_op_p2 * OpMinionTotHealth * OpMinionTotHealth;

			result += tot_taunt_hp_factor_op * OpMinionTotHealthTaunt;
			result += tot_taunt_hp_factor_op_p2 * OpMinionTotHealthTaunt * OpMinionTotHealthTaunt;

			result += tot_atk_factor_op * OpMinionTotAtk;
			result += tot_atk_factor_op_p2 * OpMinionTotAtk * OpMinionTotAtk;

			result += deckcount_factor_op * OpDeckCnt;
			result += deckcount_factor_op_p2 * OpDeckCnt * OpDeckCnt;

			result += handcount_factor_op * OpHandCnt;
			result += handcount_factor_op_p2 * OpHandCnt * OpHandCnt;

			///////////////////////////////////////

			result += constant_factor;

			///////////////////////////////////////


			result += draw_factor * Controller.NumCardsDrawnThisTurn;
			result += draw_factor_p2 * Controller.NumCardsDrawnThisTurn * Controller.NumCardsDrawnThisTurn;

			result += hero_heal_factor * Controller.AmountHeroHealedThisTurn;
			result += hero_heal_factor_p2 * Controller.AmountHeroHealedThisTurn * Controller.AmountHeroHealedThisTurn;

			result += minion_played_factor * Controller.NumMinionsPlayedThisTurn;
			result += minion_played_factor_p2 * Controller.NumMinionsPlayedThisTurn * Controller.NumMinionsPlayedThisTurn;

			result += spells_played_factor * Controller.NumSpellsPlayedThisGame;
			result += spells_played_factor_p2 * Controller.NumSpellsPlayedThisGame * Controller.NumSpellsPlayedThisGame;

			result += secrets_played_factor * Controller.NumSecretsPlayedThisGame;
			result += secrets_played_factor_p2 * Controller.NumSecretsPlayedThisGame * Controller.NumSecretsPlayedThisGame;

			result += friendly_minion_died_factor * Controller.NumFriendlyMinionsThatAttackedThisTurn;
			result += friendly_minion_died_factor_p2 * Controller.NumFriendlyMinionsThatAttackedThisTurn;

			result += friendly_minion_attacked_factor * Controller.NumFriendlyMinionsThatAttackedThisTurn;
			result += friendly_minion_attacked_factor_p2 * Controller.NumFriendlyMinionsThatAttackedThisTurn * Controller.NumFriendlyMinionsThatAttackedThisTurn;

			result += cards_played_factor * Controller.NumCardsPlayedThisTurn;
			result += cards_played_factor_p2 * Controller.NumCardsPlayedThisTurn * Controller.NumCardsPlayedThisTurn;

			return result;
		}

		public override ScoreHoffmann Clone()
		{
			return new DynamicScore { factors = (double[])factors.Clone(), Controller = Controller };
		}

		public DynamicScore mutate(double ratio, double std, double p2_std)
		{
			Random rnd = new Random();
			Normal normalDis = new Normal(0, std, rnd);
			Normal normalDis_p2 = new Normal(0, p2_std, rnd);

			double[] new_factors = (double[]) factors.Clone();

			// Choose elements to mutate
			var indices = Enumerable.Range(0, factors.Length).OrderBy(x => rnd.Next()).Take((int) Math.Round(factors.Length * ratio));

			foreach (int idx in indices)
			{
				if (idx <= 43 && idx % 2 == 1)
				{
					// factors for x^2 are mutated with a different distribution
					new_factors[idx] = new_factors[idx] + normalDis_p2.Sample();
				}
				else
				{
					new_factors[idx] = new_factors[idx] + normalDis.Sample();
				}
			}

			return new DynamicScore { factors = new_factors, Controller = Controller };
		}

		public DynamicScore singlepoint_crossover(DynamicScore other)
		{
			Random rnd = new Random();

			int crossover_point = rnd.Next(factors.Length);
			double[] new_factors = (double[])factors.Clone();

			for (int i = crossover_point; i < factors.Length; i++)
			{
				new_factors[i] = other.factors[i];
			}

			return new DynamicScore { factors = new_factors, Controller=Controller };
		}

		public override string GetString()
		{
			return "{" + string.Join(", ", factors.Select(x => Math.Round(x, 3).ToString(CultureInfo.InvariantCulture))) + "}";
		}

		public double[] factors { get; set; }

		public double health_factor { get => factors[0]; set => factors[0] = value; }
		public double health_factor_p2 { get => factors[1]; set => factors[1] = value; }
		public double health_factor_op { get => factors[2]; set => factors[2] = value; }
		public double health_factor_op_p2 { get => factors[3]; set => factors[3] = value; }

		public double boardzone_factor { get => factors[4]; set => factors[4] = value; }
		public double boardzone_factor_p2 { get => factors[5]; set => factors[5] = value; }
		public double boardzone_factor_op { get => factors[6]; set => factors[6] = value; }
		public double boardzone_factor_op_p2 { get => factors[7]; set => factors[7] = value; }

		public double tot_hp_factor { get => factors[8]; set => factors[8] = value; }
		public double tot_hp_factor_p2 { get => factors[9]; set => factors[9] = value; }
		public double tot_hp_factor_op { get => factors[10]; set => factors[10] = value; }
		public double tot_hp_factor_op_p2 { get => factors[11]; set => factors[11] = value; }


		public double tot_taunt_hp_factor { get => factors[12]; set => factors[12] = value; }
		public double tot_taunt_hp_factor_p2 { get => factors[13]; set => factors[13] = value; }
		public double tot_taunt_hp_factor_op { get => factors[14]; set => factors[14] = value; }
		public double tot_taunt_hp_factor_op_p2 { get => factors[15]; set => factors[15] = value; }


		public double tot_atk_factor { get => factors[16]; set => factors[16] = value; }
		public double tot_atk_factor_p2 { get => factors[17]; set => factors[17] = value; }
		public double tot_atk_factor_op { get => factors[18]; set => factors[18] = value; }
		public double tot_atk_factor_op_p2 { get => factors[19]; set => factors[19] = value; }


		public double deckcount_factor { get => factors[20]; set => factors[20] = value; }
		public double deckcount_factor_p2 { get => factors[21]; set => factors[21] = value; }
		public double deckcount_factor_op { get => factors[22]; set => factors[22] = value; }
		public double deckcount_factor_op_p2 { get => factors[23]; set => factors[23] = value; }

		public double handcount_factor { get => factors[24]; set => factors[24] = value; }
		public double handcount_factor_p2 { get => factors[25]; set => factors[25] = value; }
		public double handcount_factor_op { get => factors[26]; set => factors[26] = value; }
		public double handcount_factor_op_p2 { get => factors[27]; set => factors[27] = value; }

		//
		public double draw_factor { get => factors[28]; set => factors[28] = value; }
		public double draw_factor_p2 { get => factors[29]; set => factors[29] = value; }

		public double hero_heal_factor { get => factors[30]; set => factors[30] = value; }
		public double hero_heal_factor_p2 { get => factors[31]; set => factors[31] = value; }

		public double minion_played_factor { get => factors[32]; set => factors[32] = value; }
		public double minion_played_factor_p2 { get => factors[33]; set => factors[33] = value; }

		public double spells_played_factor { get => factors[34]; set => factors[34] = value; }
		public double spells_played_factor_p2 { get => factors[35]; set => factors[35] = value; }

		public double secrets_played_factor { get => factors[36]; set => factors[36] = value; }
		public double secrets_played_factor_p2 { get => factors[37]; set => factors[37] = value; }

		public double friendly_minion_died_factor { get => factors[38]; set => factors[38] = value; }
		public double friendly_minion_died_factor_p2 { get => factors[39]; set => factors[39] = value; }

		public double friendly_minion_attacked_factor { get => factors[40]; set => factors[40] = value; }
		public double friendly_minion_attacked_factor_p2 { get => factors[41]; set => factors[41] = value; }

		public double cards_played_factor { get => factors[42]; set => factors[42] = value; }
		public double cards_played_factor_p2 { get => factors[43]; set => factors[43] = value; }

		public double constant_factor { get => factors[44]; set => factors[44] = value; }

		

	}
}
