﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.src.Agent;
using SabberStoneCore.Enums;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Agent
{
	class EvAi : AbstractAgent
	{
		// globals
		private Random Rnd;
		private bool initialized;
		private bool roll_out;
		private StateNode root;
		private StateNode start;
		private StateNode active;
		private int simEpisode;     // Anzahl schon simulierter Episoden
		private List<int> rewards;
		private int num_back;
		private StateNode roll_Node;
		private int level;
		
		/*
		 *	load files once at the start of the simulation	
		 */
		public override void InitializeAgent()
		{
			Rnd = new Random();     // default policy

			// TODO Lade Baum
			root = new StateNode(null, 0, 0, 0, 0, null, null);
			StateNode dummy = new StateNode(null, 0, 0, 0, 0, null, null);
			root = dummy.loadTree();
			if (root == null)
				root = new StateNode(null, 0, 0, 0, 0, null, null);
		}

		/*
		 * Initialize data to start the game
		 */
		public override void InitializeGame()
		{
			initialized = false;    // Startzustand noch nicht gefunden
			simEpisode = 1;
			roll_out = false;
			active = root;
			start = null;
			rewards = new List<int>();
			num_back = 0;
			roll_Node = null;
			level = 1;
		}

		/*
		 * return a non-empty list of moves based on the provided POGame
		 */
		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)		// TODO Returns speichern
		{
			/**
			List<PlayerTask> simulatedactions = new List<PlayerTask>();
			simulatedactions.AddRange(poGame.CurrentPlayer.Options());
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> sim = poGame.Simulate(simulatedactions);

			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame>.KeyCollection keyColl = sim.Keys;

			foreach (PlayerTask key in keyColl)
			{
				//do something with simulated actions
				//in case an EndTurn was simulated you need to set your own cards
				//see POGame.prepareOpponent() for an example
			}

			return poGame.CurrentPlayer.Options()[0];
			**/


			// suche Startzustand
			if (!initialized)
			{
				List<Tuple<int, bool>> myField = new List<Tuple<int, bool>>();
				foreach (Minion elem in poGame.CurrentPlayer.BoardZone)
				{
					int boardCard = elem.AttackDamage;
					myField.Add(new Tuple<int, bool>(boardCard, elem.HasTaunt));
				}
				List<Tuple<int, int>> opField = new List<Tuple<int, int>>();
				foreach (Minion elem in poGame.CurrentOpponent.BoardZone)
				{
					opField.Add(new Tuple<int, int>(elem.Health, elem.AttackDamage));
				}
				StateNode thisStart = new StateNode(root, level, poGame.CurrentPlayer.RemainingMana, poGame.CurrentPlayer.Hero.Armor, poGame.CurrentOpponent.Hero.Health, myField, opField);

				// gibt es Startknoten schon ?
				bool startFound = false;
				foreach (child_Link elem in root.children)
				{
					if (thisStart.isEqual(elem.child))
					{
						active = elem.child;
						start = elem.child;
						startFound = true;
						break;
					}
				}

				// falls es noch keinen gibt, neuen erstellen
				if (!startFound)
				{
					root.children.Add(new child_Link(null, thisStart));
					start = thisStart;
					active = thisStart;
				}

				initialized = true;
			}

			// Wende nur falls nicht im roll-out
			if (!roll_out)
			{
				// Baum durchlaufen mit UCB1
				List<PlayerTask> options = poGame.CurrentPlayer.Options();
				PlayerTask option;
				double[] args = new double[options.Count];
				bool newNode = false;
				for (int i = 0; i < options.Count; i++)
				{
					// Ueberspringe End_Turn, falls noch mehr Optionen
					if(options.Count > 1 && i == 0)
					{
						args[i] = Double.NegativeInfinity;
						continue;
					}

					child_Link curr = active.find_action(options[i]);
					if (curr == null && Rnd.Next(10) <= 6)	// Explore mit bestimmter Wahrscheinlichkeit, wenn es den Knoten noch nicht gibt	
					{
						newNode = true;
						option = options[i];
						// simuliere Option, um Folgezustand zu finden
						List<PlayerTask> optionL = new List<PlayerTask>();
						optionL.Add(option);
						POGame.POGame simulated = poGame.Simulate(optionL).FirstOrDefault().Value;
						// erstelle neuen Node und führe neue Aktion durch
						List<Tuple<int, bool>> myField = new List<Tuple<int, bool>>();
						foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
						{
							int boardCard = elem.AttackDamage;
							myField.Add(new Tuple<int, bool>(boardCard, elem.HasTaunt));
						}
						List<Tuple<int, int>> opField = new List<Tuple<int, int>>();
						foreach (Minion elem in simulated.CurrentOpponent.BoardZone)
						{
							opField.Add(new Tuple<int, int>(elem.Health, elem.AttackDamage));
						}
						StateNode newN = new StateNode(active, level, simulated.CurrentPlayer.RemainingMana, poGame.CurrentPlayer.Hero.Armor, simulated.CurrentOpponent.Hero.Health, myField, opField);

						// falls es denselben Folgezustand schon gibt, aber mit anderer Aktion fuege neuen child link, aber mit demselben Child hinzu
						bool exists = false;
						child_Link newAc;
						foreach (child_Link elem in active.children)
						{
							if (newN.isEqual(elem.child))
							{
								newAc = new child_Link(new src.Agent.Action(option.PlayerTaskType, option.Target == null ? 0 : option.Target.Card.AssetId, option.Source == null ? 0 : option.Source.Card.AssetId), elem.child);
								active.children.Add(newAc);
								active.lastChosen = newAc;
								active = elem.child;
								rewards.Add(active.rate(active.parent, poGame.CurrentPlayer.PlayState));		// reward vergeben
								num_back += 1;
								level += 1;
								exists = true;
								break;
							}
						}
						if (!exists)
						{
							newAc = new child_Link(new src.Agent.Action(option.PlayerTaskType, option.Target == null ? 0 : option.Target.Card.AssetId, option.Source == null ? 0 : option.Source.Card.AssetId), newN);
							active.children.Add(newAc);
							active.lastChosen = newAc;
							active = newN;
							rewards.Add(active.rate(active.parent, poGame.CurrentPlayer.PlayState));
							num_back += 1;
							level += 1;
						}

						roll_out = true;        // MCTS roll-out activated
						roll_Node = active;

						return option;
					}
					else if(curr == null)
					{
						args[i] = Double.NegativeInfinity;
					}
					else
					{
						args[i] = curr.q_sa + Math.Sqrt(Math.Log(curr.child.parent.n_s) / curr.n_sa);
					}
				}
				if (!newNode)   
				{
					double max = args.Max();
					int maxIndex = args.ToList().IndexOf(max);			
					/*
					if (double.IsNegativeInfinity(max) && args.Length > 1)
						maxIndex = Rnd.Next(args.Length - 2) + 1;

					if (maxIndex < 0 || maxIndex > args.Length - 1)
						Console.WriteLine("Ex");
					*/
					option = options[maxIndex];

					// Suche Nachfolgezustand und wechsle dahin
					List<PlayerTask> optionL = new List<PlayerTask>();
					optionL.Add(option);
					POGame.POGame simulated = poGame.Simulate(optionL).FirstOrDefault().Value;

					List<Tuple<int, bool>> myField = new List<Tuple<int, bool>>();
					foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
					{
						int boardCard = elem.AttackDamage;
						myField.Add(new Tuple<int, bool>(boardCard, elem.HasTaunt));
					}
					List<Tuple<int, int>> opField = new List<Tuple<int, int>>();
					foreach (Minion elem in simulated.CurrentOpponent.BoardZone)
					{
						opField.Add(new Tuple<int, int>(elem.Health, elem.AttackDamage));
					}
					StateNode searchN = new StateNode(active, level, simulated.CurrentPlayer.RemainingMana, poGame.CurrentPlayer.Hero.Armor, simulated.CurrentOpponent.Hero.Health, myField, opField);

					// Ueberpruefe, ob Aktion wieder in selben Zustand kommt
					child_Link acNode = active.find_action(option);

					if(acNode != null && acNode.child != null && acNode.child.isEqual(searchN))
					{
						active.lastChosen = acNode;
						active = acNode.child;
						num_back += 1;
						level += 1;
						rewards.Add(active.rate(active.parent, poGame.CurrentPlayer.PlayState));
					}
					else    // falls nicht, schaue, ob Nachfolgezustand schon existiert
					{
						bool exists = false;
						child_Link newAc;
						foreach (child_Link elem in active.children)
						{
							if (searchN.isEqual(elem.child))
							{
								newAc = new child_Link(new src.Agent.Action(option.PlayerTaskType, option.Target == null ? 0 : option.Target.Card.AssetId, option.Source == null ? 0 : option.Source.Card.AssetId), elem.child);
								active.children.Add(newAc);
								active.lastChosen = newAc;
								active = elem.child;
								num_back += 1;
								level += 1;
								rewards.Add(active.rate(active.parent, poGame.CurrentPlayer.PlayState));
								exists = true;
								break;
							}
						}
						if (!exists) // falls kein passender  Folgezustand
						{
							newAc = new child_Link(new src.Agent.Action(option.PlayerTaskType, option.Target == null ? 0 : option.Target.Card.AssetId, option.Source == null ? 0 : option.Source.Card.AssetId), searchN);
							active.children.Add(newAc);
							active.lastChosen = newAc;
							active = searchN;
							num_back += 1;
							level += 1;
							rewards.Add(active.rate(active.parent, poGame.CurrentPlayer.PlayState));

							roll_out = true;
							roll_Node = active;
						}
					}


					// falls kein neuer Node gefunden, gehe weiter im Baum (UCB1)
					return option;
				}
			}

			// Simulation bei neu gefundenem Node
			while (simEpisode < 5)
			{
				SabberStoneCoreAi.POGame.POGame simulated = poGame;
				StateNode previous = active;            // nicht im Baum, nur zum rating
				int dcount = 0;
				while (simulated != null && simulated.State != State.COMPLETE && simulated.State != State.INVALID && simulated.Turn <= 50)
				{

					List<PlayerTask> options = simulated.CurrentPlayer.Options();
					PlayerTask option = _GetMove(simulated);
					//PlayerTask option = options[Rnd.Next(options.Count)];	// default policy
					List<PlayerTask> optionL = new List<PlayerTask>();
					optionL.Add(option);
					simulated = simulated.Simulate(optionL).FirstOrDefault().Value;

					List<Tuple<int, bool>> myField = new List<Tuple<int, bool>>();
					List<Tuple<int, int>> opField = new List<Tuple<int, int>>();
					if (simulated != null)
					{
						foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
						{
							int boardCard = elem.AttackDamage;
							myField.Add(new Tuple<int, bool>(boardCard, elem.HasTaunt));
						}


						foreach (Minion elem in simulated.CurrentOpponent.BoardZone)
						{
							opField.Add(new Tuple<int, int>(elem.Health, elem.AttackDamage));
						}

						StateNode now = new StateNode(null, level, simulated.CurrentPlayer.RemainingMana, poGame.CurrentPlayer.Hero.Armor, simulated.CurrentOpponent.Hero.Health, myField, opField);        // nicht im Baum, nur zum rating

						rewards.Add(now.rate(previous, simulated.CurrentPlayer.PlayState));
						previous = now;
					}
					// active laeuft nicht mit, da Backpropagation nur ab neuen Node aufwaerts
					dcount++;
				}

				FinalizeGame();
				simEpisode++;
			}

			// spiele tatsaechlich weiter, aber random (default policy)
			// active laeuft nicht mit, da Backpropagation nur ab neuen Node aufwaerts
			PlayerTask option_roll = _GetMove(poGame);
			//PlayerTask option_roll = poGame.CurrentPlayer.Options()[Rnd.Next(poGame.CurrentPlayer.Options().Count)];
			List<PlayerTask> optionL_roll = new List<PlayerTask>();
			optionL_roll.Add(option_roll);
			POGame.POGame simulated_roll = poGame.Simulate(optionL_roll).FirstOrDefault().Value;
			// erstelle neuen Node und führe neue Aktion durch
			if (simulated_roll != null)
			{
				List<Tuple<int, bool>> myField_roll = new List<Tuple<int, bool>>();
				foreach (Minion elem in simulated_roll.CurrentPlayer.BoardZone)
				{
					int boardCard = elem.AttackDamage;
					myField_roll.Add(new Tuple<int, bool>(boardCard, elem.HasTaunt));
				}
				List<Tuple<int, int>> opField_roll = new List<Tuple<int, int>>();
				foreach (Minion elem in simulated_roll.CurrentOpponent.BoardZone)
				{
					opField_roll.Add(new Tuple<int, int>(elem.Health, elem.AttackDamage));
				}
				StateNode newN_roll = new StateNode(active, level, simulated_roll.CurrentPlayer.RemainingMana, poGame.CurrentPlayer.Hero.Armor, simulated_roll.CurrentOpponent.Hero.Health, myField_roll, opField_roll);
				rewards.Add(newN_roll.rate(roll_Node, simulated_roll.CurrentPlayer.PlayState));
				roll_Node = newN_roll;
			}
			else
			{
				Console.WriteLine(poGame.CurrentPlayer.Hero.Health);
				Console.WriteLine(option_roll.PlayerTaskType);
			}
			return option_roll;
			
		}

		/*
		 * Funktionen fuer den Greedy-Agenten
		 */
		public PlayerTask _GetMove(POGame.POGame poGame)
		{
			// berechne für alle möglichen Aktionen den reward
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			int[] expectedRs = new int[options.Count];

			for (int i = 0; i < options.Count; i++)
			{
				expectedRs[i] = Evaluate(poGame, options[i]);
			}

			// führe die beste Aktion durch
			int max = expectedRs.Max();
			int maxIndex = expectedRs.ToList().IndexOf(max);
			PlayerTask option = options[maxIndex];

			//Console.Write("    -->  ");
			//Console.WriteLine(option.PlayerTaskType);

			return option;
		}
		public int Evaluate(POGame.POGame game, PlayerTask option)
		{
			int reward = 0;
			List<PlayerTask> optionL = new List<PlayerTask>();
			optionL.Add(option);
			// simuliere eine Aktion
			POGame.POGame simulated = game.Simulate(optionL).GetValueOrDefault(option);

			//Console.Write(option.PlayerTaskType);
			//Console.Write(" x ");

			// bei End-Turn werden CurrentPlayer und CurrentOpponent getauscht
			bool endTurn = true;
			if (simulated != null)
				endTurn = (game.CurrentPlayer.PlayerId == simulated.CurrentOpponent.PlayerId);

			if (!endTurn && simulated != null)
			{
				// Waehle Winner-Zug
				if (simulated.CurrentPlayer.PlayState == PlayState.WON)
					return Int32.MaxValue;

				// Vermeide verlierenden Zug
				if (simulated.CurrentPlayer.PlayState == PlayState.LOST)
					return Int32.MinValue;

				// belohne Verbrauch von Mana (Karten legen + Hero Power)
				reward += (game.CurrentPlayer.RemainingMana - simulated.CurrentPlayer.RemainingMana) * 10;

				// große Belohnung fuer Schaden am gegnerischen Hero
				reward += (game.CurrentOpponent.Hero.Health - simulated.CurrentOpponent.Hero.Health) * 15;

				// belohne Benutzung von Hero-Power (+ 2 Armor)
				reward += (simulated.CurrentPlayer.Hero.Armor - game.CurrentPlayer.Hero.Armor) * 2;

				// groesste Belohnung fuer gespielte Taunts
				int numTaunts = 0;
				numTaunts = simulated.CurrentPlayer.BoardZone.Where(hasTaunt => true).Count() - game.CurrentPlayer.BoardZone.Where(hasTaunt => true).Count();
				numTaunts *= 1000;

				// Belohnung für Minion-Schaden auf eigenen Feld
				foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
				{
					reward += elem.AttackDamage * 10;
				}

				// Belohnung für gemachten Schaden an gegnerischen Minions
				int atk_sum = 0;
				int taunt_dmg = 0;
				foreach (Minion elem in game.CurrentOpponent.BoardZone)
				{
					atk_sum += elem.AttackDamage;
					if (elem.HasTaunt)
						taunt_dmg += elem.Health;
				}
				foreach (Minion elem in simulated.CurrentOpponent.BoardZone)
				{
					atk_sum -= elem.AttackDamage;
					if (elem.HasTaunt)
						taunt_dmg -= elem.Health;
				}
				reward += atk_sum * 10;
				
			}
			else
			{
				reward = -10000;        // waehle End_turn immer erst als letzte Option
			}


			return reward;
		}

		/*
		 * store the result and update the agent after a game
		 */
		public override void FinalizeGame()
		{
			// Backpropagation von active
			active.n_s += 1;

			// Berechne discounted return fuer alle Knoten ueber neuen Node/Terminal State
			StateNode runner = active.parent;
			int update_state = num_back - 1;
			while (!runner.isEqual(root))
			{
				// Update N(s)
				runner.n_s += 1;

				// Update Q(s,a) als Average der Returns
				float discount = 0.75f;
				float discount_factor = 0;
				float newReturn = 0;
				for (int i = update_state; i < rewards.Count; i++)
				{
					newReturn += (float)Math.Pow(discount, discount_factor) * rewards.ElementAt(i);
					discount_factor += 1;
				}
				runner.lastChosen.returns.Add(newReturn);
				runner.lastChosen.q_sa = runner.lastChosen.returns.Average();

				// Update N(s, a)
				runner.lastChosen.n_sa += 1;

				// lastChosen zuruecksetzen
				if(simEpisode > 4)
					runner.lastChosen = null;

				// weiter iterieren
				runner = runner.parent;
				update_state -= 1;
			}

			//von rewards alles bis num_back abschneiden (fuer simulations)
			rewards.RemoveRange(num_back, rewards.Count - num_back);

		}

		/*
		 * store the final model at the end of an simulation
		 */
		public override void FinalizeAgent()
		{
			// Baum speichern
			root.SaveTree();

			StateNode dummy = new StateNode(null,0,0,0,0,null,null);
			StateNode test = dummy.loadTree();

			//Überprüfe, ob Bäume gleich sind
			bool check = _CheckTree(test, root);
			if (check)
				Console.WriteLine("Geladener und gespeicherter Baum sind gleich");
			else
				Console.WriteLine("Fehler: Bäume unterscheiden sich.");
		}
		private bool _CheckTree(StateNode loaded,StateNode normal)
		{
			if (normal.children.Count == 0)
			{
				if (loaded.children.Count == 0)
				{
					return loaded.isEqual(normal);
				}
				else return false;
			}
			else
			{

				bool equal = normal.isEqual(loaded);
				if (normal.children.Count != loaded.children.Count)
					return false;
				for (int i = 0; i < normal.children.Count && equal;i++)
				{
					equal = _CheckTree(loaded.children[i].child,normal.children[i].child);
				}
				return equal;
			}
		}
	}
}
