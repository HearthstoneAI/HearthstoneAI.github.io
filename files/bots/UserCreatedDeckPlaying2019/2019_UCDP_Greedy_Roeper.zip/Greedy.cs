﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;


namespace SabberStoneCoreAi.Competition.Agents
{
	class GreedyBotRoeper : AbstractAgent
	{
		public GreedyBotRoeper()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}

		public override void InitializeAgent()
		{
			// Nothing to do here
		}

		public override void InitializeGame()
		{
			// Nothing to do here
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			// berechne für alle möglichen Aktionen den reward
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			int[] expectedRs = new int[options.Count];

			for(int i = 0; i < options.Count; i++)
			{
				expectedRs[i] = Evaluate(poGame, options[i]);
			}
			
			// führe die beste Aktion durch
			int max = expectedRs.Max();
			int maxIndex = expectedRs.ToList().IndexOf(max);
			PlayerTask option = options[maxIndex];

			//Console.Write("    -->  ");
			//Console.WriteLine(option.PlayerTaskType);

			return option;
		}

		public int Evaluate(POGame.POGame game, PlayerTask option)
		{
			int reward = 0;
			List<PlayerTask> optionL = new List<PlayerTask>();
			optionL.Add(option);
			// simuliere eine Aktion
			POGame.POGame simulated = game.Simulate(optionL).GetValueOrDefault(option);

			//Console.Write(option.PlayerTaskType);
			//Console.Write(" x ");

			// bei End-Turn werden CurrentPlayer und CurrentOpponent getauscht
			bool endTurn = true;
			if(simulated != null)
				endTurn = (game.CurrentPlayer.PlayerId == simulated.CurrentOpponent.PlayerId);

			if (!endTurn && simulated != null)
			{
				// Waehle Winner-Zug
				if (simulated.CurrentPlayer.PlayState == PlayState.WON)
					return Int32.MaxValue;

				// Vermeide verlierenden Zug
				if (simulated.CurrentPlayer.PlayState == PlayState.LOST)
					return Int32.MinValue;

				// belohne Verbrauch von Mana (Karten legen + Hero Power)
				reward += (game.CurrentPlayer.RemainingMana - simulated.CurrentPlayer.RemainingMana) * 10;

				// große Belohnung fuer Schaden am gegnerischen Hero
				reward += (game.CurrentOpponent.Hero.Health - simulated.CurrentOpponent.Hero.Health) * 15;

				// belohne Benutzung von Hero-Power (+ 2 Armor)
				reward += (simulated.CurrentPlayer.Hero.Armor - game.CurrentPlayer.Hero.Armor) * 2;

				// groesste Belohnung fuer gespielte Taunts
				int numTaunts = 0;
				numTaunts = simulated.CurrentPlayer.BoardZone.Where(hasTaunt => true).Count() - game.CurrentPlayer.BoardZone.Where(hasTaunt => true).Count();
				//reward += numTaunts * 1000;

				// Belohnung für Minion-Schaden auf eigenen Feld
				foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
				{
					reward += elem.AttackDamage * 10;
				}

				// Belohnung für gemachten Schaden an gegnerischen Minions
				int atk_sum = 0;
				int taunt_dmg = 0;
				foreach(Minion elem in game.CurrentOpponent.BoardZone)
				{
					atk_sum += elem.AttackDamage;
					if (elem.HasTaunt)
						taunt_dmg += elem.Health;
				}
				foreach(Minion elem in simulated.CurrentOpponent.BoardZone)
				{
					atk_sum -= elem.AttackDamage;
					if (elem.HasTaunt)
						taunt_dmg -= elem.Health;
				}
				reward += atk_sum * 10;
				//reward += taunt_dmg * 20; //verbessert nichts

				
			}
			else
			{
				/**
				if (simulated.CurrentOpponent.PlayState == PlayState.WON)
					return Int32.MaxValue;

				if (simulated.CurrentOpponent.PlayState == PlayState.LOST)
					return Int32.MinValue;

				reward += (game.CurrentPlayer.RemainingMana - simulated.CurrentOpponent.RemainingMana) * 10;

				reward += (game.CurrentOpponent.Hero.Health - simulated.CurrentPlayer.Hero.Health) * 15;

				reward += (simulated.CurrentOpponent.Hero.Armor - game.CurrentPlayer.Hero.Armor) * 2;

				int numTaunts = 0;
				numTaunts = simulated.CurrentOpponent.BoardZone.Where(hasTaunt => true).Count() - game.CurrentPlayer.BoardZone.Where(hasTaunt => true).Count();
				numTaunts *= 1000;

				/*
				foreach (Minion elem in simulated.CurrentOpponent.BoardZone)
				{
					reward += elem.AttackDamage * 10;
				}
				*/
				/**
				int atk_sum = 0;
				foreach (Minion elem in game.CurrentPlayer.BoardZone)
				{
					atk_sum += elem.AttackDamage;
				}
				foreach (Minion elem in simulated.CurrentPlayer.BoardZone)
				{
					atk_sum -= elem.AttackDamage;
				}
				reward += atk_sum * 10;
				**/

				reward = -10000;		// waehle End_turn immer erst als letzte Option
			}


			//Console.Write(endTurn);
			//Console.Write(reward);

			return reward;
		}

		public override void FinalizeAgent()
		{
			// Nothing to do here
		}

		public override void FinalizeGame()
		{
			// Nothing to do here
		}
		
	}
}
