﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*****************************************************
 ******** Klasse zum Aufbauen des Suchbaums **********
 *****************************************************/

// alles public um unendlich viele getter- und setter zu sparen
namespace SabberStoneCoreAi.src.Agent
{
	class Action
	{
		public PlayerTaskType type;
		public int target;
		public int source;

		public Action(PlayerTaskType _type, int _target, int _source)
		{
			type = _type;
			target = _target;
			source = _source;
		}
	}

	class child_Link
	{
		public Action action; // the chosen action
		public float q_sa = 0; // The value of the action Q(s,a)
		public List<float> returns = new List<float>();
		public int n_sa = 0; //The times the action was chosen
		public StateNode child; //Das Kind, auf welches dann verwiesen wird

		public child_Link(Action _action, StateNode _child)
		{
			action = _action;
			child = _child;
		}
	}

	class StateNode
	{
		public StateNode parent;
		public List<child_Link> children; //Die Verweise auf{ die Kinder gepaart mit Q(s,a) und N(s,a)
		public int n_s = 0; // Anzahl, wie oft der Status bereits besucht wurde.

		// gespeicherte Werte zur State-Unterscheidung
		public int turn;
		public int mana;
		public int opHealth;
		public List<Tuple<int, bool>> myField; // <Atk, hasTaunt>
		public List<Tuple<int, int>> opField;	// <Health, Atk>
		public child_Link lastChosen; // zur Backpropagation
		public int myArmor;


		public StateNode(StateNode _parent, int _turn, int _mana, int _myArmor, int _opHealth, List<Tuple<int, bool>> _myField, List<Tuple<int, int>> _opField)
		{
			parent = _parent;
			turn = _turn;
			mana = _mana;
			myArmor = _myArmor;
			opHealth = _opHealth;
			myField = _myField;
			opField = _opField;
			children = new List<child_Link>();
		}

		/*
		 * Ueberpruefe, ob eine Aktion ausgefuehrt wurde
		 */ 
		public child_Link find_action(PlayerTask compAc)
		{
			foreach (child_Link elem in this.children)
			{
				Action checkElem = elem.action;
				
				if (checkElem.source == (compAc.Source == null ? 0 : compAc.Source.Card.AssetId) && checkElem.target == (compAc.Target == null ? 0 : compAc.Target.Card.AssetId) && checkElem.type == compAc.PlayerTaskType)
				{
					return elem;
				}
			}

			return null;
		}

		public bool isEqual(StateNode other)
		{
			// Annahme parent von verglichenen gleich, da man sich sonst im Kreis dreht
			bool sameMyField;
			if(this.myField == null && other.myField == null)
				sameMyField = true;
			else if(this.myField == null || other.myField == null)
				sameMyField = false;
			else
				sameMyField = myField.Count == other.myField.Count && !this.myField.Except(other.myField).Any() && !other.myField.Except(this.myField).Any();

			bool sameOpField;
			if (this.opField == null && other.opField == null)
				sameOpField = true;
			else if (this.opField == null || other.opField == null)
				sameOpField = false;
			else
				sameOpField = opField.Count == other.opField.Count && !this.opField.Except(other.opField).Any() && !other.opField.Except(this.opField).Any(); ;

			return this.turn == other.turn && this.mana == other.mana && this.myArmor == other.myArmor && this.opHealth == other.opHealth && sameMyField && sameOpField;
		}

		public int rate(StateNode parent, PlayState game_end)	//Evaluate(POGame.POGame game, PlayerTask option)
		{
			int reward = 0;

			// Waehle Winner-Zug
			if (game_end == PlayState.WON)
				return Int32.MaxValue;

			// Vermeide verlierenden Zug
			if (game_end == PlayState.LOST)
				return Int32.MinValue;

			// belohne Verbrauch von Mana (Karten legen + Hero Power)
			reward += (parent.mana - this.mana) * 10;

			// große Belohnung fuer Schaden am gegnerischen Hero
			reward += (parent.opHealth - this.opHealth) * 15;

			// belohne Benutzung von Hero-Power (+ 2 Armor)
			reward += (this.myArmor - parent.myArmor) * 2;

			// groesste Belohnung fuer gespielte Taunts
			int numTaunts = 0;
			numTaunts = this.myField.Where(Item2 => true).Count() - parent.myField.Where(Item2 => true).Count();
			numTaunts *= 1000;

			// Belohnung für Minion-Schaden auf eigenen Feld
			foreach (Tuple<int, bool> elem in this.myField)
			{
				reward += elem.Item1 * 10;
			}

			// Belohnung für gemachten Schaden an gegnerischen Minions
			int atk_sum = 0;
			foreach (Tuple<int, int> elem in parent.opField)
			{
				atk_sum += elem.Item2;
			}
			foreach (Tuple<int, int> elem in this.opField)
			{
				atk_sum -= elem.Item2;
			}
			reward += atk_sum * 10;
			

			return reward;
		}
		

		private class EXStateNode
		{
			public StateNode SN;
			public int Kinder;
			public List<EXStateNode> Ex_children = new List<EXStateNode>();
			public EXStateNode(StateNode sn, int k)
			{
				SN = sn;
				Kinder = k;
			}
		}

		public void SaveTree(string filepath = "")
		{
			filepath = @"D:\Git Folders\Hearthstone AI\CompetitionFramework\core-extensions\SabberStoneCoreAi\src\Agent\SubmittedAgents2019\Roeper\";
			int k = 0;
			while (System.IO.File.Exists(filepath + "BackupNodes" + k + ".txt")) k++;
			System.IO.StreamWriter file = new System.IO.StreamWriter(filepath + "BackupNodes" + k + ".txt");

			//Erster Schritt: Traversiere den Baum und gib die Anzahl der Kinder zu jeder Node zurück
			EXStateNode ExRoot = _CountChildren(this);
			//Zweiter Schritt: Traversiere den Baum und Speichere jede Node in einer Zeile ab
			SafeNode(ExRoot, file);
			file.Close();
			Console.WriteLine("Diagramm saved");
		}

		private void SafeNode(EXStateNode Node, System.IO.StreamWriter file)
		{
			string content = "";
			content += Node.SN.turn + ";" + Node.SN.n_s + ";" + Node.SN.mana + ";" + Node.SN.turn + ";" + Node.SN.myArmor + ";"
				+ Node.SN.opHealth + ";";
			if (Node.SN.myField != null)
			{
				content += Node.SN.myField.Count + ";";
				for (int i = 0; i < Node.SN.myField.Count; i++)
					content += Node.SN.myField[i].Item1 + ";" + Node.SN.myField[i].Item2 + ";";
			}
			else content += "0;";
			if (Node.SN.opField != null)
			{
				content += Node.SN.opField.Count + ";";
				for (int i = 0; i < Node.SN.opField.Count; i++)
					content += Node.SN.opField[i].Item1 + ";" + Node.SN.opField[i].Item2 + ";";
			}
			else content += "0;";
			content += Node.SN.children.Count + ";";
			//children
			for (int i = 0; i < Node.SN.children.Count; i++)
			{
				if (Node.SN.children[i].action == null)
					content += " ; ; ;";
				else
				{
					content += Node.SN.children[i].action.type + ";";
					content += Node.SN.children[i].action.source.ToString() + ";";
					content += Node.SN.children[i].action.target.ToString() + ";";
				}
				content += Node.SN.children[i].n_sa + ";";
				content += Node.SN.children[i].q_sa + ";";
			}
			content += Node.Kinder + ";";

			file.WriteLine(content);

			//Die Funktion für die Kinder aufrufen
			for (int i = 0; i < Node.SN.children.Count; i++)
			{
				SafeNode(Node.Ex_children[i], file);
			}
		}

		private EXStateNode _CountChildren(StateNode sn)
		{
			if (sn.children.Count == 0)
				return new EXStateNode(sn, 0);
			else
			{
				EXStateNode returner = new EXStateNode(sn, 0);
				for (int i = 0; i < sn.children.Count; i++)
				{
					EXStateNode local = _CountChildren(sn.children[i].child);
					bool found = false;
					int j = 0;
					for (j = 0; j < returner.Ex_children.Count && !found; j++)
					{
						if (returner.Ex_children[j].SN.isEqual(sn.children[i].child))
							found = true;
					}
					j--;
					if (found)
					{
						returner.Ex_children.Add(returner.Ex_children[j]);
					}
					else
					{
						returner.Ex_children.Add(local);
					}
					returner.Kinder += local.Kinder + 1;
				}
				return returner;
			}
		}

		public StateNode loadTree(string filepath = "")
		{
			filepath = @"D:\Git Folders\Hearthstone AI\CompetitionFramework\core-extensions\SabberStoneCoreAi\src\Agent\SubmittedAgents2019\Roeper\";
			if (System.IO.File.Exists(filepath + "BackupNodes0.txt"))
			{
				int k = 0;
				while (System.IO.File.Exists(filepath + "BackupNodes" + k + ".txt"))
					k++;
				k--;

				System.IO.StreamReader file = new System.IO.StreamReader(filepath + "BackupNodes" + k + ".txt");
				List<string> lines = new List<string>();
				string line;
				while ((line = file.ReadLine()) != null)
				{
					lines.Add(line);
				}

				int anzK;
				StateNode loadedRoot = ReadNode(0, null, out anzK, lines);
				loadedRoot.opField = null;
				loadedRoot.myField = null;
				return loadedRoot;
			}
			else
				return null;
		}

		private StateNode ReadNode(int index, StateNode parent, out int AnzK, List<string> lines)
		{
			StateNode LN = new StateNode(null, 0, 0, 0, 0, null, null);

			//Lese die Line
			string line = lines[index];
			if (line == null)
				throw new Exception("Wrong Index");
			string[] chunks = line.Split(';');
			int cStartIndex = 6;

			//Lesen der Meta-Daten
			LN.turn = Convert.ToInt32(chunks[0]);
			LN.n_s = Convert.ToInt32(chunks[1]);
			LN.mana = Convert.ToInt32(chunks[2]);
			LN.turn = Convert.ToInt32(chunks[3]);
			AnzK = Convert.ToInt32(chunks[chunks.Length - 2]);
			LN.parent = parent;
			LN.myArmor = Convert.ToInt32(chunks[4]);
			LN.opHealth = Convert.ToInt32(chunks[5]);
			//Lesen meines Feldes
			int anzMeinFeld = Convert.ToInt32(chunks[6]);
			LN.myField = new List<Tuple<int,bool>>();
			for (int j = 1; j <= anzMeinFeld*2; j+=2)
				LN.myField.Add(new Tuple<int,bool>(Convert.ToInt32(chunks[cStartIndex + j]),Convert.ToBoolean(chunks[cStartIndex+j+1])));
			cStartIndex += anzMeinFeld*2 + 1;
			//Lesen des gegnerischen Felds
			LN.opField = new List<Tuple<int, int>>();
			int anzGegFeld = Convert.ToInt32(chunks[cStartIndex]);
			for (int j = 1; j < anzGegFeld * 2; j += 2)
				LN.opField.Add(new Tuple<int, int>(Convert.ToInt32(chunks[cStartIndex + j]), Convert.ToInt32(chunks[cStartIndex + j + 1])));
			cStartIndex += anzGegFeld * 2 + 1;
			//Lesen der Kinder
			int count_children = Convert.ToInt32(chunks[cStartIndex]);
			cStartIndex++;
			LN.children = new List<child_Link>();
			int preIndex = 0;
			List<StateNode> alreadyIn = new List<StateNode>();
			for (int i = 1; i <= count_children; i++)
			{
				int cI = index + i + preIndex;
				int AK = 0;
				StateNode CN = ReadNode(cI, LN, out AK, lines);
				preIndex += AK;
				bool found = false;
				int j = 0;
				for (j = 0; j < alreadyIn.Count && !found; j++)
				{
					if (alreadyIn[j].isEqual(CN))
						found = true;
				}
				Action myAct = null;
				if (chunks[(i * 5 - 5 + cStartIndex)] != " ")
					myAct = new Action(GetTaskFromString(chunks[(i * 5 - 5 + cStartIndex)]), Convert.ToInt32(chunks[(i * 5 - 5 + cStartIndex + 1)]), Convert.ToInt32(chunks[(i * 5 - 5 + cStartIndex + 2)]));
				child_Link CL = new child_Link(myAct, null);
				if (found)
				{
					CL = new child_Link(myAct, alreadyIn[j - 1]);
				}
				else
				{
					CL = new child_Link(myAct, CN);
					alreadyIn.Add(CN);
				}
				LN.children.Add(CL);
			}

			return LN;
		}
		private PlayerTaskType GetTaskFromString(string theS)
		{
			PlayerTaskType res = PlayerTaskType.CHOOSE;
			switch (theS)
			{
				case "MINION_ATTACK": res = PlayerTaskType.MINION_ATTACK; break;
				case "PLAY_CARD": res = PlayerTaskType.PLAY_CARD; break;
				case "HERO_ATTACK": res = PlayerTaskType.HERO_ATTACK; break;
				case "END_TURN": res = PlayerTaskType.END_TURN; break;
				case "HERO_POWER": res = PlayerTaskType.HERO_POWER; break;
				case "CHOOSE": res = PlayerTaskType.CHOOSE; break;
				case "CONCEDE": res = PlayerTaskType.CONCEDE; break;
			}
			return res;
		}
	}
}
