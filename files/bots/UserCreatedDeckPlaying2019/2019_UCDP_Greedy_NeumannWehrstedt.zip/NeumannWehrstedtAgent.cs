﻿using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Enums;
using SabberStoneCore.Model;

/*
 * CIG 2019 Programming assigment
 * This agent assigns values to every action depending on the stuation and game state.
 * It sorts the mana based options using the Knapsack algorithm to get the optimal mana usage under the mana limit available to us.
 * 
 * This agent was optimized for the AggroPirate Warrior.
 *
 * Jenny Neumann - 200305
 * Marcel Wehrstedt - 199214
 */

namespace SabberStoneCoreAi.Competition.Agents
{
	class NeumannWehrstedtAgent : AbstractAgent
	{
		/// <summary>
		/// List of available hero powers and their value for player 
		/// </summary>
		private Dictionary<string, double> heroPowersTable;

		public NeumannWehrstedtAgent()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}
		
		
		int PlayerNumber = 0;

		/// <summary>
		/// Effect of 'Patches the Pirate' cannot be used anymore
		/// </summary>
		private bool patchesInvalid = false;

		public override void FinalizeAgent()
		{

		}

		public override void FinalizeGame()
		{

		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			// get available player tasks
			List<PlayerTask> options = poGame.CurrentPlayer.Options();

			// get available attack tasks
			var attackOptions = new Dictionary<PlayerTask, double>();

			// get available mna tasks
			var manaOptions = new Dictionary<PlayerTask, double>();

			// get available hero powers. Used when Sir Finley is played and a new hero power is chosen
			var heroOptions = new List<PlayerTask>();

			// collect mana costs, index should be the same as in manaOptions Dictionary
			var manaOptionsCosts = new List<int>();

			PlayerNumber = poGame.CurrentPlayer == poGame.FirstPlayer ? 1 : 2;

			double taskValue;

			if (!patchesInvalid)
			{
				patchesInvalid = IsPatchesInPlay(poGame.CurrentPlayer.Controller);
			}

			// task for END_TURN
			PlayerTask endTurn = null;

			foreach (PlayerTask task in options)
			{
				switch (task.PlayerTaskType)
				{
					// play a minion, weapon or spell
					case PlayerTaskType.PLAY_CARD:
						switch (task.Source.Card.Type)
						{
							case SabberStoneCore.Enums.CardType.MINION:
								// can be cast to minion, because it is guaranteed to be one
								var minion = (SabberStoneCore.Model.Entities.Minion)Array.Find(task.Controller.HandZone.GetAll(), m => m.Id == task.Source.Id);

								double attackWeight, healthWeight;

								if (poGame.CurrentPlayer == poGame.FirstPlayer)
								{
									attackWeight = 1.5;
									healthWeight = 0.5;
								}
								else
								{
									attackWeight = 0.5;
									healthWeight = 1.5;
								}

								taskValue = (double)(attackWeight * minion.AttackDamage + healthWeight * minion.Health) / Math.Max(minion.Cost, 1);

								// if Patches can still be played, prioritise pirate type minions
								if (!patchesInvalid && minion.Race == SabberStoneCore.Enums.Race.PIRATE)
								{
									taskValue += 2.5;
								}

								manaOptions.Add(task, taskValue);
								manaOptionsCosts.Add(minion.Cost);
								break;
							case SabberStoneCore.Enums.CardType.SPELL:
								// get spell value
								taskValue = GetSpellValue(task, options.FindAll(t => t.PlayerTaskType == PlayerTaskType.MINION_ATTACK || t.PlayerTaskType == PlayerTaskType.HERO_ATTACK));

								if (taskValue > 100)
									return task;
								else if (taskValue > 0)
								{
									manaOptions.Add(task, taskValue);
									manaOptionsCosts.Add(Math.Max(task.Source.Cost, 1));
								}
								break;
							case SabberStoneCore.Enums.CardType.WEAPON:
								var weapon = (SabberStoneCore.Model.Entities.Weapon)Array.Find(task.Controller.HandZone.GetAll(), m => m.Id == task.Source.Id);

								// hero has no weapon equipped, add the option to do so
								if (poGame.CurrentPlayer.Hero.EquippedWeapon == 0)
								{
									taskValue = (double)(weapon.AttackDamage * weapon.Durability) / Math.Max(weapon.Cost, 1);
									manaOptions.Add(task, taskValue);
									manaOptionsCosts.Add(Math.Max(task.Source.Cost, 1));
								}
								else
									taskValue = (double)(weapon.AttackDamage * weapon.Durability - task.Controller.Hero.Damage * task.Controller.Hero.Weapon.Durability) / Math.Max(weapon.Cost, 1);
								break;
						}

						break;
					case PlayerTaskType.HERO_POWER:
						taskValue = GetHeropowerValue(task, options.FindAll(a => a.PlayerTaskType == PlayerTaskType.MINION_ATTACK || a.PlayerTaskType == PlayerTaskType.HERO_ATTACK));
						if (taskValue >= 0)
						{
							manaOptions.Add(task, taskValue);
							manaOptionsCosts.Add(Math.Max(task.Controller.Hero.HeroPower.Cost, 1));
						}
						break;
					case PlayerTaskType.MINION_ATTACK:
						taskValue = GetAttackValue(task);

						if (taskValue > 0)
						{
							attackOptions.Add(task, taskValue);
						}
						break;
					case PlayerTaskType.HERO_ATTACK:
						taskValue = GetAttackValue(task);

						if (taskValue >= 0)
						{
							attackOptions.Add(task, taskValue);
						}
						break;
					case PlayerTaskType.CHOOSE:
						heroOptions.Add(task);
						break;
					case PlayerTaskType.END_TURN:
						endTurn = task;
						break;
					default:
						break;
				}
			}

			// if you can choose a new hero power, get the highest valued one
			if (heroOptions.Count > 0)
				return ChooseBestHeroPower(heroOptions);

			// evaluate values and get best choice
			if (manaOptions.Count > 0)
			{
				// get best possible mana option using the Knapsack algorithm
				KeyValuePair<PlayerTask, double> unbuffed = GetBestManaOptionPair(manaOptions, manaOptionsCosts, poGame.CurrentPlayer.Controller.RemainingMana);

				// if player has the 'Coin', see if it makes a difference with the extra mana it gives
				if (manaOptions.Keys.Any(m => m.ToString().Contains("Coin")))
				{
					KeyValuePair<PlayerTask, double> buffed = GetBestManaOptionPair(manaOptions, manaOptionsCosts, poGame.CurrentPlayer.Controller.RemainingMana + 1);

					if (buffed.Value > unbuffed.Value)
					{
						return buffed.Key;
					}
				}

				return unbuffed.Key;
			}

			if (attackOptions.Count > 0)
				return GetBestAttackOption(attackOptions);
			return endTurn;
		}

		public override void InitializeAgent()
		{
			
			heroPowersTable = new Dictionary<string, double>()
			{
				{ "Steady Shot",	100	},
				{ "Fireblast",		10	},
				{ "Lesser Heal",	-10	},
				{ "Dagger Mastery",	-10 },
				{ "Totemic Call",	0	},
				{ "Life Tap",		5	},
				{ "Reinforce",		15	},
				{ "Shapeshift",		25	}
			};
		}

		public override void InitializeGame()
		{
			patchesInvalid = false;

		}

		/// <summary>
		/// Checks for 'Patches the Pirate' in Hand and Board Zones
		/// </summary>
		/// <param name="controller">Controller whose zones are to be checked</param>
		/// <returns>Found an instance of 'Patches the Pirate' in play</returns>
		public bool IsPatchesInPlay(SabberStoneCore.Model.Entities.Controller controller)
		{
			SabberStoneCore.Model.Entities.IPlayable result = Array.Find(controller.HandZone.GetAll(), h => h.ToString().Contains("Patches"));
			if (result == null)
				result = Array.Find(controller.BoardZone.GetAll(), b => b.ToString().Contains("Patches"));
			if (result == null)
				return false;

			return true;
		}

		/// <summary>
		/// Assigns a value to an attack
		/// </summary>
		/// <param name="task">ATTACK task to assign a value to</param>
		/// <returns>Assigned value</returns>
		public double GetAttackValue(PlayerTask task)
		{
			double taskValue = 0;

			// hero attacks
			switch (task.PlayerTaskType)
			{
				case PlayerTaskType.HERO_ATTACK:
					if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
					{
						var target = (SabberStoneCore.Model.Entities.Minion)GetEntityById(task, task.Target.Id);

						// highest value, no attack value 'wasted' and target is killed
						if (task.Controller.Hero.AttackDamage == target.Health)
							taskValue = 5;
						// if attack anyway is higher than enemy hero health
						else if (task.Controller.Hero.AttackDamage > target.Health)
							taskValue = 4;
						// if not don't bother
						else
							taskValue = 0;
					}
					else
					{
						taskValue = 30 - task.Target.Health;
					}
					break;
				case PlayerTaskType.MINION_ATTACK:
					var attackerEntity = (SabberStoneCore.Model.Entities.Minion)GetEntityById(task, task.Source.Id);

					//check if target card is a minion
					if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
					{
						var target = (SabberStoneCore.Model.Entities.Minion)GetEntityById(task, task.Target.Id);

						double weight;

						if (attackerEntity.AttackDamage == target.Health && attackerEntity.Health > target.AttackDamage)
							weight = 5.0;
						else if (attackerEntity.AttackDamage > target.Health && attackerEntity.Health > target.AttackDamage)
							weight = 2.5;
						else if (attackerEntity.AttackDamage >= target.Health && attackerEntity.Health <= target.AttackDamage)
							weight = 1.5;
						else
							weight = 0;

						taskValue += weight * (double)(target.AttackDamage + target.Health) / (attackerEntity.AttackDamage + attackerEntity.Health);
					}
					else
						taskValue = 2;
					break;

			}

			return taskValue;
		}

		/// <summary>
		/// Gets highest valued ATTACK task
		/// </summary>
		/// <param name="attackOptions">List of ATTACK tasks to get best from</param>
		/// <returns></returns>
		public PlayerTask GetBestAttackOption(Dictionary<PlayerTask, double> attackOptions)
		{
			return attackOptions.OrderBy(v => v.Value).Last().Key;
		}

		/// <summary>
		/// Assigns a value to a spell
		/// </summary>
		/// <param name="task">task to assign value to</param>
		/// <param name="attacks">List of all available options in that turn</param>
		/// <returns></returns>
		public double GetSpellValue(PlayerTask task, List<PlayerTask> attacks)
		{
			// define our resulting value
			double spellValue = 0.01;

			// tokenize card text, sentence wise for performance sake
			string[] sentences = task.Source.Card.Text.ToLower().Split(new char[] { '.' });

			// our damage counter
			int damage = 0;

			foreach (string sentence in sentences)
			{
				string[] tokens = sentence.Split(new char[] { ' ', '-', '\n', '_' });

				// value highly if spell gives you mana; basically used for the coin
				if (sentence.Contains("mana") && sentence.Contains("gain"))
					spellValue = 200;

				// if card benefits you while it is kept in your hand, don't play it
				else if (sentence.Contains("keep") && sentence.Contains("in") && sentence.Contains("hand"))
					return -5;

				// buff spells
				else if (sentence.Contains("give") && sentence.Contains("attack"))
				{
					int boost = -1;

					// parse damage value from text
					foreach (string token in tokens)
					{
						if (token.Contains("+"))
						{
							boost = Int32.Parse(token.Substring(token.IndexOf("$") + 1));
							break;
						}
					}

					// only play this if hero can attack in the same turn, otherwise this spell is wasted
					if (attacks.Find(t => t.PlayerTaskType == PlayerTaskType.HERO_ATTACK) != null && boost > 0)
						spellValue += (double)(boost / Math.Max(1, task.Controller.Hero.AttackDamage));
					else
						spellValue += -5;

				}

				// Shuffle the deck when needed
				else if (sentence.Contains("shuffle"))
					spellValue += 0.5;

				// damage spells
				else if (sentence.Contains("deal"))
				{
					// parse damage value from text
					foreach (string token in tokens)
					{
						if (token.Contains("$"))
						{
							damage = Int32.Parse(token.Substring(token.IndexOf("$") + 1));
							break;
						}
					}

					// if it has a target, check against that. if not, assume attack on everyone
					if (task.HasTarget)
					{
						// don't attack your own creatures
						if (task.Target.Controller == task.Controller)
							spellValue = -5;
						else
						{
							switch (task.Target.Card.Type)
							{
								case SabberStoneCore.Enums.CardType.MINION:
									int targetHealth;
									task.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out targetHealth);

									if (damage > targetHealth)
									{
										//Factor is determined by the damage per mana ratio to justify playing the card and the target selection factor
										spellValue += damage / Math.Max(1, task.Source.Card.Cost) * ((double)targetHealth / damage);
									}
									break;
								case SabberStoneCore.Enums.CardType.HERO:
									spellValue += (double)damage / Math.Max(task.Source.Card.Cost, 1);
									break;
							}
						}
					}
					else
					{
						SabberStoneCore.Model.Entities.Minion[] minions = task.Controller.Opponent.BoardZone.GetAll();
						int killedEnemies = 0;
						int damageSum = 0;

						foreach (SabberStoneCore.Model.Entities.Minion minion in minions)
						{
							if (damage >= minion.Health)
							{
								killedEnemies++;
								damageSum += minion.Health;
							}
							else damageSum += damage;
						}
						if (minions.Length != 0)
							spellValue = killedEnemies + damageSum / Math.Max(task.Source.Card.Cost, 1) * (double)(killedEnemies / minions.Length);
						else
							spellValue += -3;
					}
				}

				// if something can be destroyed, do so
				else if (sentence.Contains("destroy") && task.HasTarget)
				{
					int health, attack;
					task.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out health);
					task.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.ATK, out attack);
					spellValue += (double)task.Target.Card.Cost / task.Source.Card.Cost * (health + attack) / task.Target.Card.Cost;

				}

			}

			return spellValue;
		}

		/// <summary>
		/// Gets highest valued mana consuming task using the Knapsack algorithm for optimal mana usage. 
		/// </summary>
		/// <param name="manaOptions">Available mana tasks</param>
		/// <param name="manaOptionsCost">Costs of available mana tasks</param>
		/// <param name="manaLeft">Amount of mana the player has left</param>
		/// <returns>Highest valued (Task, Value) Pair</returns>
		public KeyValuePair<PlayerTask, double> GetBestManaOptionPair(Dictionary<PlayerTask, double> manaOptions, List<int> manaOptionsCost, int manaLeft)
		{
			double[,] K = new double[manaOptions.Count + 1, manaLeft + 1];
			for (int i = 0; i <= manaOptions.Count; i++)
			{
				for (int j = 0; j <= manaLeft; j++)
				{
					if (i == 0 || j == 0)
					{
						K[i, j] = 0;
					}
					else if (manaOptionsCost[i - 1] <= j && manaOptions.ElementAt(i - 1).Value + K[i - 1, j - manaOptionsCost[i - 1]] > K[i - 1, j])
					{
						K[i, j] = manaOptions.ElementAt(i - 1).Value + K[i - 1, j - manaOptionsCost[i - 1]];
					}
					else
					{
						K[i, j] = K[i - 1, j];
					}
				}
			}

			double highestValue = K[manaOptions.Count, manaLeft];
			int mana = manaLeft;
			for (int i = manaOptions.Count; i > 0 && highestValue > 0 && mana >= 0; i--)
			{
				if (K[i - 1, mana] != highestValue)
				{
					mana = Math.Max(0, mana - manaOptionsCost[i - 1]);
					//highestValue = K[i, mana];
					return manaOptions.ElementAt(i - 1);
				}
			}

			return manaOptions.ElementAt(0);
		}

		/// <summary>
		/// Choose the highest valued hero power
		/// </summary>
		/// <param name="powers">List of hero powers to choose from</param>
		/// <returns>Highest valued hero power</returns>
		public PlayerTask ChooseBestHeroPower(List<PlayerTask> powers)
		{
			var results = new Dictionary<PlayerTask, double>();
			foreach (PlayerTask power in powers)
			{
				foreach (KeyValuePair<string, double> el in heroPowersTable)
				{
					if (power.ToString().Contains(el.Key))
					{
						results.Add(power, el.Value);
						continue;
					}
				}
			}

			return results.OrderBy(h => h.Value).Last().Key;
		}

		/// <summary>
		/// Assigns a value to a hero power
		/// </summary>
		/// <param name="task">Hero power to assign a value to</param>
		/// <returns>Assigned hero power value</returns>
		public double GetHeropowerValue(PlayerTask task, List<PlayerTask> attacks)
		{
			//catch cases where the cost of heropower is not 2, i.e. cards like loatheb or other stuff, base value for cost 2 should be 0, and higher costed less / lower costed higher
			double powerValue = 2 - task.Controller.Hero.HeroPower.Cost;

			// dirty way to get what hero power is evaluated
			string heroPower = task.Controller.Hero.HeroPower.ToString();

			// default hp for warrior. Not that good, so don't use it
			if (heroPower.Contains("Armor Up!"))
				powerValue += -1;

			// fireblast does decent damage
			else if (heroPower.Contains("Fireblast"))
			{
				// target is a hero
				if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.HERO)
				{
					// Do not attack your own hero, that would be bad
					if (task.Controller.Hero == task.Target) powerValue = -1;

					// us as a last resort only
					else powerValue += 1;
				}
				// target is minion
				else
				{
					// ideally, we kill a minion
					if (task.Target.Controller != task.Controller)
					{
						var target = (SabberStoneCore.Model.Entities.Minion)GetEntityById(task, task.Target.Id);

						if (target.Health == 1)
							powerValue += 2 + (double)target.AttackDamage / 10;
						//otherwise the best target would be the target that is lowest, would make future trades better, or just has the highest attack
						else
							powerValue = target.AttackDamage / 10;
					}
					// do not attack your own minions
					else powerValue += -1;
				}
			}

			// lesser heal is a hp we do not want
			else if (heroPower.Contains("Lesser Heal"))
			{
				if (PlayerNumber == 1)
					powerValue = -1;
				else
				{
					//Never heal opponents minion / hero
					if (task.Controller == task.Target.Controller)
					{
						if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
							powerValue += GetHealValue(2, (SabberStoneCore.Model.Entities.Minion)GetEntityById(task, task.Target.Id));
						else if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.HERO)
						{
							//only heal if health is below max increasing the lower it is to a max value of 5
							powerValue += 5 - ((double)task.Target.Controller.Hero.Health / task.Target.Controller.Hero.BaseHealth * 5);
						}
					}
					else
						powerValue = -1;
				}
			}

			else if (heroPower.Contains("Life Tap"))
				powerValue += 0.1;

			else if (heroPower.Contains("Reinforce"))
				powerValue += 1;

			else if (heroPower.Contains("Shapeshift"))
			{
				// 2 relevant cases: need of armor, could trade well, otherwise heropower should only be used if nothing else is possible
				if (task.Controller.Hero.Health < 10)
					powerValue += 1.5;
				else
				{
					if (attacks.Find(a => a.PlayerTaskType == PlayerTaskType.HERO_POWER) != null)
					{
						SabberStoneCore.Model.Entities.Minion[] entities = task.Game.CurrentOpponent.BoardZone.GetAll();
						int targetHealth;
						task.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out targetHealth);

						foreach (SabberStoneCore.Model.Entities.Minion entity in entities)
						{
							if (1 > targetHealth)
							{
								powerValue += 2;
								break;
							}
						}
					}
					else
					{
						powerValue += -1;
					}
				}
			}

			// best one, value higher when more minions on our side
			else if (heroPower.Contains("Steady Shot"))
			{
				int boardStrength = 0;
				int threshold = 5;

				// check if controlled entities are stronger than threshold
				foreach (SabberStoneCore.Model.Entities.Minion min in task.Controller.BoardZone.GetAll())
				{
					boardStrength += min.AttackDamage;
				}

				if (boardStrength >= threshold)
					powerValue += 3.5;
				else
					powerValue += 1;
			}

			// summons either a 1/1 or 0/2 totem. not bad, but not that good either
			else if (heroPower.Contains("Totemic Call"))
				powerValue += 1;

			return powerValue;
		}

		public double GetHealValue(int healing, SabberStoneCore.Model.Entities.Minion target)
		{
			double value = 0;
			//only has value if the target is actually damaged

			if (target.Health < target.BaseHealth)
			{
				// value then depends on the amount it is possibly healed and minions closer to death would be prefered to get healed
				// Base Value -	Factor for how heavy the target is damaged		-	Utility factor of the heal, highest value is reached if the total amount of healing can be achieved
				value = 2 * 1 - (double)(target.Health - 1 / target.BaseHealth) * Math.Min((double)(target.BaseHealth - target.Health) / healing, 1);
			}
			return value;
		}

		/// <summary>
		/// Gets an entity on the board
		/// </summary>
		/// <param name="p">Task to get Boards from</param>
		/// <param name="id">Entity ID</param>
		/// <returns>Entity with given id</returns>
		public SabberStoneCore.Model.Entities.IEntity GetEntityById(PlayerTask p, int id)
		{
			// check enemy board for entity id and return that specific instance
			SabberStoneCore.Model.Entities.IEntity result = null;

			// look for minions on opponent board
			result = Array.Find(p.Target.Controller.BoardZone.GetAll(), m => m.Id == id);

			// if nothing is found, check your own board instead
			if (result == null)
				result = Array.Find(p.Controller.BoardZone.GetAll(), m => m.Id == id);

			return result;

		}

	}
}
