﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Enums;

namespace SabberStoneCoreAi.Competition.Agents
{
	static class cState 
	{
		static POGame.POGame state;

		public static POGame.POGame getState()
		{
			return state;
		}

		public static void setState(POGame.POGame game){
			state = game;
		}
	}
	class BotOstendorfSchroeder : AbstractAgent
	{
		public BotOstendorfSchroeder()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}
		

		public override void InitializeAgent() 
		{
			
		}

		public override void InitializeGame() {}

		public override void FinalizeAgent() {}

		public override void FinalizeGame() {}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame game)
		{	
			var player    = game.CurrentPlayer;

			cState.setState(game);

			// Get all simulation results for simulations that didn't fail
			var validOpts = game.Simulate( player.Options() ).Where( x => x.Value != null );

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy( x => Score(x.Value, player.PlayerId ) ).Last().Key :
				player.Options().First( x => x.PlayerTaskType == PlayerTaskType.END_TURN );
		}


		private static int Score( POGame.POGame state, int playerId )
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
 
			switch ( state.CurrentPlayer.HeroClass )
			{
				case CardClass.WARRIOR: return new ScoreWarrior { Controller = p }.Rate();
				case CardClass.MAGE: 	return new ScoreMage { Controller = p }.Rate();
				case CardClass.SHAMAN:  return new ScoreShaman { Controller = p }.Rate();
				default: 				return new ScoreMage { Controller = p }.Rate();
			}
			
		}
		
	}
}
