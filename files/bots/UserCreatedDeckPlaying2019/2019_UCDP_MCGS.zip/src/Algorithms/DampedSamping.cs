﻿namespace SabberStoneCoreAi.MCGS
{
	public partial class NodeConfig
	{
		public const bool DampedSampling = true;
		//public bool DoNotReduceEndTurnSamples = false;
		public double DampingParameter = 2;
	}
}
