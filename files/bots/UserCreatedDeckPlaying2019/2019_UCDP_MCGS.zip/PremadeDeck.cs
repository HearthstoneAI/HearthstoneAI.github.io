﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Model;

namespace SabberStoneCoreAi.Meta
{
	public static class PremadeDeck
	{
		public static readonly List<Card> OddPaladin = new List<Card>
		{
			Cards.FromName("Acherus Veteran"),
			Cards.FromName("Acherus Veteran"),
			Cards.FromName("Argent Squire"),
			Cards.FromName("Argent Squire"),
			Cards.FromName("Blessing of Might"),
			Cards.FromName("Blessing of Might"),
			Cards.FromName("Fire Fly"),
			Cards.FromName("Fire Fly"),
			Cards.FromName("Lost in the Jungle"),
			Cards.FromName("Lost in the Jungle"),
			Cards.FromName("Righteous Protector"),
			Cards.FromName("Righteous Protector"),
			Cards.FromName("Divine Favor"),
			Cards.FromName("Divine Favor"),
			Cards.FromName("Raid Leader"),
			Cards.FromName("Raid Leader"),
			Cards.FromName("Stonehill Defender"),
			Cards.FromName("Stonehill Defender"),
			Cards.FromName("Unidentified Maul"),
			Cards.FromName("Unidentified Maul"),
			Cards.FromName("Fungalmancer"),
			Cards.FromName("Fungalmancer"),
			Cards.FromName("Leeroy Jenkins"),
			Cards.FromName("Level Up!"),
			Cards.FromName("Level Up!"),
			Cards.FromName("Corridor Creeper"),
			Cards.FromName("Corridor Creeper"),
			Cards.FromName("Stormwind Champion"),
			Cards.FromName("Vinecleaver"),
			Cards.FromName("Vinecleaver"),
			Cards.FromName("Baku the Mooneater"),
		};
	}
}
