﻿using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Enums;
using SabberStoneCore.Model;

namespace SabberStoneCoreAi.Competition.Agents
{
	class LuKamila : AbstractAgent
	{
		public LuKamila()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}
		

		public override void FinalizeAgent()
		{
		}
		public override void FinalizeGame()
		{
		}
		public override void InitializeGame()
		{
		}
		public override void InitializeAgent()
		{
			
		}
		
		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			// get all possible options for this turn
			List<PlayerTask> options = poGame.CurrentPlayer.Options();

			// save values of all options
			Dictionary<PlayerTask, long> optionValueDictionary = new Dictionary<PlayerTask, long>();

			// simulate all possible options and get simulated board states
			Dictionary<PlayerTask, POGame.POGame> simulatedOptions = poGame.Simulate(options);

			// go through all simulated options
			foreach (KeyValuePair<PlayerTask, POGame.POGame> simulatedOption in simulatedOptions)
			{
				// calculate value of current option by using a reward function which evaluates the simulated state of the game, given the current option is selected
				long optionValue = GetOptionValue(simulatedOption);

				// add option and calculated value to dictionary
				optionValueDictionary.Add(simulatedOption.Key, optionValue);
			}

			// select option with the highest value from dictionary
			PlayerTask bestOption = optionValueDictionary.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;

			// best option is returned
			return bestOption;
		}

		private long GetOptionValue(KeyValuePair<PlayerTask, POGame.POGame> simulatedOption)
		{
			// get simulated game state
			var gameState = simulatedOption.Value;
			// get option
			var option = simulatedOption.Key;

			// if there is no simulated game state because the game has already ended for example
			// or the option would be to end the turn (because in this case the board zones are not evaluated correctly)
			if (gameState == null || option.PlayerTaskType == PlayerTaskType.END_TURN)
			{
				// return the lowest possible value
				return long.MinValue;
			}

			// if the opponent would be eliminated
			if (gameState.CurrentOpponent.Hero.Health <= 0)
			{
				// return highest value possible
				return long.MaxValue;
			}

			// initialize option value
			long optionValue = 0;


			#region weights

			// initialize value of 1 player hero hit point
			long playerHealthWeight = 1;

			// initialize value of 1 opponent hero hit point
			long opponentHealthWeight = -1;

			// initialize value per player minion the board
			long playerMinionCountWeight = 3;

			// initialize value per player minion the board
			long opponentMinionCountWeight = -5;

			// initialize value per attack point of a friendly minion on the board
			long playerMinionAttackWeight = 2;

			// initialize value per health point of a friendly minion on the board
			long playerMinionHealthWeight = 1;

			// initialize value per friendly minion attributes on the board
			long playerMinionBattlecryWeight = 1;
			long playerMinionChargeWeight = 1;
			long playerMinionDeathrattleWeight = 1;
			long playerMinionDivineShieldWeight = 1;
			long playerMinionInspireWeight = 1;
			long playerMinionLifeStealWeight = 1;
			long playerMinionStealthWeight = 1;
			long playerMinionTauntWeight = 1;
			long playerMinionWindfuryWeight = 1;

			// initialize value per attack point of an opponent minion on the board
			long opponentMinionAttackWeight = -2;

			// initialize value per health point of an opponent minion on the board
			long opponentMinionHealthWeight = -5;

			// initialize value per attack power on player weapon
			long playerHeroAttackDamageWeight = 2;

			// initialize value per durability point on player weapon
			long playerWeaponDurabilityWeight = 4;

			#endregion


			// evaluate player health
			optionValue += gameState.CurrentPlayer.Hero.Health * playerHealthWeight;

			// evaluate opponent health
			optionValue += gameState.CurrentOpponent.Hero.Health * opponentHealthWeight;

			// evaluate player minions on the board
			optionValue += gameState.CurrentPlayer.BoardZone.Count * playerMinionCountWeight;

			// evaluate player minions on the board
			optionValue += gameState.CurrentOpponent.BoardZone.Count * opponentMinionCountWeight;

			// get list of friendly minions
			var playerMinions = gameState.CurrentPlayer.BoardZone.ToList();

			// go through all friendly minions
			foreach (Minion minion in playerMinions)
			{
				// evaluate player minions attack power
				optionValue += minion.AttackDamage * playerMinionAttackWeight;

				// evaluate player minions health
				optionValue += minion.Health * playerMinionHealthWeight;

				// evaluate special minion attributes
				if (minion.HasBattleCry) { optionValue += playerMinionBattlecryWeight; }
				if (minion.HasCharge) { optionValue += playerMinionChargeWeight; }
				if (minion.HasDeathrattle) { optionValue += playerMinionDeathrattleWeight; }
				if (minion.HasDivineShield) { optionValue += playerMinionDivineShieldWeight; }
				if (minion.HasInspire) { optionValue += playerMinionInspireWeight; }
				if (minion.HasLifeSteal) { optionValue += playerMinionLifeStealWeight; }
				if (minion.HasStealth) { optionValue += playerMinionStealthWeight; }
				if (minion.HasTaunt) { optionValue += playerMinionTauntWeight; }
				if (minion.HasWindfury) { optionValue += playerMinionWindfuryWeight; }
			}

			// get list of opponent minions
			var opponentMinions = gameState.CurrentOpponent.BoardZone.ToList();

			// go through all friendly minions
			foreach (Minion minion in opponentMinions)
			{
				// evaluate opponent minions attack power
				optionValue += minion.AttackDamage * opponentMinionAttackWeight;

				// evaluate opponent minions health
				optionValue += minion.Health * opponentMinionHealthWeight;
			}

			// if player has a weapon equipped
			if (gameState.CurrentPlayer.Hero.Weapon != null)
			{
				// evaluate weapon attack damage
				optionValue += gameState.CurrentPlayer.Hero.Weapon.AttackDamage * playerHeroAttackDamageWeight;

				// evaluate weapom durability
				optionValue += gameState.CurrentPlayer.Hero.Weapon.Durability * playerWeaponDurabilityWeight;
			}

			// return option value
			return optionValue;
		}
	}
}
