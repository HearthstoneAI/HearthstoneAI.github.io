﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Nodes;
using SabberStoneCoreAi.Score;
using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Model;
using System.Linq;
using System.Collections.Generic;

namespace SabberStoneCoreAi.src.Agent.TreeDataStructure
{
	class Tree
	{
		//Each Tree must have a root Node, which is similar to an entry point to the tree data structure!
		public Node root = null;


		//At the start of our turn we get every optional move possible
		public List<PlayerTask> allOptions;


		//Each Tree has a List of Nodes, this means the root Node already has a List of children Nodes, that can be initialized
		public List<PlayerTask> usedTasks = new List<PlayerTask>();



		//The parameters are necessary values for the initilization of the root Node 
		public Tree(POGame.POGame treeGame)
		{
			//This node is only initialized once, when a new Tree data structure is created
			//The root node consists of the actual game instance of our actual turn and the PlayerTask,
			//which is necessary for a node object, is set to null, because there does not exist a PlayerTask
			//at this moment.
			root = new Node(null,treeGame);
			//node <- rootNode

			Controller control = treeGame.CurrentPlayer;
			allOptions = control.Options();

			/*
			foreach(PlayerTask pl in allOptions)
			{
				Console.WriteLine(pl.Source);
			}*/


			Dictionary<PlayerTask, POGame.POGame> rootSimulation = treeGame.Simulate(allOptions);

			//Checking the size of the Dictionary (simulated PlayerTasks)
			//The first Element in the Dictionary is always the END_TURN PlayerTask
			//When the Dicitonary has the size 2 the second PlayerTask,
			//which is not an END_TURN PlayerTask is used
		
				Console.WriteLine("ROOTSIMULATION");
				foreach (KeyValuePair<PlayerTask, POGame.POGame> en in rootSimulation)
				{

					Console.WriteLine(en.Key);
				}

				//The resulting can have a max depth of allOptions.length and the width of Level 1 is the length of each entry in the rootSimulation Dictionary

				//First we insert the first layer of nodes			
				foreach (KeyValuePair<PlayerTask, POGame.POGame> entry in rootSimulation)
				{
					Console.WriteLine(entry.Value.CurrentPlayer.PlayerId);
					
						//WE NEED TO FILTER THE OPPONENT MOVES
						Console.WriteLine("LAYER 1 SIMULATION");
						Node temp = null;
						temp = new Node(entry.Key, entry.Value);
						temp.Parent = root;
						temp.result = AgentJadeDruid.CurrentGameState(entry.Key, entry.Value);
						temp.nodeOptions = entry.Value.CurrentPlayer.Options();
						temp.optionSimulation = entry.Value.Simulate(temp.nodeOptions);
						root.children.Add(temp);

						foreach (KeyValuePair<PlayerTask, POGame.POGame> tr in temp.optionSimulation)
						{
							Console.WriteLine(tr.Key);
						}
					
				}
				List<List<PlayerTask>> moves = new List<List<PlayerTask>>();
				List<List<Node>> nodes = new List<List<Node>>();
				int counter = 0;


				Console.WriteLine(root.children.Count);






				//Now we insert all remaining nodes
				//We need to keep track of the tree width and depth to determine the end of the algorithm (inserting nodes)
				foreach (Node child in root.children)
				{
					Node save = child;
					//Console.WriteLine(save.calculated_Move);
					List<PlayerTask> taskTemp = new List<PlayerTask>();
					List<Node> nodeTemp = new List<Node>();
					//save.nodeOptions.Count > 1

					while (counter < 5)
					{
						//moves[counter].Add(save.calculated_Move);
						//nodes[counter].Add(save);
						taskTemp.Add(save.calculated_Move);
						nodeTemp.Add(save);
						//Console.WriteLine(save.calculated_Move.FullPrint());
						//Simulating all new instances of games
						int endTurnCounter = 0;
						
						foreach (KeyValuePair<PlayerTask, POGame.POGame> entry in save.optionSimulation)
						{
							
								Node temp = null;

								temp = new Node(entry.Key, entry.Value);
								temp.Parent = save;
								temp.result = AgentJadeDruid.CurrentGameState(entry.Key, entry.Value);
								temp.nodeOptions = entry.Value.CurrentPlayer.Options();
								temp.optionSimulation = entry.Value.Simulate(temp.nodeOptions);
								//Console.WriteLine("USED MOVE IN NODE");
								//Console.WriteLine(temp.calculated_Move);
								save.children.Add(temp);
							
						}
						//List<Node> simulated_Moves = save.children;
						if ((save.children.Count != endTurnCounter) && (save.children.Count > 0))
						{
							Node NodeTemp = save.children[0];
							save = NodeTemp;
							//Selecting the Node with the biggest Value (CurrentGameState) from the simulated games
							foreach (Node n in save.children)
							{
								if (n.result > save.result)
								{
									save = n;
								}

							}

						}
						counter++;
						//Console.WriteLine(counter);
						/*foreach(PlayerTask p in taskTemp)
						{
							Console.WriteLine(p);
						}*/

					}

					moves.Add(taskTemp);
					nodes.Add(nodeTemp);
				//usedTasks = moves[Calculate_PlayerTasks(nodes)];
				Console.WriteLine("USED PLAYER ID...........");
				Calculate_PlayerTasks(nodes, moves);
				//Console.WriteLine(usedTasks[0].Game.CurrentPlayer.PlayerId);

			}
				//Currently two erros : - INDEX ; -NOT AN OBJECT REFERENCE

			
			
		
				

			//Console.WriteLine(usedTasks.Count);
		}//end Constructor of Tree


		//Now we implement different methods used in a tree data structure
		//First we need a Method to add or "insert" a Node into the tree.
		//The Dictionary consists of KeyValuePairs (Key => PlayerTask ; Value => POGame)
		public void InsertNode(KeyValuePair<PlayerTask, POGame.POGame> gameState)
		{

			/* The Return type is currently void but this must be changed to Node because the inserted Note can
			 * than be used add this Node to the List of children of the root Node */


			//We use a single KeyValuePair instead of the whole dictionary to get the POGame (actual game)
			//This game instance is then used to initialize the next Node
			//We also use the PlayerTask as a parameter for the constructor of the Node object "temp"
			var temp = new Node(gameState.Key,gameState.Value);
			temp.result = AgentJadeDruid.CurrentGameState(gameState.Key, gameState.Value);

			/*
			 * Zuweisung Eltern Kind Knoten , weitere Simulationen werden dann als Kind Knoten gespeichtert !
			 * 6.6.19 */


			Node current;
			Node parent;

			
		



		}

		//We use a method for determining the greatest value of the different simulations of options give
		//This method returns the index of the List with the highest calculated CurrentGameState

			//CURRENT ERROR CAUSED BY FALSE INDEXES
			//12.6.19

		public int GetPlayerTasks(List<List<Node>> pl)
		{
			int greatest_value = 0;
			int index = 0;
			foreach (List<Node> pNode in pl)
			{
				//pNode.Reverse();

					if (pNode.Count > 0)
					{
						int temp = pNode.Count - 1;

						while ((pNode[temp].calculated_Move.PlayerTaskType == PlayerTaskType.END_TURN) && (temp > 0))
						{
							temp--;
						}
						if ((pNode[temp].result > greatest_value) && (pNode[temp].calculated_Move.PlayerTaskType != PlayerTaskType.END_TURN))
						{
							greatest_value = pNode[temp].result;
							index = pl.IndexOf(pNode);

						}
					}
				
				//Console.WriteLine(greatest_value);
			}
			if (greatest_value == 0) return 0;

			Console.WriteLine("INDEX");
			Console.WriteLine(index);
			return index;
			
		}

		//NEED NEW METHOD FOR LIST OF PLAYERTASKS !!!
		//WE NEED TO KEEP TRACK OF THE USED PLAYERID
		public int Calculate_PlayerTasks(List<List<Node>> pl, List<List<PlayerTask>> move)
		{
			//Storing all max values in a List
			List<int> max_values = new List<int>();


			//PRINTING ALL ELEMENTS THAT ARE STORED
			Console.WriteLine("RECEIVED LIST: -----------");
			foreach(List<PlayerTask> p in move)
			{
				foreach(PlayerTask pt in p)
				{
					Console.WriteLine(pt);
				}
			}


			foreach(List<Node> pList in pl)
			{
				//Calculating the highest Game Value , to access this specific List
				if (pList.Count > 0)
				{
					if (pList[0].used_instance.CurrentPlayer.PlayerId == AgentJadeDruid.PlayID)
					{
						var max = pList.Max(r => r.result);
						//var itemsWithMax = pList.Where(r => r.result == max);
						max_values.Add(max);
					}
				}
			}
			//DEBUGGING ........
			Console.WriteLine("CALCULATED INDEX: ");
			Console.WriteLine(max_values.IndexOf(max_values.Max()));
			Console.WriteLine("SIZE OF LISTS: ----------------------------------------");
			Console.WriteLine(pl.Count + " " + move.Count);
			if (move.Count > max_values.IndexOf(max_values.Max())) Console.WriteLine("CAN BE USED!!------");
			return max_values.IndexOf(max_values.Max());

		}



	}
}
