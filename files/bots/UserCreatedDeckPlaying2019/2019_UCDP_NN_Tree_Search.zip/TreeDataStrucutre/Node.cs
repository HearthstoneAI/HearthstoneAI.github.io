﻿using SabberStoneCore.Tasks.PlayerTasks;
using System;
using System.Collections.Generic;
using System.Text;

namespace SabberStoneCoreAi.src.Agent.TreeDataStructure
{



	class Node
	{
		//First we use a variable to store the information about the Node ID
		public int NodeID;


		//We also simply use a static attribute to map a different ID to each Node
		public static int NodeIDCounter = 0;


		//Listing all necessary attributes, which need to be stored inside the tree data structure
		public List<Node> siblings;


		//each Node has a parent Node, multiple children and multiple siblings; 
		public Node Parent { get; set; }


		public List<Node> children;


		//When the Node does not have any children its called "Leaf"
		public bool isLeaf;


		//Only one Root Node exists per Tree!
		public bool isRoot;


		//Each Node also needs to have our value from the method CurrentGameState to calcute the value on how the game state is currently in
		public int result;


		//Each node consists of a List with new Options derived from the parent node
		public List<PlayerTask> nodeOptions;


		public PlayerTask calculated_Move;


		public POGame.POGame used_instance;


		public Dictionary<PlayerTask, POGame.POGame> optionSimulation;
	


		//We implement a Constructor for initializing the different attributes.
		/*public Node()
		{
			NodeID = NodeIDCounter;
			NodeIDCounter++;
			siblings = new List<Node>();
			Parent = null;
			children = new List<Node>();
			isLeaf = false;
			isRoot = false;
			result = 0;
		}*/
		public Node(PlayerTask usedMove, POGame.POGame instance)  {
			NodeID = NodeIDCounter;
			NodeIDCounter++;
			siblings = null;
			Parent = null;
			children = new List<Node>();
			isLeaf = false;
			isRoot = false;
			result = AgentJadeDruid.CurrentGameState(usedMove, instance);
			calculated_Move = usedMove;
			used_instance = instance;
		}





	}
}
