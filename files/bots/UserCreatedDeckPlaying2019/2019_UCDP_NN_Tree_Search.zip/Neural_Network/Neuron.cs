﻿using System;
using System.Collections.Generic;
using System.Text;

//author: @Leon Geis, @Dariusz Saflik
//23.05.19

namespace SabberStoneCoreAi.src.Agent.Neural_Network
{
	class Neuron
	{

		//A list of Dendrite, which are connected to the Neuron
		public List<Dendrite> Dendrites { get; set; }
		//The output Pulse the Neuron gives to other Neurons (or the output itself?!);
		public Pulse OutputPulse { get; set; }
		//weight is used to store the sum of all coming pulses of the dendrites.
		private double Weight;
		
		//The standard constructor of the class Neuron:
		public Neuron()
		{
			Dendrites = new List<Dendrite>();
			OutputPulse = new Pulse();
		}

		//The most important function of the Neuron the "Fire" function:
		public void Fire()
		{
			OutputPulse.Value = Sum();
			OutputPulse.Value = Activation(OutputPulse.Value);
		}
		//Computing the weight of each dendrite ("the weight of each connection");
		public void Compute(double learningRate, double delta)
		{
			Weight += learningRate * delta;
			foreach (Dendrite d in Dendrites)
			{
				d.SynapticWeight = Weight;
			}
		}

		private double Sum()
		{
			//removing the implicit typecast from double -> float x = 0.0f
			//    float x = 0 has an implicit typecast from int to float.
			//    float x = 0.0f does not have such a typecast.
			//    float x = 0.0 has an implicit typecast from double to float.
			double computeValue = 0.0f;
			foreach (Dendrite d in Dendrites)
			{
				computeValue += d.InputPulse.Value * d.SynapticWeight;
			}
			return computeValue;
		}

		//Function Activation "activates" the neuron to fire a signal after a certain sum of inputs
		private double Activation(double input)
		{
			double threshold = 1;
			//When the input is bigger or equal the threshold return 0, else return the treshold
			//e.g, the Sigmoid function can be used here!
			return input >= threshold ? 0 : threshold;
		}



	}
}
