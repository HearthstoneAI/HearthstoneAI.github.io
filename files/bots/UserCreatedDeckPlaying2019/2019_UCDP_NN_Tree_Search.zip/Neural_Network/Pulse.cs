﻿using System;
using System.Collections.Generic;
using System.Text;

//author: @Leon Geis, @Dariusz Saflik
//23.5.19

namespace SabberStoneCoreAi.src.Agent.Neural_Network
{
	class Pulse
	{
		public double Value { get; set; }

	}
}
