﻿using System;
using System.Collections.Generic;
using System.Text;

//author: @Leon Geis, @Dariusz Saflik
//23.05.09

namespace SabberStoneCoreAi.src.Agent.Neural_Network
{
	class Neural_Layer
	{

		//The neurons here are given in a List(could also be other data structures!)
		public List<Neuron> Neurons { get; set; }
		//The name of this certain Layer of Neurons
		public string Name { get; set; }
		//The overall weight of the Layer
		public double Weight { get; set; }

		//Constructor with the given number of neurons in this layer,
		//the initial Weight and the name you want to give this Layer
		public Neural_Layer(int count, double initialWeight, string new_name)
		{
			Neurons = new List<Neuron>();
			for (int i = 0; i < count; i++)
			{
				Neurons.Add(new Neuron());
			}
			Weight = initialWeight;
			Name = new_name;
		}

		//The method Compute is similar to the method in the class Neuron
		//see Neuron.cs for further information
		public void Compute(double learningRate, double delta)
		{
			foreach (Neuron n in Neurons)
			{
				n.Compute(learningRate, delta);
			}
		}

		//Adding a possible but not necessary method to give a console output
		//for the single layer of neurons
		public void Log()
		{
			Console.WriteLine($"{Name}, Weight: {Weight}");
		}
		//Forwarding all signal of the neurons, by letting them "fire"
		public void Forward()
		{
			foreach (Neuron n in Neurons)
			{
				n.Fire();
			}
		}


	}
}
