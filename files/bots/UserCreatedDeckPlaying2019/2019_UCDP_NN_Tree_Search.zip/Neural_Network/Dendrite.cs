﻿using System;
using System.Collections.Generic;
using System.Text;

//author: @LeonGeis, @Dariusz Saflik
//23.5.19

namespace SabberStoneCoreAi.src.Agent.Neural_Network
{
	class Dendrite
	{
		//Input Signal
		public Pulse InputPulse { get; set; }
		//The connection strength between the dendrite and synapsis of two neurons
		public double SynapticWeight { get; set; }
		//Used for adjusting the synapticWeight during training
		public bool Learnable { get; set; } = true;
	}
}
