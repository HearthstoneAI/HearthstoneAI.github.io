﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

//author: @Leon Geis, @Dariusz Saflik
//23.05.19

namespace SabberStoneCoreAi.src.Agent.Neural_Network
{
	class NetworkModel
	{

		//The List of the (several) layers of neurons
		public List<Neural_Layer> Layers { get; set; }
		//The constructor of the NetworkModel class:
		public NetworkModel()
		{
			Layers = new List<Neural_Layer>();
		}

		//A method for adding additional layers of neurons
		public void AddLayer(Neural_Layer new_layer)
		{

			int dendrite_count = 1;
			//If the list isn't empty, then the amount of dendrites equals
			//the amount of neurons the last layer
			if (Layers.Count > 0)
			{
				dendrite_count = Layers.Last().Neurons.Count;
			}
			//Going through the neurons of the new layer and adding the necessary amount of
			//dendrites(connections) to the new layer.
			//This is important to guarantee connections between the last- and new layer!
			//Skipping this step would meant a new layer in the NetworkModel, but without any connection.
			foreach (Neuron n in new_layer.Neurons)
			{
				for (int i = 0; i < dendrite_count; i++)
				{
					n.Dendrites.Add(new Dendrite());
				}
			}
		}

		//Build() is used to build up the given network model
		public void Build()
		{
			int i = 0;
			foreach (Neural_Layer layer in Layers)
			{
				if (i >= Layers.Count - 1)
				{
					break;
				}
				Neural_Layer nextLayer = Layers[i + 1];
				CreateNetwork(layer, nextLayer);
				i++;
			}
		}

		//CreateNetwork creates a network of the different layer through connecting
		//each layer through dendrites, which are the different connections!
		private void CreateNetwork(Neural_Layer connectingFrom, Neural_Layer connectingTo)
		{
			foreach (Neuron to in connectingTo.Neurons)
			{
				foreach (Neuron from in connectingFrom.Neurons)
				{
					to.Dendrites.Add(new Dendrite() { InputPulse = to.OutputPulse, SynapticWeight = connectingTo.Weight });
				}
			}
		}

		//This method conatins the used training algorithm,
		//at this time the implementation example from the given URL is used;
		//https://medium.com/coinmonks/implement-a-simple-neural-network-in-c-net-part-2-9fa92ef454a8
		/*public void Train()
		{
			//Links for further training algorithms:
			//https://medium.com/@ODSC/5-essential-neural-network-algorithms-9336093fdf56
			//https://page.mi.fu-berlin.de/rojas/neural/chapter/K8.pdf
			//https://ml4a.github.io/ml4a/how_neural_networks_are_trained/
			//Levenberg-Marquardt, BFGS Quasi-Newton, Resilient Backpropagation
			//Levenberg-Marquardt is yet known to be the fastest training algorithm for neural nets

		}*/
		//For simplicity the implementation example from the given URL is used;
		//https://medium.com/coinmonks/implement-a-simple-neural-network-in-c-net-part-2-9fa92ef454a8
		//THIS WILL BE CHANGED!
		public void Train(NeuralData X, NeuralData Y, int iterations, double learningRate = 0.1)
		{
			int epoch = 1;
			//Loop till the number of iterations
			while (iterations >= epoch)
		  {
			//Get the input layers
			var inputLayer = Layers[0];
			List<double> outputs = new List<double>();

			//Loop through the record
			for (int i = 0; i < X.Data.Length; i++)
			{
			  //Set the input data into the first layer
			  for (int j = 0; j < X.Data[i].Length; j++)
			  {
				inputLayer.Neurons[j].OutputPulse.Value = X.Data[i][j];
			  }

			  //Fire all the neurons and collect the output
			  ComputeOutput();
			  outputs.Add(Layers.Last().Neurons.First().OutputPulse.Value);
			}

			//Check the accuracy score against Y with the actual output
			double accuracySum = 0;
			int y_counter = 0;
			outputs.ForEach((x) =>
			{
			  if (x == Y.Data[y_counter].First())
			  {
				accuracySum++;
			  }

			  y_counter++;
			});

			//Optimize the synaptic weights
			Optimize(accuracySum / y_counter);
			Console.WriteLine("Epoch: {0}, Accuracy: {1} %", epoch, (accuracySum / y_counter) * 100);
			epoch++;
		  }
		}

		//Print() just prints the names of each layers and their weights to the console
		public void Print()
		{
			Console.WriteLine("Name\tNeurons\tWeight");
			foreach (Neural_Layer layer in Layers)
			{
				Console.WriteLine($"{layer.Name}\t{layer.Neurons.Count}\t{layer.Weight}");
			}
		}

		//Computing the Output of the Network and triggering all the forwarding
		//method of all layers (the first layer is the input and has to be skipped)
		private void ComputeOutput()
		{
			//Skip the input layer!
			foreach (Neural_Layer l in Layers.Skip(1))
			{
				l.Forward();
			}
		}

		//Optimize is used to optimize the weights of the neural net
		private void Optimize(double accuracy)
		{
			//Initializing a float variable used for the learning rate of the neural net
			//it is initialized with 0.1, but if the given accuracy is above 100% it will
			//be changed to -0.1;
			float lr = 0.1f;
			//The case that the accuracy has reached 100%:
			if (accuracy == 1) return;
			//If the accuracy is above 100% , substract the the value to reach again the 100%
			if (accuracy > 1) lr = -0.1f;

			//Updating the weights of all layers using the learning rate and the parameter
			//delta for this case stays at 1 to disable further changes in the adjustment of
			//the individual weights
			//This can be changed later!
			foreach(Neural_Layer l in Layers)
			{
				l.Compute(lr, 1);
			}

		}

		
		//An additional main method for testing purposes only!
		/*public static void Main(string[] args)
		{
			//Creating a new NetworkModel and adding different layers
			NetworkModel model = new NetworkModel();
			model.Layers.Add(new Neural_Layer(2, 0.1, "INPUT"));
			model.Layers.Add(new Neural_Layer(3, 0.1, "HIDDEN"));
			model.Layers.Add(new Neural_Layer(1, 0.1, "OUTPUT"));
			//Building (connecting) the different layers with each other
			model.Build();
			//Printing the necessary data of the NetworkModel through the Print() method
			model.Print();
		}*/

	}
}
