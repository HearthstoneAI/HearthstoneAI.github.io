﻿   using System;
using System.Collections.Generic;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.src.Agent.Neural_Network;
using SabberStoneCore.Model.Zones;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.src.Agent.TreeDataStructure;
using SabberStoneCore.Enums;
using SabberStoneCore.Config;

namespace SabberStoneCoreAi.src.Agent
{
	class AgentJadeDruid : AbstractAgent
	{
		private Random Rnd = new Random();

		public static List<Card> UserDeck = JadeDruidDeck.JadeDruid;
		public List<Card> GetUserDeck() { return UserDeck; }

		public static List<PlayerTask> TasksToExecute =new List<PlayerTask>();

		public static int PlayID;
		//Using a Neural Network to improve our function, which calculates a numerical value
		//based on how the agent is currently using his tasks.

		//Used parameters (used for mutliplication)
		//currently 11 parameters (or input values) are used.
		//Idea: we need also 11 output parameters (updated values)

			//Same Game instance
			//Using our values;
			//Propagating through the ANN
			//Using output as Input again
		
		public static int myHealth;
		public static int opHealth;
		public static int myCards;
		public static int opCards;
		public static int myDeck;
		public static int opDeck;
		public static int myMinions;
		public static int opMinions;
		public static int myBoardCleared;
		public static int opBoardCleared;
		public static int win;
		public static int lose;

		//Later, neuralNet is initialized through a return parameter,
		//that returns the trained neural net
		public static NetworkModel neuralNet = new NetworkModel();
		
		public AgentJadeDruid() {
			preferedDeck = JadeDruidDeck.JadeDruid;
			preferedHero = CardClass.DRUID;
		}

		
		public List<PlayerTask> CalculateNextMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			/*List<PlayerTask> playerMoves = poGame.CurrentPlayer.Options();
			var gameStates = poGame.Simulate(playerMoves);
			int current_game_value = CurrentGameState(poGame);*/
			//Console.WriteLine(CurrentGameState(poGame));
			Tree t = new Tree(poGame);
			return t.usedTasks;
		}

		//We need an Upper Confidence Bound for the Actions that are currently available to the player.
		//See https://arxiv.org/abs/1808.04794v1 for more information
		//5.6.19
		public PlayerTask UpperConfidenceBound(Dictionary<PlayerTask, POGame.POGame> tasks)
		{
			PlayerTask upper_bound = null;

			return null;
		}

		public static int CurrentGameState(PlayerTask endturn, POGame.POGame pOGame)
		{
			//Initializing an object of type Score to get access to the different scores
			//the game state is actually in
			/*
			 * Score.Score score = null;
			 * The Score is not needed anymore for this purpose
			 * */
			int myhealth = 2*(int)Math.Sqrt(pOGame.CurrentPlayer.Hero.Health);
			int ophealth = 2 * (int)Math.Sqrt(pOGame.CurrentOpponent.Hero.Health);
			//When its the first turn the cards chosen get a higher value than all other cards
			int cards=0;
			int enemy_cards = 0;
			if (pOGame.Turn == 1)
			{
				cards = 3*pOGame.CurrentPlayer.HandZone.Count;
				enemy_cards = 3 * pOGame.CurrentOpponent.HandZone.Count;
			}
			else
			{
				//Each card will add the number 2 to the current cards integer.
				//Because it is not the first turn the cards are less high valued than the first cards drawn!
				for(int i = 0; i < pOGame.CurrentPlayer.HandZone.Count; i++)
				{
					cards += 2;
				}
				//The enemy cards have to be weighted too.
				for (int i = 0; i < pOGame.CurrentOpponent.HandZone.Count; i++)
				{
					enemy_cards += 2;
				}
			}
			//The deck itself is an additional input necessary for the overall judgement of the game
			int deck = 0;
			int opdeck = 0;
			if (pOGame.CurrentPlayer.DeckZone.Count == 0)
			{
				deck = (int)Math.Sqrt(pOGame.CurrentPlayer.DeckZone.Count) - (int)Math.Sqrt(pOGame.Turn);
			}
			else
			{
				deck = (int)Math.Sqrt(pOGame.CurrentPlayer.DeckZone.Count);
			}
			if (pOGame.CurrentOpponent.DeckZone.Count == 0)
			{
				opdeck = (int)Math.Sqrt(pOGame.CurrentOpponent.DeckZone.Count) - (int)Math.Sqrt(pOGame.Turn);
			}
			else
			{
				opdeck = (int)Math.Sqrt(pOGame.CurrentOpponent.DeckZone.Count);
			}


			//All minions currently located on our side of the board need to be summarized into a single value.
			//This needs to be done to give the agent a current field of view of his minions and their overall value.
			//For additional information see: https://www.wowhead.com/news=253870/the-value-of-a-hearthstone-card
			int minion = 0;
			int opminion = 0;
			//Getting all of the minions on the side of the agent itself
			Minion[] current_minions = pOGame.CurrentPlayer.BoardZone.GetAll();
			Minion[] op_minions = pOGame.CurrentOpponent.BoardZone.GetAll();
			//First generating a value based on our cards currently on the board
			foreach(Minion m in current_minions)
			{
				minion += (m.AttackDamage + m.Health);
				//Now the abilities of each card are also added to the given minion value,
				//which consists until now only of the health and damage of the card.
				//But there is a lot more, that makes a card usefull not only the already used attributes.
				//Instead of subtracting different attributes of the given card to estimate
				//a budget, we simply add this value to increase the given value for our
				//special purpose. We do not care simply about the budget but especially for the current state
				//the card is in.
				//The higher the cards mana cost is in addition with their abilities we assume, that their value is higher. (Scaling of mana points with health and attack)

				//For the cases in which the value of different attributes is unclear we simply made an assumption based on the values assigned to the other combinations.
				//Some attributes can be ignored, because we use a rogue deck in which we e.g. do not have any windfury cards.

				if (m.HasCharge && (m.Cost == 1)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.HasCharge && (m.Cost == 2)) minion += ((m.Cost + 2) * 2) + 1;
				else if (m.HasCharge && (m.Cost <=5) && (m.Cost >= 3)) minion += ((m.Cost + 3) * 2) + 1;
				else if (m.HasCharge && (m.Cost == 6)) minion += ((m.Cost + 4) * 2) + 1;
				else if (m.HasCharge && (m.Cost > 6)) minion += ((m.Cost + 5) * 2) + 1;

				if (m.HasDivineShield && (m.Cost == 1)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.HasDivineShield && (m.Cost == 2)) minion += ((m.Cost + 2) * 2) + 1;
				else if (m.HasDivineShield && (m.Cost > 2)) minion += ((m.Cost + 3) * 2) + 1;

				if ((m.HasStealth && (m.Cost == 1))||(m.HasStealth && (m.Cost==2))) minion += ((m.Cost) * 2) + 1;
				else if (m.HasDivineShield && (m.Cost >= 3) && (m.Cost <= 6)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.HasDivineShield && (m.Cost > 6)) minion += ((m.Cost + 2) * 2) + 1;

				if (m.HasTaunt && (m.Cost >= 1) && (m.Cost <= 7)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.HasTaunt && (m.Cost > 7)) minion += ((m.Cost + 2) * 2) + 1;

				//Combo and Battlecry cards have the same values as card with charge, because their behaviour is very similar.

				if (m.Combo && (m.Cost == 1)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.Combo && (m.Cost == 2)) minion += ((m.Cost + 2) * 2) + 1;
				else if (m.Combo && (m.Cost <= 5) && (m.Cost >= 3)) minion += ((m.Cost + 3) * 2) + 1;
				else if (m.Combo && (m.Cost == 6)) minion += ((m.Cost + 4) * 2) + 1;
				else if (m.Combo && (m.Cost > 6)) minion += ((m.Cost + 5) * 2) + 1;

				if (m.HasBattleCry && (m.Cost == 1)) minion += ((m.Cost + 1) * 2) + 1;
				else if (m.HasBattleCry && (m.Cost == 2)) minion += ((m.Cost + 2) * 2) + 1;
				else if (m.HasBattleCry && (m.Cost <= 5) && (m.Cost >= 3)) minion += ((m.Cost + 3) * 2) + 1;
				else if (m.HasBattleCry && (m.Cost == 6)) minion += ((m.Cost + 2) * 2) + 1;
				else if (m.HasBattleCry && (m.Cost > 6)) minion += ((m.Cost + 4) * 2) + 1;

				//Because we currently have the card "Hench-Clan Thug" in our deck, we need to give this this minion also a value.
				//This card does not have any of the effects above, but has a special effect, which will have a slightly higher value than the other attributes.
				Card hench_clan = Cards.FromName("Hench-Clan Thug");
				if(m.Equals(hench_clan)) minion += ((m.Cost + 4) * 2) + 1;

			}
			//Now we need to generate a value based on the cards from the opponent
			foreach (Minion opm in op_minions)
			{
				opminion += (opm.AttackDamage + opm.Health);
				//Now the abilities of each card are also added to the given minion value,
				//which consists until now only of the health and damage of the card.
				//But there is a lot more, that makes a card usefull not only the already used attributes.
				//Instead of subtracting different attributes of the given card to estimate
				//a budget, we simply add this value to increase the given value for our
				//special purpose. We do not care simply about the budget but especially for the current state
				//the card is in.
				//The higher the cards mana cost is in addition with their abilities we assume, that their value is higher. (Scaling of mana points with health and attack)

				//For the cases in which the value of different attributes is unclear we simply made an assumption based on the values assigned to the other combinations.

				if (opm.HasCharge && (opm.Cost == 1)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.HasCharge && (opm.Cost == 2)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.HasCharge && (opm.Cost <= 5) && (opm.Cost >= 3)) opminion += ((opm.Cost + 3) * 2) + 1;
				else if (opm.HasCharge && (opm.Cost == 6)) opminion += ((opm.Cost + 4) * 2) + 1;
				else if (opm.HasCharge && (opm.Cost > 6)) opminion += ((opm.Cost + 5) * 2) + 1;

				if (opm.HasDivineShield && (opm.Cost == 1)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.HasDivineShield && (opm.Cost == 2)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.HasDivineShield && (opm.Cost > 2)) opminion += ((opm.Cost + 3) * 2) + 1;

				if ((opm.HasStealth && (opm.Cost == 1)) || (opm.HasStealth && (opm.Cost == 2))) opminion += ((opm.Cost) * 2) + 1;
				else if (opm.HasDivineShield && (opm.Cost >= 3) && (opm.Cost <= 6)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.HasDivineShield && (opm.Cost > 6)) opminion += ((opm.Cost + 2) * 2) + 1;

				if (opm.HasTaunt && (opm.Cost >= 1) && (opm.Cost <= 7)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.HasTaunt && (opm.Cost > 7)) opminion += ((opm.Cost + 2) * 2) + 1;

				//Combo and Battlecry cards have the same values as card with charge, because their behaviour is very similar.

				if (opm.Combo && (opm.Cost == 1)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.Combo && (opm.Cost == 2)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.Combo && (opm.Cost <= 5) && (opm.Cost >= 3)) opminion += ((opm.Cost + 3) * 2) + 1;
				else if (opm.Combo && (opm.Cost == 6)) opminion += ((opm.Cost + 4) * 2) + 1;
				else if (opm.Combo && (opm.Cost > 6)) opminion += ((opm.Cost + 5) * 2) + 1;

				if (opm.HasBattleCry && (opm.Cost == 1)) opminion += ((opm.Cost + 1) * 2) + 1;
				else if (opm.HasBattleCry && (opm.Cost == 2)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.HasBattleCry && (opm.Cost <= 5) && (opm.Cost >= 3)) opminion += ((opm.Cost + 3) * 2) + 1;
				else if (opm.HasBattleCry && (opm.Cost == 6)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.HasBattleCry && (opm.Cost > 6)) opminion += ((opm.Cost + 4) * 2) + 1;

				//Because the opponent can have additional attributes, which the decks in our deck do not have we have to implement those cases aswell.
				//First Windfury can be an attribute that the cards of the opponnents board.
				if (opm.HasWindfury && (opm.Cost >= 1) && (opm.Cost <= 2)) opminion += ((opm.Cost +1)*2)+1;
				else if (opm.HasWindfury && (opm.Cost >= 3) && (opm.Cost <= 5)) opminion += ((opm.Cost + 2) * 2) + 1;
				else if (opm.HasWindfury && (opm.Cost == 6)) opminion += ((opm.Cost + 4) * 2) + 1;
				else if (opm.HasWindfury && (opm.Cost > 6)) opminion += ((opm.Cost + 5) * 2) + 1;

				//Now we simply make an assumption for the other attributes, because they are not as important as the rest of the given attributes.
				if (!opm.HasCharge && !opm.HasDivineShield && !opm.HasStealth && !opm.HasTaunt && !opm.Combo && !opm.HasBattleCry && !opm.HasWindfury) opminion += ((opm.Cost + 2) * 2) + 1;

			}

			int op_board_cleared = 0;
			int my_board_cleared = 0;
			if (pOGame.CurrentOpponent.BoardZone.IsEmpty && (pOGame.Turn <= 10) )op_board_cleared += 2 + (pOGame.Turn);
			//Setting a maximum limit for the variable to be added to the board_cleared variable
			//This maximum is alo used for the calculation of the enemy board 
			else if(pOGame.CurrentOpponent.BoardZone.IsEmpty && (pOGame.Turn > 10)) op_board_cleared += 2 + 10;

			if (pOGame.CurrentPlayer.BoardZone.IsEmpty && (pOGame.Turn <= 10)) my_board_cleared += 2 + (pOGame.Turn);
			else if (pOGame.CurrentPlayer.BoardZone.IsEmpty && (pOGame.Turn > 10)) my_board_cleared += 2 + 10;


			//If the game is won this win variable gets the biggest amount possible to represent using simple integers
			int win = 0;
			if (pOGame.CurrentOpponent.Hero.Health <= 0) win = 5000;

			//If the game is lost this lost variable gets the smallest amount possible to represent using simple integers
			int lost = 0;
			if (pOGame.CurrentPlayer.Hero.Health <= 0) lost = -5000;

			//Now comes the key part of this function, which is calculating a general value based on the current game state.
			//This simply means this value represents how good or bad the game is in its current state for our agent.
			//We add all differences and of course the win and lost variables.
			int overall = (myhealth-ophealth)+(cards-enemy_cards)+(deck-opdeck)+(minion-opminion)+(op_board_cleared-my_board_cleared)+win+lost;
			if (endturn.PlayerTaskType == PlayerTaskType.END_TURN) { overall = int.MinValue; return overall; }


			return overall;
		}

		private static void Quick_Sort(int[] arr, int left, int right)
		{
			if (left < right)
			{
				int pivot = Partition(arr, left, right);

				if (pivot > 1)
				{
					Quick_Sort(arr, left, pivot - 1);
				}
				if (pivot + 1 < right)
				{
					Quick_Sort(arr, pivot + 1, right);
				}
			}

		}

		private static int Partition(int[] arr, int left, int right)
		{
			int pivot = arr[left];
			while (true)
			{

				while (arr[left] < pivot)
				{
					left++;
				}

				while (arr[right] > pivot)
				{
					right--;
				}

				if (left < right)
				{
					if (arr[left] == arr[right]) return right;

					int temp = arr[left];
					arr[left] = arr[right];
					arr[right] = temp;


				}
				else
				{
					return right;
				}
			}
		}




		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			//We implement and train the neural net below here;
			//var input = new Neural_Layer(11,0.5,"INPUT");
			//var hiddenLayer1 = new Neural_Layer(5,0.5,"HIDDEN1");
			//var hiddenLayer2 = new Neural_Layer(3, 0.5, "HIDDEN2");
			//var output = new Neural_Layer(11,0.5,"OUTPUT");

			//neuralNet.Layers.Add(input);
			//neuralNet.Layers.Add(hiddenLayer1);
			//neuralNet.Layers.Add(hiddenLayer2);
			//neuralNet.Layers.Add(output);

			//neuralNet.Build();

			//Console.WriteLine("OUTPUT OF ANN-------------------------------------");

			//neuralNet.Print();




			PlayID = poGame.CurrentPlayer.PlayerId;
			//Console.WriteLine("PLAYERID");
			//Console.WriteLine(PlayID);


			//TasksToExecute = CalculateNextMove(poGame);
			/*Console.WriteLine("TASK TO EXECUTE");
			foreach(PlayerTask pl in TasksToExecute)
			{
				Console.WriteLine(pl.ToString());
			}*/

			/*int counter = 0;
			if (TasksToExecute.Count == 1)
			{
				temp = TasksToExecute[0];
			}else if ((TasksToExecute[counter].PlayerTaskType == PlayerTaskType.END_TURN)&&(TasksToExecute.Count>1))
			{
				counter++;
				temp = TasksToExecute[counter];
			}
			Console.WriteLine("---------------------------------------------------------");
			Console.WriteLine(temp);
			*/


			//Console.WriteLine(TasksToExecute[counter].PlayerTaskType);
			//Console.WriteLine(temp.ToString());
			//return temp;
			PlayerTask temp = null;
			int state = 0;
			int compare = 0;

			List<PlayerTask> options = poGame.CurrentPlayer.Options();

			PlayerTask nextTask = null;

			List<int> simulatedStates = new List<int>();

			Dictionary<PlayerTask, POGame.POGame> firstSimulation = poGame.Simulate(options);

			foreach (KeyValuePair<PlayerTask, POGame.POGame> ausgabe in firstSimulation)
			{
				//Console.WriteLine(ausgabe.Key);
				state = CurrentGameState(ausgabe.Key, ausgabe.Value);
				//Console.WriteLine("Spielstand nach simuliertem Zug: " + state);
				simulatedStates.Add(state);
			}
			//simulatedStates[0] = -200;
			/*foreach(PlayerTask task in options)
			{
				Console.WriteLine(task);
				state = CurrentGameState(poGame);
				Console.WriteLine("Aktueller Spielstand: " + state);
			}*/

			int[] sort = new int[simulatedStates.Count];
			for (int i = 0; i < sort.Length; i++)
			{
				sort[i] = simulatedStates[i];
			}
			Quick_Sort(sort, 0, (sort.Length - 1));

			foreach(KeyValuePair<PlayerTask, POGame.POGame> ausgabe in firstSimulation)
			{
				compare = CurrentGameState(ausgabe.Key,ausgabe.Value);
				if(compare == sort[sort.Length - 1])
				{
					nextTask = ausgabe.Key;
				}
			}
			




			state = CurrentGameState(nextTask, poGame);
			//temp = options[Rnd.Next(options.Count)];
			//Console.WriteLine("");
			//Console.WriteLine("----------------------------");
			//Console.WriteLine("Spielstand vor unserem Zug: " + state);
			//Console.WriteLine(nextTask);
			//Console.WriteLine("My health: " + poGame.CurrentPlayer.Hero.Health);
			//Console.WriteLine("Opponent health: " + poGame.CurrentOpponent.Hero.Health);
			//Console.WriteLine("----------------------------");
			//Console.WriteLine("");
			return nextTask;
		}

		public override void FinalizeAgent() { }
		public override void FinalizeGame() { }

		public override void InitializeAgent(){}
		public override void InitializeGame(){}
	}
}
