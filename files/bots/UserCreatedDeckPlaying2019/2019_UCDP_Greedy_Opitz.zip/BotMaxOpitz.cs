﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Enums;

namespace SabberStoneCoreAi.Competition.Agents
{
	class BotMaxOpitz : AbstractAgent
	{
		public BotMaxOpitz()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}

		public override void InitializeAgent() {
			
		}

		public override void InitializeGame() {}
		public override void FinalizeGame(){}
		public override void FinalizeAgent(){}

		public override PlayerTask GetMove(POGame.POGame POGame)
		{
			Dictionary<PlayerTask, POGame.POGame> tasks = POGame.Simulate(POGame.CurrentPlayer.Options());

			if (tasks.Any())
			{
				return tasks.OrderBy(s => Score(s.Value, POGame.CurrentPlayer.PlayerId)).Last().Key;
			}

			else return POGame.CurrentPlayer.Options().First(p => p.PlayerTaskType == PlayerTaskType.END_TURN);
		}

		private static int Score( POGame.POGame state, int playerId )
		{
			SabberStoneCore.Model.Entities.Controller p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			return new MaxScore { Controller = p }.Rate();
		}
	}
}
