﻿using System;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
    public class MaxScore : Score
    {
        public override int Rate()
        {
            if (OpHeroHp < 1)
                return Int32.MaxValue;

            if (HeroHp < 1)
                return Int32.MinValue;

            int result = 0;

			// Mana left * -10
			if (Controller.BaseMana - Controller.OverloadLocked - Controller.UsedMana > 0)
				result += (Controller.BaseMana - Controller.OverloadLocked - Controller.UsedMana) * -10;
			
			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
                result += 1000;

            result += (BoardZone.Count - OpBoardZone.Count) * 75;

			// use Heropower
			if(Controller.HeroClass.Equals(SabberStoneCore.Enums.CardClass.WARRIOR))
				result += Controller.HeroPowerActivationsThisTurn * 10;

			if (Controller.HeroClass.Equals(SabberStoneCore.Enums.CardClass.HUNTER)
				|| Controller.HeroClass.Equals(SabberStoneCore.Enums.CardClass.MAGE))
				result += Controller.HeroPowerActivationsThisTurn * 20;

			//don't give the opp an easy bordclear
			result += (MinionTotHealth - OpMinionTotAtk) * 100;

            result += OpMinionTotHealthTaunt * -50;

			// FINISH HIM
			if (OpHeroHp > 0 && OpHeroHp < 5)
				result += OpHeroHp * -25;

			// don't lose too much Minions
			result += Controller.NumFriendlyMinionsThatDiedThisGame * -50;

			// don't be afraid to attack
			result += Controller.NumFriendlyMinionsThatAttackedThisTurn * 20;

            result += MinionTotAtk;

            result += (HeroHp - OpHeroHp) * 10;

            return result;
        }
    }
}
