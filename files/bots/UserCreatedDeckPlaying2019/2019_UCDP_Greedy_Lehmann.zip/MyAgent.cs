﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;

using SabberStoneCoreAi.Meta;
using SabberStoneCore.Model;
using SabberStoneCore.Enums;


namespace SabberStoneCoreAi.Competition.Agents
{
	class BotLehmann : AbstractAgent
	{
		public BotLehmann()
		{
			preferedDeck = Decks.AggroPirateWarrior;
			preferedHero = CardClass.WARRIOR;
		}

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			var player = poGame.CurrentPlayer;

			// Get all simulation results for simulations that didn't fail
			var validOpts = poGame.Simulate(player.Options()).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}

		public override void InitializeAgent()
		{
			
		}

		public override void InitializeGame()
		{
		}

		// Calculate different scores based on our opponents hero's class
		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentOpponent.HeroClass)
			{
				case CardClass.WARRIOR: return new RampScore { Controller = p }.Rate();
				case CardClass.MAGE: return new RampScore { Controller = p }.Rate();
				default: return new RampScore { Controller = p }.Rate();
			}
		}
	}
}
