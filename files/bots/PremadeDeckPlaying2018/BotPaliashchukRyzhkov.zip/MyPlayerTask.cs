﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	[Serializable]
	class MyPlayerTask
	{
		private PlayerTaskType playerTaskType;
		private bool hasSource = false;
		private bool hasTarget = false;
		private int sourceId = -1;
		private int targetId = -1;


		public PlayerTaskType PlayerTaskType { get => playerTaskType; set => playerTaskType = value; }
		public bool HasSource { get => hasSource; set => hasSource = value; }
		public bool HasTarget { get => hasTarget; set => hasTarget = value; }
		public int SourceId { get => sourceId; set => sourceId = value; }
		public int TargetId { get => targetId; set => targetId = value; }

		public MyPlayerTask(PlayerTask option)
		{
			PlayerTaskType = option.PlayerTaskType;
			HasSource = option.HasSource;
			HasTarget = option.HasTarget;
			if (HasSource)
			{
				SourceId = option.Source.Card.AssetId;
			}
			if (HasTarget)
			{
				TargetId = option.Target.Id;
			}

		}

		public MyPlayerTask(MyPlayerTask option)
		{
			TargetId = option.TargetId;
			PlayerTaskType = option.PlayerTaskType;
			HasSource = option.HasSource;
			HasTarget = option.HasTarget;
			SourceId = option.SourceId;
			TargetId = option.TargetId;
		}

		public override bool Equals(object obj)
		{
			var task = obj as MyPlayerTask;
			if (obj is PlayerTask)
			{
				task = new MyPlayerTask((obj as PlayerTask));
			}

			return task != null &&
				   PlayerTaskType == task.PlayerTaskType &&
				   HasSource == task.HasSource &&
				   HasTarget == task.HasTarget &&
				   SourceId == task.SourceId &&
				   TargetId == task.TargetId;
		}

		public static bool operator ==(MyPlayerTask task1, MyPlayerTask task2)
		{
			return EqualityComparer<MyPlayerTask>.Default.Equals(task1, task2);
		}

		public static bool operator !=(MyPlayerTask task1, MyPlayerTask task2)
		{
			return !(task1 == task2);
		}

		public override string ToString()
		{
			return "MyPlayerTask: " + playerTaskType + " " + HasSource + " " + SourceId + " " + HasTarget + " " + TargetId;
		}
	}
}
