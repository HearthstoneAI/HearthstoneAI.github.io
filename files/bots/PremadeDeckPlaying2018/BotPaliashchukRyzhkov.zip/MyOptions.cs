﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	class MyOptions
	{
		public List<MyPlayerTask> options;


		public MyOptions(List<PlayerTask> options)
		{
			this.options = new List<MyPlayerTask>();
			for (int i = 0; i < options.Count; i++)
			{
				var temp = new MyPlayerTask(options[i]);
				this.options.Add(temp);
			}

		}

		public MyOptions(MyOptions options)
		{
			this.options = new List<MyPlayerTask>();
			this.options.AddRange(options.options);
		}

		public override bool Equals(object obj)
		{
			var newOptions = obj as MyOptions;

			if (newOptions == null)
				return false;

			if (newOptions.options.Count != options.Count)
				return false;

			bool result = true;

			int n1 = 0;
			int n2 = 0;
			int length = options.Count;

			for (int i = 0; i < length; i++)
			{
				for (int k = 0; k < length; k++)
				{
					if (options[i] == options[k])
					{
						n1++;
					}
					if (options[i] == newOptions.options[k])
					{
						n2++;
					}
				}
				if (n1 != n2)
				{
					result = false;
					break;
				}
				n1 = 0;
				n2 = 0;
			}

			return result;
		}

		public static bool operator ==(MyOptions options1, MyOptions options2)
		{
			return EqualityComparer<MyOptions>.Default.Equals(options1, options2);
		}

		public static bool operator !=(MyOptions options1, MyOptions options2)
		{
			return !(options1 == options2);
		}
	}
}
