﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;


//Developed by Mikhail Paliashchuk and Alexander Ryzhkov
namespace SabberStoneCoreAi.Agent
{
    class BotPaliashchukRyzhkov : AbstractAgent
    {
		private Random Rnd = new Random();

		bool isFirstMove = true;
		int last_turn = 0;
		int gameplayed = 0;

		double timer = 0;
		double max_time = 10;
		Stopwatch stopWatch;

		// for simulate
		float maxExpectedReward = -3000000;
		bool isWin = false;
		List<PlayerTask> simMoves;
		List<PlayerTask> bestMoves;
		MyOptions myBestMoves;

		bool exitrecursion = false;

		// for evaluate
		public float weight1 = 1f;
		public float weight2 = 1f;

		public float myHealthImp = 1;
		public float myUnitAttackImp = 1;
		public float myUnitHealthImp = 1;

		public float enemyHealthImp = 1;
		public float enemyUnitHealthImp = 1;
		public float enemyUnitAttackImp = 1;

		public override void InitializeAgent()
		{
			simMoves = new List<PlayerTask>();
			bestMoves = new List<PlayerTask>();
			Rnd = new Random();
			stopWatch = new Stopwatch();

		}

		public override void InitializeGame()
		{

		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			if (last_turn == 0)
			{
				last_turn = poGame.Turn;
				stopWatch.Start();
			}

			if (last_turn != poGame.Turn)
			{
				isWin = false;
				exitrecursion = false;
				simMoves.Clear();
				bestMoves.Clear();
				last_turn = poGame.Turn;
				isFirstMove = true;
				timer = 0;
				stopWatch.Stop();
				stopWatch.Reset();
				stopWatch.Start();
			}

			if (isFirstMove)
			{
				isFirstMove = false;
				maxExpectedReward = -3000000;
				TurnSimulate1(poGame);
				myBestMoves = new MyOptions(bestMoves);
			}
			else
			{
				if (bestMoves.Count != 0)
				{
					bestMoves.RemoveAt(0);
					myBestMoves.options.RemoveAt(0);
				}
			}


			if (bestMoves.Count == 0)
				return poGame.CurrentPlayer.Options().Find(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
			else
			{
				bool check = false;
				int index = -1;
				for (int i = 0; i < poGame.CurrentPlayer.Options().Count; i++)
				{
					if (myBestMoves.options[0] == new MyPlayerTask(poGame.CurrentPlayer.Options()[i]))
					{
						index = i;
						check = true;
						break;
					}
				}
				return bestMoves[0];
			}
		}


		public override void FinalizeGame()
		{
			simMoves.Clear();
			bestMoves.Clear();
			last_turn = 0;
			isFirstMove = true;
		}

		public override void FinalizeAgent()
		{

		}

		public bool TurnSimulate1(POGame.POGame poGame)
		{
			timer = stopWatch.ElapsedMilliseconds;

			if (timer >= max_time)
			{
				exitrecursion = true;
				stopWatch.Stop();
				stopWatch.Reset();
			}
			if (exitrecursion)
				return false;

			if (poGame == null)
			{
				return false;
			}

			bool flag = true;

			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			List<PlayerTask> validTasks = new List<PlayerTask>();

			if (options.Count > 1)
			{
				// filter all non EndTurn Tasks
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType != PlayerTaskType.END_TURN)
						validTasks.Add(task);
				}
			}
			else if (options[0].PlayerTaskType != PlayerTaskType.END_TURN)
			{
				validTasks.Add(options[0]);
			}


			float currentReward = EvaluateState(poGame.CurrentPlayer, poGame.CurrentOpponent);
			if (currentReward > maxExpectedReward)
			{
				maxExpectedReward = currentReward;
				bestMoves = new List<PlayerTask>(simMoves);
				bestMoves.Add(poGame.CurrentPlayer.Options().Find(x => x.PlayerTaskType == PlayerTaskType.END_TURN));
			}

			if (validTasks.Count == 0)
			{
				flag = false;
				return flag;
			}

			Dictionary<PlayerTask, POGame.POGame> results = new Dictionary<PlayerTask, POGame.POGame>();
			results = poGame.Simulate(validTasks);

			for (int i = 0; i < validTasks.Count; i++)
			{
				if (timer >= 60000)
				{
					exitrecursion = true;
					stopWatch.Stop();
					stopWatch.Reset();
				}
				if (exitrecursion)
					return false;
				flag = true;
				POGame.POGame tempPoGame;
				try
				{
					tempPoGame = results.GetValueOrDefault(validTasks[i]);
				}
				catch (Exception e)
				{
					continue;
				}

				if (tempPoGame == null)
				{
					continue;
				}

				simMoves.Add(validTasks[i]);

				if (tempPoGame.CurrentPlayer.Hero.Health <= 0)
				{
					if (simMoves.Count != 0)
						simMoves.RemoveAt(simMoves.Count - 1);
					if (i == validTasks.Count - 1)
						flag = false;
					continue;
				}
				else if (tempPoGame.CurrentOpponent.Hero.Health <= 0)
				{
					if (!isWin)
					{
						isWin = true;
						bestMoves = new List<PlayerTask>(simMoves);
					}

					if (simMoves.Count != 0)
						simMoves.RemoveAt(simMoves.Count - 1);
					flag = false;
					exitrecursion = true;
					break;
				}

				while (flag && !exitrecursion)
				{
					flag = TurnSimulate1(tempPoGame);
					if (exitrecursion)
					{
						flag = false;
						break;
					}
				}
				if (simMoves.Count != 0)
					simMoves.RemoveAt(simMoves.Count - 1);
			}
			return flag;
		}


		public float EvaluateState(SabberStoneCore.Model.Entities.Controller player1, SabberStoneCore.Model.Entities.Controller player2)
		{
			float expected_reward_1 = 0;
			float expected_reward_2 = 0;

			expected_reward_1 += myHealthImp * (player1.Hero.Health + player1.Hero.Armor);
			expected_reward_1 += myUnitAttackImp * player1.Hero.AttackDamage;

			// find enemy min attack enemy
			int enemyMinAttack = 100;
			for(int i = 0; i < player2.BoardZone.GetAll().Length; i++)
			{
				SabberStoneCore.Model.Entities.Minion minion = player2.BoardZone.GetAll()[i];
				if (minion.AttackDamage < enemyMinAttack)
					enemyMinAttack = minion.AttackDamage;
			}
			if (enemyMinAttack == 100)
				enemyMinAttack = 0;

			// find my max attack
			int myMaxAttack = 100;
			for (int i = 0; i < player1.BoardZone.GetAll().Length; i++)
			{
				SabberStoneCore.Model.Entities.Minion minion = player1.BoardZone.GetAll()[i];
				if (minion.AttackDamage < myMaxAttack)
					myMaxAttack = minion.AttackDamage;
			}
			if (myMaxAttack == 100)
				myMaxAttack = 0;


			for (int i = 0; i < player1.BoardZone.GetAll().Length; i++)
			{
				SabberStoneCore.Model.Entities.Minion minion = player1.BoardZone.GetAll()[i];
				if (minion.HasTaunt)
					expected_reward_1 += myHealthImp * minion.Health;
				else
					expected_reward_1 += myUnitHealthImp * minion.Health;
				if (minion.HasDivineShield)
					expected_reward_1 += myUnitHealthImp * (minion.Health + enemyMinAttack);
				if (minion.HasWindfury)
					expected_reward_1 += myUnitAttackImp * 2 * minion.AttackDamage;
				else
					expected_reward_1 += myUnitAttackImp * minion.AttackDamage;
				if (minion.IsFrozen)
				{
					if (minion.HasWindfury)
						expected_reward_1 += -myUnitAttackImp * 2 * minion.AttackDamage;
					else
						expected_reward_1 += -myUnitAttackImp * minion.AttackDamage;
				}
				if (minion.Freeze)
				{
					expected_reward_2 += -enemyUnitAttackImp * enemyMinAttack;
				}
			}



			expected_reward_2 += enemyHealthImp * (player2.Hero.Health + player2.Hero.Armor);
			expected_reward_2 += enemyUnitAttackImp * player2.Hero.AttackDamage;


			for (int i = 0; i < player2.BoardZone.GetAll().Length; i++)
			{
				SabberStoneCore.Model.Entities.Minion minion = player2.BoardZone.GetAll()[i];
				if (minion.HasTaunt)
					expected_reward_2 += enemyHealthImp * minion.Health;
				else
					expected_reward_2 += enemyUnitHealthImp * minion.Health;
				if (minion.HasDivineShield)
					expected_reward_2 += enemyUnitHealthImp * (minion.Health + myMaxAttack);
				if (minion.HasWindfury)
					expected_reward_2 += enemyUnitAttackImp * 2 * minion.AttackDamage;
				else
					expected_reward_2 += enemyUnitAttackImp * minion.AttackDamage;
				if (minion.IsFrozen)
				{
					if (minion.HasWindfury)
						expected_reward_2 += -enemyUnitAttackImp * 2 * minion.AttackDamage;
					else
						expected_reward_2 += -enemyUnitAttackImp * minion.AttackDamage;
				}
				if (minion.Freeze)
				{
					expected_reward_1 += -myUnitAttackImp * myMaxAttack;
				}
			}
			
			return expected_reward_1 * weight1 - expected_reward_2 * weight2;
			
		}

		public override string ToString()
		{

			return "Agent parameters: w1 = " + weight1.ToString() + " , w2 = " + weight2.ToString() +
				"\n myHealthImp = " + myHealthImp + " , myUnitAttackImp = " + myUnitAttackImp + "myUnitHealthImp = " + myUnitHealthImp +
				"\n enemyHealthImp = " + enemyHealthImp + " , enemyUnitHealthImp = " + enemyUnitHealthImp + "enemyUnitAttackImp = " + enemyUnitAttackImp;
		}
	}
}
