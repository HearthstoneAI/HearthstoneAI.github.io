﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;


// Developed by Anonymous Author (Greedy01)
namespace SabberStoneCoreAi.src.Agent
{
	class Greedy01 : AbstractAgent
	{
		private Random Rnd = new Random();
		private int gameNum;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			//Console.WriteLine(gameNum + ". game ended");
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			//Console.WriteLine(gameNum + ". Greedy01 :" + poGame.Turn.ToString() + ". turn - Greedy");
			return Greedy(poGame, options);
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
			gameNum = 0;
		}

		public override void InitializeGame()
		{
			//Console.WriteLine(++gameNum + ". game started");
		}

		public PlayerTask Greedy(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			List<int> fitnessList = new List<int>();
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated = poGame.Simulate(options);
			for (int i = 0; i < simulated.Count; i++)
			{
				if (i == 0)
				{
					fitnessList.Add(GetFitness(poGame));
				}
				else
				{
					SabberStoneCoreAi.POGame.POGame newGame = simulated[options[i]];
					fitnessList.Add(GetFitness(newGame));
				}
			}
			int taskIndex = fitnessList.IndexOf(fitnessList.Max());
			return options[taskIndex];
		}

		public int GetFitness(SabberStoneCoreAi.POGame.POGame game)
		{
			int opponentHero = game.CurrentOpponent.Hero.Health;
			int ownHero = game.CurrentPlayer.Hero.Health;
			int ownMinionPower = 0;
			int opponentMinionPower = 0;
			foreach (SabberStoneCore.Model.Entities.Minion minion in game.Minions)
			{
				if(minion.Controller == game.CurrentPlayer)
				{
					ownMinionPower += minion.AttackDamage + minion.Health;
				}
				else
				{
					opponentMinionPower += minion.AttackDamage + minion.Health;
				}				
			}
			return ownHero + ownMinionPower - opponentHero - opponentMinionPower;
		}
	}
}
