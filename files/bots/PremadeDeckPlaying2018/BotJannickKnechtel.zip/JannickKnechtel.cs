﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	//Developed by Jannick Knechtel
	class JannickKnechtel : AbstractAgent
	{
		private Random Rnd = new Random();

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			return getBestMove(poGame, options);
		}

		public override void InitializeAgent()
		{
			//Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}

		public PlayerTask getBestMove(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{

			int turn = 0;
			int next = 0;
			PlayerTask best = options[0];

			turn = TurnValue(poGame);


			foreach (PlayerTask task in options) {									//Phase 1: Mana ausgeben --> Karten spielen/Hero Power

				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD || task.PlayerTaskType == PlayerTaskType.HERO_POWER) {

					List<PlayerTask> taskl =  new List<PlayerTask>();
					taskl.Add(task);

					next = TurnValue(poGame.Simulate(taskl)[task]);

					if (next > turn) {
						turn = next;
						best = task;
					}

				}

			}

			if (best != options[0]) return best;

			foreach (PlayerTask task in options) {									//Phase 2: Angriff

				if(task.PlayerTaskType == PlayerTaskType.MINION_ATTACK || task.PlayerTaskType == PlayerTaskType.HERO_ATTACK){

					List<PlayerTask> taskl = new List<PlayerTask>();
					taskl.Add(task);

					next = TurnValue(poGame.Simulate(taskl)[task]);

					if (next > turn)
					{
						turn = next;
						best = task;
					}

				}

			}

			if (best != options[0]) return best;

			return options[0];
			/*


			LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
				{
					minionAttacks.AddLast(task);
				}
			}
			if (minionAttacks.Count > 0)
				return minionAttacks.First.Value;

			PlayerTask summonMinion = null;
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
				{
					summonMinion = task;
				}
			}
			if (summonMinion != null)
				return summonMinion;

			else
				return options[0];

			*/

		}

		public int TurnValue(SabberStoneCoreAi.POGame.POGame game) {														//Bewertet aktuellen, bzw. simulierten GameState

			int value = 0;
			int atk = 0;
			int hp = 0;

			foreach (SabberStoneCore.Model.Entities.Minion minion in game.CurrentPlayer.BoardZone) {						//Eigene Minions
				hp = minion.Health * 2;
				atk = minion.AttackDamage * 4;

				
				if (minion.HasWindfury) atk *= 2;
				if (minion.HasDivineShield) hp *= 2;
				if (minion.HasTaunt) hp += 3;
				if (minion.HasLifeSteal) hp += 1;
				if (minion.HasInspire) hp += 3;
				if (minion.HasCharge) atk *= 2;
				if (minion.HasStealth) hp += 3;
				if (minion.Poisonous) hp += 5;

				value += hp;
				value += atk;
			}

			foreach (SabberStoneCore.Model.Entities.Minion minion in game.CurrentOpponent.BoardZone){						//Gegner Minions
				hp = minion.Health * 2;
				atk = minion.AttackDamage * 4;

				if (minion.HasWindfury) atk *= 2;
				if (minion.HasDivineShield) hp *= 2;
				if (minion.HasTaunt) hp *= 2;
				if (minion.HasLifeSteal) hp += 1;
				if (minion.HasInspire) hp += 3;
				if (minion.HasStealth) hp += 3;
				if (minion.Poisonous) hp += 9;

				value -= hp;
				value -= atk;
			}
			
			value += game.CurrentPlayer.SecretZone.Count * 16;																//Eigene Secrets
			//value -= game.CurrentOpponent.SecretZone.Count * 16;															//Gegner Secrets (nicht sicher ob erlaubt)


			if (game.CurrentPlayer.Hero.Weapon != null) value += game.CurrentPlayer.Hero.Weapon.AttackDamage * game.CurrentPlayer.Hero.Weapon.Durability * 2;           //Waffe
			if (game.CurrentOpponent.Hero.Weapon != null) value -= game.CurrentOpponent.Hero.Weapon.AttackDamage * game.CurrentOpponent.Hero.Weapon.Durability * 4;         //Waffe Gegner

			value += game.CurrentPlayer.Hero.Health;                                                                        //eigene Hero-HP
			value += 30 - game.CurrentOpponent.Hero.Health;                                                                 //Gegner Hero-HP
			value += game.CurrentPlayer.Hero.Armor;																			//Armor
			value -= game.CurrentOpponent.Hero.Armor;																		//Gegner Armor


			foreach (SabberStoneCore.Model.Entities.Entity card in game.CurrentPlayer.HandZone) {							//Wert der Karten auf der Hand
				value += card.Card.Cost;
			}




			if (game.CurrentOpponent.Hero.Health <= 0) value = 9999999;													//Wenn Gegner durch Zug stirbt --> Maximaler Rückgabewert
			if (game.CurrentPlayer.Hero.Health <= 0) value = -9999999;														//Wenn Spielr durch Zug stirbt --> Minimaler Rückgabewert
			return value;
		}
	}
}
