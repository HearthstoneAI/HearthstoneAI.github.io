﻿using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using System.Collections.Generic;

namespace SabberStoneCoreAi.GameStateIkarus
{

	struct CompactMinion
	{
		public CompactMinion(int _health, int _damage, string _cardId)
		{
			health = _health;
			damage = _damage;
			cardId = _cardId;
		}

		public int health;
		public int damage;
		public string cardId;
	}

	class GameStateLog
	{
		List<List<CompactGameState>> history = new List<List<CompactGameState>>();

		public void Add(Game game)
		{
		//	history[history.Count - 1].Add(new CompactGameState(game));
		}
		public void Advance()
		{
			history.Add(new List<CompactGameState>());
		}

		public float Test(HashFunction function)
		{
			int numHits = 0;
			int numMisses = 0;

			Dictionary<int, CompactGameState> dict = new Dictionary<int, CompactGameState>();
			foreach (List<CompactGameState> turn in history)
			{
				dict.Clear();
				foreach (CompactGameState state in turn)
				{
					int key = function.Hash(state);
					CompactGameState g;
					if (dict.TryGetValue(key, out g))
					{
						if (state != g)
							++numMisses;//Console.WriteLine("collision");
						else ++numHits;
					}
					else dict.Add(key, state);
				}
			}

			float r = (float)numHits / numMisses;

		//	System.Console.WriteLine($"{numHits} / {numMisses} = {r}");

			return r;
		}
	}

	class CompactGameState
	{
		public CompactGameState(Game game)
		{
			minions = new List<CompactMinion>();
			minions.Capacity = game.Minions.Count;
			foreach (SabberStoneCore.Model.Entities.Minion entity in game.Minions)
			{
				minions.Add(new CompactMinion(entity.Health, entity.AttackDamage, entity.Card.Id));
			}

			currentPlayerHealth = game.CurrentPlayer.Hero.Health;
			currentOpponentHealth = game.CurrentOpponent.Hero.Health;
			currentPlayerMana = game.CurrentPlayer.RemainingMana;
			optionsPlayed = game.CurrentPlayer.NumOptionsPlayedThisTurn;

			currentPlayerId = game.CurrentPlayer.PlayerId;
		}

		public static bool operator== (CompactGameState lhs, CompactGameState rhs)
		{
			if (lhs.currentPlayerHealth != rhs.currentPlayerHealth) return false;
			if (lhs.currentOpponentHealth != rhs.currentOpponentHealth) return false;
			if (lhs.currentPlayerMana != rhs.currentPlayerMana) return false;
			if (lhs.optionsPlayed != rhs.optionsPlayed) return false;
			if (lhs.minions.Count != rhs.minions.Count) return false;

			for (int i = 0; i < lhs.minions.Count; ++i)
			{
				CompactMinion entity1 = lhs.minions[i];
				CompactMinion entity2 = rhs.minions[i];

				if (entity1.health != entity2.health || entity1.damage != entity2.damage
					|| entity1.cardId != entity2.cardId)
					return false;
			}
			return true;
		}

		public static bool operator !=(CompactGameState lhs, CompactGameState rhs)
		{
			return !(lhs == rhs);
		}

		public List<CompactMinion> minions;
		public List<int> playerCards;
		public List<int> opponentCards;
		public int currentPlayerHealth;
		public int currentOpponentHealth;
		public int currentPlayerMana;
		public int optionsPlayed;

		public int currentPlayerId;

		public int numSimulations = 0;
		public int numWins = 0;
		public float totalScore = 0f;
	}

	class HashFunction
	{
		public const int NUM_ARGS = 18;
		public int[] shifts;

		// generate new
		public HashFunction()
		{
			System.Random rng = new System.Random();
			shifts = new int[NUM_ARGS];
			for(int i = 0; i < NUM_ARGS; ++i)
			{
				shifts[i] = rng.Next(32);
			}
		}

		public int Hash(CompactGameState state)
		{
			int h = 0;

			h ^= state.currentPlayerHealth << shifts[0];
			h ^= state.currentOpponentHealth << shifts[1];
			h ^= state.optionsPlayed << shifts[2];
			h ^= state.currentPlayerMana << shifts[3];
			for(int i = 0; i <state.minions.Count; ++i)
			{
				h ^= state.minions[i].health << shifts[4+i];
			}

			return h;
		}

		public override string ToString()
		{
			string s = "";
			for (int i = 0; i < NUM_ARGS; ++i)
			{
				s += shifts[i];
				s += ", ";
			}

			return s;
		}
	}

	class EvalFunction
	{
		public EvalFunction() { }

		public EvalFunction(EvalFunction other)
		{
			for(int i= 0; i< NUM_DIMENSIONS; ++i)
			{
				weights[i] = other.weights[i];
			}
		}

		// init with random values in the range of [-_max, _max]
		public EvalFunction(float _max)
		{
			for (int i = 0; i < NUM_DIMENSIONS; ++i)
				weights[i] = (float)randomGenerator.NextDouble() * _max * 2f - _max;
		}

		public float Evaluate(Game game, int playerId)
		{
			Controller self;
			Controller other;
			if (game.CurrentPlayer.PlayerId == playerId)
			{
				self = game.CurrentPlayer;
				other = game.CurrentOpponent;
			}
			else
			{
				self = game.CurrentOpponent;
				other = game.CurrentPlayer;
			}

			float value = self.HandZone.Count * weights[0] + self.Hero.Health * weights[1]
				+ self.RemainingMana * weights[6];
			if (self.Hero.Weapon != null)
				value += self.Hero.Weapon.AttackDamage * self.Hero.Weapon.Durability * weights[2];

			value += other.HandZone.Count * weights[3] + other.Hero.Health * weights[4];
			if (other.Hero.Weapon != null)
				value += other.Hero.Weapon.AttackDamage * other.Hero.Weapon.Durability * weights[5];

			List<Minion> minions = game.Minions;
			minions.Sort((m1, m2) => m1.AttackDamage + m1.Health - (m2.AttackDamage + m2.Health));

			int minions1 = 0;
			int minions2 = 0;
			foreach (Minion minion in game.Minions)
			{
				int ind;
				if (minion.Controller.PlayerId == self.PlayerId)
				{
					ind = BEGIN_MINIONS + minions1 * WEIGHTS_PER_MINION;
					++minions1;
				}
				else
				{
					ind = BEGIN_MINIONS + minions2 * WEIGHTS_PER_MINION + MINION_WEIGHTS_PER_PLAYER;
					++minions2;
				}

				float v = minion.Health * minion.Damage;
				value += weights[ind] * minion.AttackDamage + weights[ind+1]* minion.Health + weights[ind+2] * v;
			}

			return value;
		}

		// randomly change weights
		public void Mutate(int mutations = 2, float _strength = 0.1f)
		{
			for(int i = 0; i < mutations; ++i)
			{
				int ind = randomGenerator.Next(NUM_DIMENSIONS);
				switch(randomGenerator.Next(4))
				{
					case 0:
						weights[ind] += _strength;
						break;
					case 1:
						weights[ind] -= _strength;
						break;
					case 2:
						weights[ind] *= 1f + _strength;
						break;
					case 3:
						weights[ind] *= 1f - _strength;
						break;
				}
			}
		}

		public EvalFunction CrossOver(EvalFunction other)
		{
			EvalFunction res = new EvalFunction();
			for(int i = 0; i < NUM_DIMENSIONS; ++i)
			{
				res.weights[i] = randomGenerator.Next(2) == 0 ? weights[i] : other.weights[i];
			}

			return res;
		}

		public override string ToString()
		{
			string str = "[ ";
			for (int i = 0; i < NUM_DIMENSIONS; ++i)
			{
				str += weights[i].ToString("0.00");
				str += " ";
			}

			return str + "]";
		}

		//	hero life, minion life + damage, cards in hand; weapon; current player mana
		public const int WEIGHTS_PER_MINION = 3;
		public const int MINION_WEIGHTS_PER_PLAYER = WEIGHTS_PER_MINION * 7;
		public const int BEGIN_MINIONS = WEIGHTS_PER_PLAYER;
		public const int WEIGHTS_PER_PLAYER =3;
		public const int NUM_DIMENSIONS = MINION_WEIGHTS_PER_PLAYER * 2 + WEIGHTS_PER_PLAYER * 2 + 1;
		public float[] weights = new float[NUM_DIMENSIONS];

		private System.Random randomGenerator = new System.Random();
	}
}
