﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using SabberStoneCore.Enums;
using SabberStoneCore.Exceptions;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Model.Zones;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.GameStateIkarus;
using SabberStoneCore.Tasks.PlayerTasks;


// Developed by Anonymous Author (Thanduriel)
namespace SabberStoneCoreAi.Agent
{
	class IkarusCompetition : AbstractAgent
	{
		class Node
		{

			public PlayerTask task;
			public int numSimulations;
			public int numWins;
			public float totalScore;
			//	public int currentPlayerId;

			public Node[] childs;
			public int numChilds;
		}

		class TreeState
		{
			public TreeState(Node _node, CompactGameState _gameState)
			{
				gameState = _gameState;
				parents = new HashSet<Node> { _node };
			}
			public CompactGameState gameState;
			public HashSet<Node> parents;
		}

		private Random Rnd = new Random();
		private int playerId;
		private double turnTime;
		private Stopwatch turnWatch;
		private int gameCount = 0;
		// cache with possible gamestates
		private Dictionary<int, List<TreeState>> previousStates;
		private SabberStoneCoreAi.DeckTracker deckTracker;
		private int currentTurn = -1;
		private int lookAhead;
		private bool useAdaptiveDepth;
		public bool useRandomSelection = false;
		EvalFunction evalFunction;


		public GameStateLog log = new GameStateLog();

		public int numHits = 0;
		public int numMisses = 0;

		public int simulationsTotal = 0;
		public int simulationsExceptRegular = 0;
		public int simulationsExceptSpecial = 0;

		public IkarusCompetition() : this(null, 15.0, true){}


		public IkarusCompetition(EvalFunction _evalFunction = null, double _turnTime = 65.0, bool adaptiveDepth = true)
		{
			turnTime = _turnTime;
			useRandomSelection = false;
			previousStates = new Dictionary<int, List<TreeState>>();
			turnWatch = new Stopwatch();
			if(_evalFunction == null)
			{
				evalFunction = new EvalFunction();
				evalFunction.weights = new float[EvalFunction.NUM_DIMENSIONS] { 1.24f, 1.38f, 1.46f, 0.74f, -0.58f, 1.29f, 0.97f, 0.83f, -0.81f, -0.01f, 2.03f, -0.88f, 1.33f, 1.74f, 1.10f, 0.56f, 4.58f, 1.10f, 0.99f, 0.85f, 0.36f, 0.99f, 1.15f, 0.68f, -1.19f, -0.87f, -0.98f, -0.70f, -0.10f, -0.36f, 0.17f, -1.08f, -0.72f, -0.43f, 1.94f, 2.15f, -1.99f, -0.92f, -0.91f, 0.06f, -1.99f, -1.00f, 0.57f, -1.20f, 0.15f, -0.80f, -1.11f, -2.03f, -2.16f };
			}
			else evalFunction = _evalFunction;
			useAdaptiveDepth = adaptiveDepth;
		}

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			++gameCount;
		//	Console.WriteLine($"{numHits}, {numMisses}");
		//	Console.WriteLine($"per simulation: {timeTakenSim}; per check: {timeTakenCheck}");
		//	Console.WriteLine(gameCount);
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			if (deckTracker == null)
			{
				deckTracker = new SabberStoneCoreAi.DeckTracker(poGame.CurrentOpponent.HeroClass);
			}
			// new turn
			if(poGame.Turn != currentTurn)
			{
				turnWatch.Restart();
				previousStates.Clear();
				log.Advance();
				currentTurn = poGame.Turn;
				deckTracker.Update(poGame.CurrentOpponent.PlayHistory);
			}
			int numSims = 0;

			// remember self
			playerId = poGame.CurrentPlayer.PlayerId;

			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			// needs to be done once so that game process works
			Dictionary<PlayerTask, POGame.POGame> simStates = poGame.Simulate(options);
			Node root = new Node();
			root.numSimulations = 1;

			Expand(root, options);

			double begin = turnWatch.Elapsed.TotalSeconds;
			double timeLeft = turnTime - turnWatch.Elapsed.TotalSeconds;
			double computeTime = 2.0 + timeLeft * 0.4;
			turnTime = begin + computeTime;
			if (turnTime > 74.0)
			{
				computeTime = timeLeft * 0.5;
				turnTime = begin + computeTime;
			}
			lookAhead = (int)(1.3 + 3.5 * Math.Log(computeTime));
			if(!useAdaptiveDepth)
			{
				lookAhead = 5;
				turnTime = begin + 1.0;
			}
		//	Console.WriteLine(timeLeft);
			do
			{
				for (int i = 0; i < 8; ++i)
				{
					Node node = Select(root);
					float result = Playout(node, poGame);
					// back-propagate
					foreach (TreeState treeState in statesVisited)
					{
						++treeState.gameState.numSimulations;
						treeState.gameState.totalScore += result;
					}
					++numSims;
					++root.numSimulations;

					foreach (Node n in relevantActions)
					{
						n.totalScore += result;
						++n.numSimulations;
					}
				}
				
			} while (turnWatch.Elapsed.TotalSeconds < turnTime);

			float max = 0f;
			PlayerTask maxTask = options[0];//RandomPlay(options);
			for(int i = 1; i < root.numChilds; ++i)
			{
				float r = (float)root.childs[i].totalScore / root.childs[i].numSimulations;
				if(r > max)
				{
					max = r;
					maxTask = root.childs[i].task;
				}
			}
		//	Console.WriteLine(numSims);
			return maxTask;
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}

		private void Expand(Node node, List<PlayerTask> playerTasks)
		{
			node.childs = new Node[playerTasks.Count];
			node.numChilds = playerTasks.Count;

			for (int i = 0; i < playerTasks.Count; ++i)
			{
				node.childs[i] = new Node();
				node.childs[i].task = playerTasks[i];
				node.childs[i].numSimulations = 1;
			}
		}

		private Node Select(Node node)
		{
		//	if(useRandomSelection) return node.childs[Rnd.Next(node.numChilds)];

			float max = 0f;
			float numSimsLog = (float)Math.Log(node.numSimulations);
			int maxInd = 0;
			for(int i = 0; i < node.numChilds; ++i)
			{
				float f = 0.01f * node.childs[i].totalScore / node.childs[i].numSimulations
					+ 1.41f * (float)Math.Sqrt(numSimsLog / node.childs[i].numSimulations);

				if(f > max)
				{
					max = f;
					maxInd = i;
				}
			}
			return node.childs[maxInd];
		}

		private enum GameResult
		{
			TIE = 0,
			FIRSTPLAYER = 1,
			SECONDPLAYER = 2
		}

		private double timeTakenSim = 0.0;
		private double timeTakenCheck = 0.0;
		public int averageDepth = 0;

		// all states visited in the current play out
		private HashSet<TreeState> statesVisited = new HashSet<TreeState>();
		// all actions that could result in the current state
		private HashSet<Node> relevantActions = new HashSet<Node>();

		private float Playout(Node node, POGame.POGame initialState)
		{
			statesVisited.Clear();
			relevantActions.Clear();
			relevantActions.Add(node);
			List<PlayerTask> taskList = new List<PlayerTask>();
			taskList.Add(node.task);
			Dictionary<PlayerTask, POGame.POGame> dic = initialState.Simulate(taskList);
			POGame.POGame newPOState = dic[node.task];
			if (newPOState == null) return evalFunction.Evaluate(node.task.Game, playerId);
			Game gameState = newPOState.CurrentOpponent.Game;

			SabberStoneCoreAi.DeckTracker localTracker = new SabberStoneCoreAi.DeckTracker(deckTracker);
			localTracker.Shuffle();
			RecoverOpponentCards(gameState, localTracker);

			try
			{
				
				gameState.Process(node.task);
			} catch(Exception) { return evalFunction.Evaluate(gameState, playerId); }

			int count = 0;
			while (true)
			{
				++count;
				if (gameState.State == State.COMPLETE)
				{
					// determine end
					if(gameState.CurrentPlayer.PlayState == PlayState.WON)
						return 100f * gameState.CurrentPlayer.PlayerId == playerId ? 1f : -1f;
					if (gameState.CurrentOpponent.PlayState == PlayState.WON)
						return 100f * gameState.CurrentOpponent.PlayerId == playerId ? 1f : -1f;
					return 0f;
				}
				// advance game state
				List<PlayerTask> tasks = gameState.CurrentPlayer.Options();
				if (tasks.Count == 0) return evalFunction.Evaluate(gameState, playerId);
				PlayerTask task = RandomPlay(tasks);
				if (count > lookAhead && task.PlayerTaskType == PlayerTaskType.END_TURN && playerId == gameState.CurrentPlayer.PlayerId)
					return evalFunction.Evaluate(gameState, playerId);
				try
				{
					++simulationsTotal;
					gameState.Process(task);
					if (gameState.Turn == currentTurn)
					{
					//	log.Add(gameState);
						int key = GameHash(gameState);
						List<TreeState> possibleMatches;
						CompactGameState newState = new CompactGameState(gameState);
						if (previousStates.TryGetValue(key, out possibleMatches))
						{
							TreeState found = possibleMatches.Find(game => game.gameState == newState);
							if (found == null)
							{
								possibleMatches.Add(new TreeState(node, newState));
							}
							else
							{
								// previously unknown parent
								if (found.parents.Add(node))
								{
									node.numSimulations += found.gameState.numSimulations;
									node.totalScore += found.gameState.totalScore;
								}
								foreach (Node n in found.parents)
								{
									relevantActions.Add(n);
								}
								statesVisited.Add(found);
							}
						}
						else
						{
							List<TreeState> states = new List<TreeState>();
							states.Add(new TreeState(node, newState));
							previousStates.Add(key, states);
						}
					}
				}
				catch (Exception)
				{
					++simulationsExceptRegular;
					averageDepth += count;
					return evalFunction.Evaluate(gameState, playerId);
				}
			}
		}

		// Return a uniform random play from the list
		private PlayerTask RandomPlay(List<PlayerTask> playerTasks)
		{
			return playerTasks[Rnd.Next(playerTasks.Count)];
		}

		private int GameHash(Game game)
		{
			int s = game.CurrentPlayer.NumOptionsPlayedThisTurn | (game.CurrentOpponent.Hero.Health << 4)
				| (game.CurrentPlayer.Hero.Health << 9)
				| (game.CurrentPlayer.UsedMana << 28);
			int shift = 14;
			foreach (SabberStoneCore.Model.Entities.Minion entity in game.Minions)
			{
				s ^= entity.Health << shift;
				shift += 2;
			}
			return s;
		}

		private void AddCardToZone(IZone zone, Card card, Controller player, Game game)
		{
			Entity.FromCard(player, card, null, zone);
		}

		private void RecoverOpponentCards(Game game, SabberStoneCoreAi.DeckTracker deckTracker)
		{
			int numCardsDeck = game.CurrentOpponent.DeckZone.Count;
			int numCardsHand = game.CurrentOpponent.HandZone.Count;

			game.CurrentOpponent.DeckCards = deckTracker.Deck;
			game.CurrentOpponent.HandZone = new HandZone(game.CurrentOpponent);
			game.CurrentOpponent.DeckZone = new DeckZone(game.CurrentOpponent);

			for (int i = 0; i < numCardsHand; ++i)
			{
				Card c = deckTracker.Draw();
				if (c == null) break;
				AddCardToZone(game.CurrentOpponent.HandZone, c, game.CurrentOpponent, game);
			}

			for (int i = 0; i < deckTracker.CardsLeft.Count; ++i)
			{
				AddCardToZone(game.CurrentOpponent.DeckZone, deckTracker.CardsLeft[i], game.CurrentOpponent, game);
			}
		}
	}
}
