﻿
using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCoreAi.Meta;
using System;
using System.Collections.Generic;

namespace SabberStoneCoreAi
{
	class DeckTracker
	{
		public DeckTracker(CardClass cardClass)
		{
			switch(cardClass)
			{
			case CardClass.WARRIOR:
				Deck = Decks.AggroPirateWarrior;
				break;
			case CardClass.MAGE:
				Deck = Decks.RenoKazakusMage;
				break;
			case CardClass.SHAMAN:
				Deck = Decks.MidrangeJadeShaman;
				break;
			default:
				int test = 1;
				break;
			}

			CardsLeft = new List<Card>();
			CardsLeft.AddRange(Deck);
		}

		// copy constructor
		public DeckTracker(DeckTracker oth)
		{
			CardsLeft = new List<Card>(oth.CardsLeft);
			Deck = oth.Deck;
			lastHistoryEntry = oth.lastHistoryEntry;
		}

		private Random rng = new Random();

		public void Shuffle()
		{
			int n = CardsLeft.Count;
			while (n > 1)
			{
				n--;
				int k = rng.Next(n + 1);
				Card value = CardsLeft[k];
				CardsLeft[k] = CardsLeft[n];
				CardsLeft[n] = value;
			}
		}

		public bool RemoveCard(Card card)
		{
			for(int i = 0; i < CardsLeft.Count; ++i)
			{
				if(CardsLeft[i].Id == card.Id)
				{
					CardsLeft[i] = CardsLeft[CardsLeft.Count - 1];
					CardsLeft.RemoveAt(CardsLeft.Count - 1);
					return true;
				}
			}

			return false;
		}

		public Card Draw()
		{
			if (CardsLeft.Count == 0) return null;
			Card card = CardsLeft[CardsLeft.Count - 1];
			CardsLeft.RemoveAt(CardsLeft.Count - 1);

			return card;
		}

		public List<Card> Draw(int numCards)
		{
			List<Card> hand = new List<Card>();
			hand.Capacity = numCards;
			hand.AddRange(CardsLeft.GetRange(CardsLeft.Count - numCards, numCards));
			CardsLeft.RemoveRange(CardsLeft.Count - numCards, numCards);

			return hand;
		}

		public void Update(List<PlayHistoryEntry> history)
		{
			for (; lastHistoryEntry < history.Count; ++lastHistoryEntry)
				RemoveCard(history[lastHistoryEntry].SourceCard);
		}

		public List<Card> CardsLeft { get; }
		public List<Card> Deck { get; }
		private int lastHistoryEntry;
	}
}
