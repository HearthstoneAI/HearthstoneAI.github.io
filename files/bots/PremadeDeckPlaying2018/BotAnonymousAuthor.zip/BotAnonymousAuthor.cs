﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;


//Developed by Anonymous Author
namespace SabberStoneCoreAi.Agent
{
	class BotAnonymousAuthor : AbstractAgent
	{
		private Random rnd = new Random();

		public override void FinalizeAgent()
		{
			//throw new NotImplementedException();
		}

		public override void FinalizeGame()
		{
			//throw new NotImplementedException();
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			PlayerTask option;

			List<PlayerTask> options = poGame.CurrentPlayer.Options();

			option = options[rnd.Next(options.Count)];

			int iMana = poGame.CurrentPlayer.BaseMana;

			//spend mana
			int iIndexTask = findBestCardToPlay(options, iMana);
			if (iIndexTask != -1) {
				//Console.Write(options[iIndexTask]);
			return options[iIndexTask]; }

			//attack
			PlayerTask tmpTask = chooseWhatToAttack(options, poGame);
			if (tmpTask != null)
				return tmpTask;

			//tryhard
			PlayerTask endTask = null; 
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
					return task;
				if (task.PlayerTaskType == PlayerTaskType.CHOOSE)
					return task;
				if (task.PlayerTaskType == PlayerTaskType.CONCEDE)
					return task;
				if (task.PlayerTaskType == PlayerTaskType.END_TURN)
					endTask = task;
			}

			return endTask;
		}

		public override void InitializeAgent()
		{
			rnd = new Random();
			//throw new NotImplementedException();
		}

		public override void InitializeGame()
		{
			//throw new NotImplementedException();
		}

		int findBestCardToPlay (List <PlayerTask> options, int iMana)
		{
			//filter playable cards
			Dictionary<int, (CardType, int)> manaList = new Dictionary<int, (CardType,int)>();
			for (int i = 0; i < options.Count; i++)
			{
				PlayerTask task = options[i];
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
					manaList.Add(i, (task.Source.Card.Type, task.Source.Card.Cost));
				if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
					manaList.Add(i, (CardType.HERO_POWER, 2));
			}

			if (manaList.Count < 1)
				return -1;

			//try to maximize
			int key = -1;
			foreach(KeyValuePair<int, (CardType, int)> manaCardOut in manaList)
			{
				foreach (KeyValuePair<int, (CardType, int)> manaCardIn in manaList)
				{
					//ToDo: find good algorithm
					if ((manaCardIn.Value.Item1 == CardType.MINION) && (manaCardIn.Value.Item2 == iMana))
						return manaCardIn.Key;
				}
				int iManaLeft = iMana - manaCardOut.Value.Item2;
				key = manaCardOut.Key;
			}
			return key;
		}

		PlayerTask chooseWhatToAttack(List<PlayerTask> options, POGame.POGame poGame)
		{
			PlayerTask possibleTask = null;
			int attackValue = 0;
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK)
				{
					int iCharIndexAtt = getCharacterIndex(task.Source, poGame.Characters);
					int iCharIndexDef = getCharacterIndex(task.Target, poGame.Characters);
					ICharacter attacker = poGame.Characters[iCharIndexAtt];
					ICharacter defender = poGame.Characters[iCharIndexDef];

					//kill minion and survive
					if (attacker.Health > defender.AttackDamage && attacker.AttackDamage >= defender.Health)
						return task;

					//kill possible threat
					if (getCharValue(attacker) < getCharValue(defender) && attacker.AttackDamage >= defender.Health)
						return task;

					//attack possible threat
					if (getCharValue(attacker) < getCharValue(defender) && attacker.Health > defender.AttackDamage && task.Target != poGame.CurrentOpponent.Hero)
					{
						if (attackValue < (getCharValue(defender) - getCharValue(attacker)))
						{
							attackValue = getCharValue(defender) - getCharValue(attacker);
							possibleTask = task;
						}
					}

					//attack hero
					if (task.Target == poGame.CurrentOpponent.Hero)
					{
						if (attacker.AttackDamage > attackValue)
						{
							attackValue = attacker.AttackDamage;
							possibleTask = task;
						}
					}
				}
			}
			return possibleTask;
		}

		int getCharacterIndex(IEntity card, List<ICharacter> characters)
		{
			for (int i = 0; i < characters.Count; i++)
			{
				if (card == characters[i])
					return i;
			}
			return -1;
		}

		bool isSpotter (ICharacter chara)
		{
			return chara.HasTaunt;
		}

		int getCharValue(ICharacter chara)
		{
			int charValue = chara.Health + chara.AttackDamage;
			charValue = (chara.HasTaunt ? charValue + 5 : charValue);
			charValue = (chara.HasWindfury ? charValue + 3 : charValue);
			charValue = (chara.AuraEffects != null ? charValue + 2 : charValue);
			return charValue;
		}
	}
}
