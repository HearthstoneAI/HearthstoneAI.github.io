﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;


/* Information:
 *	This Implementation is done for the programming assingnment in the course of Computational Intelligence in Games.
 *	it is solely done by Dennis Siegel
 *	Unfortunately it doesn't cover all possibilities and could be improved a lot, which wasn't done due to lack of time (but the but succeeded in all tests, so he should pass for the exam).
 *	Specific sections in the code that would have gotten improved when I had more time are highlighted by the keyword ToDo in front of it, which could allow some nice improvements in behavior of the bot.
 *	The implementation itself is based on the experience I gathered as a player in Hearthstone to dertermine the value of each possible play.
 *	Besides that the most interesting part of this implementation is the solution for Knappsack Problem, which is mapped on the problem of finding the best usage of mana each turn (weights = manacost, value determined by card)
*/

/* Changelog:
 *	Fixed Exception caused by devision by zero
 *	Fixed GetHeroPowerValue function to be dependent from current HeroPower and not the base HeroClass
*/

namespace SabberStoneCoreAi.Agent
{
	class BotDennisSiegel2 : AbstractAgent
	{
		private Random Rnd = new Random();
		private bool initialized = false;
		Dictionary<SabberStoneCore.Enums.GameTag, int> currentCard;
		SabberStoneCoreAi.Meta.Strategy strategy = SabberStoneCoreAi.Meta.Strategy.None;
		// Some sort of Decktracker
		List<SabberStoneCore.Model.Card> cards_left_in_deck;
		int last_turn;
		bool inverted_heal = false;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			//local variables used for evaluation
			//gets all options possible for this turn
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			//list of all possible tasks consuming mana
			List<PlayerTask> mana_option_tasks = new List<PlayerTask>();
			//list of non-mana-consuming tasks (basically only attacks
			List<PlayerTask> attackoptions = new List<PlayerTask>();
			//second list used to get the best option, some sort of workaround to put heropower and cards together
			List<int> mana_option_costs = new List<int>();
			List<double> attackvalues = new List<double>();
			List<double> mana_option_values = new List<double>();
			Dictionary<PlayerTask, double> mana_usage_options = new Dictionary<PlayerTask, double>();
			SabberStoneCore.Enums.CardClass playerClass = poGame.CurrentPlayer.BaseClass;
			PlayerTask endTurn = options[0];
			double value;
			int health, atk, cost, durability;

			// Some stuff that is done in the beginning of each game
			if (!initialized)
			{
				// Determine Archtype of currently played deck to determine specific strategy and resulting weights of actions 
				determineStrategy(poGame.CurrentPlayer.DeckCards);
				cards_left_in_deck = poGame.CurrentPlayer.DeckCards;
				//Gets the starting handcards amd removes them from the list of possible draws in the future
				for (int i = 0; i < poGame.CurrentPlayer.HandZone.GetAll().Length; i++) cards_left_in_deck.Remove(poGame.CurrentPlayer.HandZone.GetAll()[i].Card);
				last_turn = poGame.Turn;
				initialized = true;
			}

			//Some stuff that is done in the beginning of each turn
			if (last_turn != poGame.Turn)
			{
				//Gets the newly drawn card and removes it from the list of possible draws in the future
				if (cards_left_in_deck.Count != 0) cards_left_in_deck.Remove(poGame.CurrentPlayer.HandZone.GetAll()[poGame.CurrentPlayer.HandZone.GetAll().Length - 1].Card);
				last_turn = poGame.Turn;
				//ToDo: add check if heals deal damage Auchenai Soulpriest
			}

			//Stuff done on the actual turn
			foreach (PlayerTask task in options)
			{
				switch (task.PlayerTaskType)
				{
					case PlayerTaskType.PLAY_CARD:
						// Difference Minions & Spells				
						switch (task.Source.Card.Type)
						{
							//Playable card is a mionion
							case SabberStoneCore.Enums.CardType.MINION:
								currentCard = task.Source.Card.Tags;
								//Somewhat dirty to convert the IEntity into Minion, but since it is guaranteed to be a card played from hand and it's tagged as minion it should be save
								//Reasoning for it is, that the entity may have changed stats like cost or handbuffs which would not be included on the card itself
								SabberStoneCore.Model.Entities.Minion current_minion = (SabberStoneCore.Model.Entities.Minion)getHandEntityfromTarget(task);
								/* Previous option to get stats of a card, unfortunately not given changes in the specific entity like Giants
								currentCard.TryGetValue(SabberStoneCore.Enums.GameTag.ATK, out atk);
								currentCard.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out healt);
								// Does not take discounts into account!
								currentCard.TryGetValue(SabberStoneCore.Enums.GameTag.COST, out cost);
								*/
								atk = current_minion.AttackDamage;
								health = current_minion.Health;
								cost = current_minion.Cost;

								value = (double)(atk + health) / max(cost, 1);
								mana_option_tasks.Add(task);
								mana_option_costs.Add(max(cost,1));
								mana_option_values.Add(value);
								break;
							//Playable card is a spell
							case SabberStoneCore.Enums.CardType.SPELL:
								SabberStoneCore.Model.Entities.Spell current_spell = (SabberStoneCore.Model.Entities.Spell)getHandEntityfromTarget(task);
								value = evaluateText(task);
								if (value == 100) return task;
								if (value >= 0)
								{
									mana_option_tasks.Add(task);
									mana_option_costs.Add(max(current_spell.Cost,1));
									mana_option_values.Add(value);
								}
								break;
							//Playable card is a weapon
							case SabberStoneCore.Enums.CardType.WEAPON:
								//No weapon equipped
								SabberStoneCore.Model.Entities.Weapon current_weapon = (SabberStoneCore.Model.Entities.Weapon)getHandEntityfromTarget(task);
								atk = current_weapon.AttackDamage;
								durability = current_weapon.Durability;
								cost = current_weapon.Cost;
								if (poGame.CurrentPlayer.Hero.EquippedWeapon == 0)
								{
									value = (double)(atk * durability) / (max(cost, 1));
									mana_option_tasks.Add(task);
									mana_option_costs.Add(cost);
									mana_option_values.Add(value);
								}
								//Only change the weapon, if it is strictly better
								else
								{
									int cur_atk = task.Controller.Hero.Weapon.Damage;
									int cur_durability = task.Controller.Hero.Weapon.Durability;
									value = (double)(atk * durability - cur_atk * cur_durability) / (max(cost, 1));
								}
								break;
							case SabberStoneCore.Enums.CardType.TOKEN:
								break;
							default:
								break;
						}
						break;
					//Action is heropower
					case PlayerTaskType.HERO_POWER:
						value = getHeropowerValue(task, playerClass);
						if (value >= 0)
						{
							mana_usage_options.Add(task, value);
							mana_option_tasks.Add(task);
							mana_option_costs.Add(max(task.Controller.Hero.HeroPower.Cost,1));
							mana_option_values.Add(value);
						}
						break;
					case PlayerTaskType.MINION_ATTACK:
						attackoptions.Add(task);
						attackvalues.Add(getAttackValue(task));
						break;
					case PlayerTaskType.HERO_ATTACK:
						attackoptions.Add(task);
						attackvalues.Add(getAttackValue(task));
						break;
					case PlayerTaskType.END_TURN:
						endTurn = task;
						break;
					default:
						break;
				}
			}
			if (mana_option_tasks.Count != 0) return bestOption(poGame.CurrentPlayer.RemainingMana, mana_option_costs, mana_option_values, mana_option_tasks.Count, mana_option_tasks);
			if (attackoptions.Count != 0) return bestAttackOption(attackoptions, attackvalues);
			else return endTurn;
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}

		//ToDo: clearer separation
		//Determine Archetype of the deck played
		public void determineStrategy(List<SabberStoneCore.Model.Card> deck)
		{
			double avrg_mana_costs = 0;
			foreach (SabberStoneCore.Model.Card card in deck)
			{
				avrg_mana_costs += card.Cost;
			}
			avrg_mana_costs /= (double)deck.Count;
			if (avrg_mana_costs <= 3) strategy = Meta.Strategy.Aggro;
			else strategy = Meta.Strategy.Midrange;
		}

		//ToDo: 95% done, add weights depending on archtype
		// Values of Heropower, separated by class
		//Warning: Only works for basic heropowers, if the heropower changes it might cause exceptions
		public double getHeropowerValue(PlayerTask task, SabberStoneCore.Enums.CardClass heroClass)
		{
			//catch cases where the cost of heropower is not 2, i.e. cards like loatheb or other stuff, base value for cost 2 should be 0, and higher costed less / lower costed higher
			double payoff = 2 - task.Controller.Hero.HeroPower.Cost;
			//evaluate each class seperatedly
			string heroPower = task.Controller.Hero.HeroPower.ToString();

			//Case: Druid
			if (heroPower.Contains("Shapeshift"))
			{
				// 2 relevant cases: need of armor, could trade well, otherwise heropower should only be used if nothing else is possible
				if (task.Controller.Hero.Health < 10) payoff += 1.5;
				else
				{
					SabberStoneCore.Model.Entities.Minion[] entities = task.Game.CurrentOpponent.BoardZone.GetAll();
					foreach (SabberStoneCore.Model.Entities.Minion entity in entities)
					{
						if (canKill(1, entity))
						{
							payoff += 2;
							break;
						}
					}
				}
			}
			//Case: Hunter
			else if (heroPower.Contains("Steady Shot"))
			{
				payoff += 0.5;
			}
			//Case: Mage
			else if (heroPower.Contains("Fireblast"))
			{
				if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.HERO)
				{
					//There are 2 options here: own hero or opponent hero.
					//we want to avoid dealing damage to our own hero here
					if (task.Controller.Hero == task.Target) payoff = -1;
					//although dealing damage to the opponent hero is fine, it should only be used if there is no better option to spend mana on
					else payoff += 0.01;
				}
				// In that case we expect the target to be a minion
				else
				{
					//Best possible outcome is to ping a minion that only has one health left, so it dies
					if (task.Target.Controller != task.Controller)
					{
						int health, atk;
						SabberStoneCore.Model.Entities.Minion target = getBoardEntityfromTask(task, task.Target.Id);
						atk = target.AttackDamage;
						health = target.Health;
						if (health == 1) payoff += 2 + (double)atk / 10;
						//otherwise the best target would be the target that is lowest, would make future trades better, or just has the highest attack
						else payoff = atk / 10;
					}
					//Never ping your own stuff!
					else payoff += -1;
				}
			}
			//Case: Paladin
			else if (heroPower.Contains("Reinforce"))
			{
				//Paladin generates a 1/1 token for 2, which is statwise a value of 1
				//ToDo: include synergies for recruits
				payoff += 1;
			}
			//Case: Priest
			else if (heroPower.Contains("Lesser Heal"))
			{
				if (inverted_heal)
				{
					//if healing is inverted it deals damage instead, so never use it on own targets
					if (task.Controller != task.Target.Controller)
					{
						if (canKill(2, task.Target.Card))
						{
							payoff += 1 + get_killValue(2, task.Target.Card);
						}
					}
					else payoff = -1;
				}
				//Healing effect
				else
				{
					//Never heal opponents minion / hero
					if (task.Controller == task.Target.Controller)
					{
						if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION) payoff += get_healValue(2, getBoardEntityfromTask(task, task.Target.Id));
						else if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.HERO)
						{
							//only heal if health is below max increasing the lower it is to a max value of 5
							payoff += 5 - ((double)task.Target.Controller.Hero.Health / task.Target.Controller.Hero.BaseHealth * 5);
						}
					}
					else payoff = -1;
				}
			}
			//Case: Rogue
			else if (heroPower.Contains("Dagger Mastery"))
			{
				//Only relevant if no weapon is equipped
				if (task.Controller.Hero.EquippedWeapon == 0)
				{
					payoff += 1;
					SabberStoneCore.Model.Entities.Minion[] entities = task.Game.CurrentOpponent.BoardZone.GetAll();
					foreach (SabberStoneCore.Model.Entities.Minion entity in entities)
					{
						if (canKill(1, entity))
						{
							payoff += 1;
							break;
						}
					}
				}
				//Case where the Dagger gets reequipped, it would be a waste of mana if the previous dagger wasnt used for attacking, but still it would not be as valueable
				else if (task.Controller.Hero.Weapon.AttackDamage == 1 && task.Controller.Hero.CantAttack)
				{
					payoff += 0.5;
				}
				else payoff = -1;
			}
			//Case: Shaman
			else if (heroPower.Contains("Totemic Call"))
			{
				//Totems are either 1/1 or 0/2 with effects resulting in a value of 1 statwise
				//ToDo: add weights for each specific available totem, the need of each and a percentual chance of them based on possibilities
				payoff += 1;
			}
			//Case: Warlock
			else if (heroPower.Contains("Life Tap"))
			{
				//Do not overdraw or suicide on using heropower!
				if (task.Controller.Hero.Health > 15 && task.Controller.HandZone.Count <= 8) payoff += 1.5;
				else payoff = -1;
			}
			//Case: Warrior
			else if (heroPower.Contains("Armor Up!"))
			{
				//Heropower is useless if you go for an aggro deck and should only be used if nothing else is possible, otherwise it is a fine choice
				if (strategy != Meta.Strategy.Aggro) payoff += 1.5;
			}
			return payoff;
		}

		// ToDo: Weights depending on archetypes, cleaner evaluation for minions as targets for weapon
		public double getAttackValue(PlayerTask task)
		{
			double payoff = 0;
			//Hero attacking
			int src_atk, src_health, target_atk, target_health;
			if (task.PlayerTaskType == SabberStoneCore.Tasks.PlayerTasks.PlayerTaskType.HERO_ATTACK)
			{
				src_atk = task.Controller.Hero.AttackDamage;
				src_health = task.Controller.Hero.Health;
				if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
				{
					SabberStoneCore.Model.Entities.Minion target = getBoardEntityfromTask(task, task.Target.Id);
					target_atk = target.AttackDamage;
					target_health = target.Health;

					if (src_atk == target_health) payoff = 5;
					else if (src_atk > target_health) payoff = 2;
					else payoff = 0;

				}
				// Target should be enemy hero
				else
				{
					//ToDo: weight it by Archtype
					payoff = 3;
				}
			}
			//Minion attacking
			else if (task.Source.Card.Type == SabberStoneCore.Enums.CardType.MINION)
			{
				SabberStoneCore.Model.Entities.Minion src = getBoardEntityfromTask(task, task.Source.Id);
				src_atk = src.AttackDamage;
				src_health = src.Health;
				if (task.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
				{
					SabberStoneCore.Model.Entities.Minion target = getBoardEntityfromTask(task, task.Target.Id);
					target_atk = target.AttackDamage;
					target_health = target.Health;
					//Best trade - kills enemy exactly, without dieing
					if (src_atk == target_health && src_health > target_atk) payoff = 5 * (double)(target_atk + target_health) / (src_atk + src_health);
					//Favourable trade - might have too much atk, but kills without dieing
					else if (src_atk >= target_health && src_health > target_atk) payoff = 4 * (double)(target_atk + target_health) / (src_atk + src_health);
					//Bad trade - both minions die
					else if (src_atk >= target_health && src_health >= target_atk) payoff = 1 * (double)(target_atk + target_health) / (src_atk + src_health);
					// 
					else payoff = 1;
				}
				// Target should be enemy hero
				else payoff = 2;
			}
			return payoff;
		}

		// A utility function that returns maximum of two integers
		double max(double a, double b) { return (a > b) ? a : b; }
		int max(int a, int b) { return (a > b) ? a : b; }
		double min(double a, double b) { return (a < b) ? a : b; }
		int min(int a, int b) { return (a < b) ? a : b; }

		// Dynamic-Programming solution for Knappsack, used to determine the best usage of mana each turn
		PlayerTask bestOption(int avail_mana, List<int> mana_costs, List<double> values, int n, List<PlayerTask> options)
		{
			double[,] K = new double[n + 1, avail_mana + 1];
			for (int i = 0; i <= n; i++)
			{
				for (int j = 0; j <= avail_mana; j++)
				{
					if (i == 0 || j == 0) { K[i, j] = 0; }
					else if (mana_costs[i - 1] <= j && values[i - 1] + K[i - 1, j - mana_costs[i - 1]] > K[i - 1, j])
					{
						K[i, j] = values[i - 1] + K[i - 1, j - mana_costs[i - 1]];
					}
					else { K[i, j] = K[i - 1, j]; }
				}
			}
			double highestValue = K[n, avail_mana];
			int mana = avail_mana;
			for (int i = n; i > 0 && highestValue > 0 && mana >= 0; i--)
			{
				if (K[i - 1, mana] != highestValue)
				{
					mana = max(0, mana - mana_costs[i - 1]);
					highestValue = K[i, mana];
					return options[i - 1];
				}
			}
			return options[0];
		}

		// Determines the best possible attack-sequence by payoffs of each option
		public PlayerTask bestAttackOption(List<PlayerTask> options, List<double> values)
		{
			PlayerTask bestOption = options[0];
			double bestVaule = values[0];
			for (int i = 1; i < options.Count; i++)
			{
				if (values[i] > bestVaule)
				{
					bestOption = options[i];
					bestVaule = values[i];
				}
			}
			return bestOption;
		}

		//Helper to get the specific Minion entity of given task used for healing task, since you don't want to heal enemy minions it should be fine like this
		public SabberStoneCore.Model.Entities.Minion getBoardEntityfromTask(PlayerTask task, int target_id)
		{
			SabberStoneCore.Model.Entities.Minion target_entity = null;
			//check own board
			foreach (SabberStoneCore.Model.Entities.Minion minion in task.Target.Controller.BoardZone.GetAll())
			{
				if (target_id == minion.Id)
				{
					target_entity = minion;
					break;
				}
			}
			if (target_entity == null)
			{
				foreach (SabberStoneCore.Model.Entities.Minion minion in task.Controller.BoardZone.GetAll())
				{
					if (target_id == minion.Id)
					{
						target_entity = minion;
						break;
					}
				}
			}
			return target_entity;
		}
		//Handbuffs occuring on cards are not counted in the task.source.card values, so this is needed to get the actual / current stats like mana costs etc
		public SabberStoneCore.Model.Entities.IEntity getHandEntityfromTarget(PlayerTask task)
		{
			int target_id = task.Source.Id;
			SabberStoneCore.Model.Entities.IEntity target_entity = null;

			foreach (SabberStoneCore.Model.Entities.IEntity entity in task.Controller.HandZone.GetAll())
			{
				if (target_id == entity.Id)
				{
					target_entity = entity;
					break;
				}
			}
			return target_entity;
		}


		// Determines whether a certain damage source (like spells or weapons) can kill specific targets
		public bool canKill(int damage, SabberStoneCore.Model.Entities.Minion target)
		{
			return (damage > target.Health);
		}
		public bool canKill(int damage, SabberStoneCore.Model.Card target)
		{
			int health;
			target.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out health);
			return (damage > health);
		}

		//Determines the value of getting the target killed by specific damage, highest value will be achieved if damage is equal to the health of the target, assuming the damage will actual kill the target.
		public double get_killValue(int damage, SabberStoneCore.Model.Entities.Minion target)
		{
			return (double)target.Health / damage;
		}
		public double get_killValue(int damage, SabberStoneCore.Model.Card target)
		{
			int health;
			target.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out health);
			return (double)health / damage;
		}

		//Determines the value of a heal
		public double get_healValue(int healing, SabberStoneCore.Model.Entities.Minion target)
		{
			double value = 0;
			//only has value if the target is actually damaged
			if (target.Health < target.BaseHealth)
			{
				//the value then depends on the amount it is possibly healed and minions closer to death would be prefered to get healed
				// Base Value -	Factor for how heavy the target is damaged		-	Utility factor of the heal, highest value is reached if the total amount of healing can be achieved
				value = 2 * 1 - (double)(target.Health - 1 / target.BaseHealth) * min((double)(target.BaseHealth - target.Health) / healing, 1);
			}
			return value;
		}

		//Function to evaluate text of a card
		//ToDo: a lot
		// keywords if-otherwise / choose one
		public double evaluateText(PlayerTask option)
		{
			double value = 0.01;
			string text = option.Source.Card.Text.ToLower();
			//There are mostly 2 separators of effects used in card texts the wording "and" and the character '.', replace function is used to get a workaround here.
			string[] effects = text.Split(new char[] { '.' });
			// "\n" | "." separator for multiple effects
			// to all except dragons
			int damage = 0;
			foreach (string effect in effects)
			{
				string[] current_effect_snippet = effect.Split(new char[] { ' ', '-', '\n', '_' });

				//for simplicity: always play coin-like cards directly
				if (text.Contains("gain") && text.Contains("mana")) return 500;

				//never play a combo card without its combo effect
				if (text.Contains("combo") && option.Source.Controller.NumOptionsPlayedThisTurn == 0) return -1;

				//cards like Forgotten Torch or Elise
				if (text.Contains("shuffle")) value += 0.25;

				//catch a special case, since most "spend all mana" are 0 cost and grand high value but might be a bait
				if (text.Contains("spend") && text.Contains("all") && text.Contains("Mana"))
				{
					//Forbidden Flame
					if (text.Contains("deal") && option.HasTarget)
					{
						damage = option.Controller.RemainingMana;
						if (canKill(damage, option.Target.Card))
						{
							value += 1 + get_killValue(damage, option.Target.Card);
						}
					}
				}
				//Secrets somehow throws an exception ?
				else if (text.Contains("secret"))
				{
					if (option.Source.Card.Name.Contains("Bear")) value -= 500;
					else value += 1;
				}

				//Damage Spell
				else if (text.Contains("deal"))
				{
					foreach (string word in current_effect_snippet)
					{
						if (word.Contains("$"))
						{
							damage = Int32.Parse((word.Substring(word.IndexOf("$") + 1)));
							break;
						}
					}
					if (option.HasTarget)
					{
						if (option.Target.Controller == option.Controller) value = -1;
						else
						{
							if (option.Target.Card.Type == SabberStoneCore.Enums.CardType.MINION)
							{
								if (canKill(damage, option.Target.Card))
								{
									//Factor is determined by the damage per mana ratio to justify playing the card and the target selection factor
									value += (double)(damage / max(1, option.Source.Card.Cost)) * get_killValue(damage, option.Target.Card);
								}
							}
							else if (option.Target.Card.Type == SabberStoneCore.Enums.CardType.HERO)
							{
								//ToDo: add factor given by strategy
								value += (double)damage / max(option.Source.Card.Cost, 1);
							}
						}
					}
					//Assuming its an aoe spell
					else
					{
						SabberStoneCore.Model.Entities.Minion[] minions = option.Controller.Opponent.BoardZone.GetAll();
						int enemies_killed = 0;
						int total_damage = 0;
						foreach (SabberStoneCore.Model.Entities.Minion minion in minions)
						{
							//Better for control decks
							if (canKill(damage, minion))
							{
								enemies_killed++;
								total_damage += minion.Health;
							}
							else total_damage += damage;
						}
						if (minions.Length != 0) value = enemies_killed + (double)(total_damage / max(option.Source.Card.Cost, 1)) * (double)(enemies_killed / minions.Length);
						else value += -3;
					}
				}

				//Draw Spell
				else if (text.Contains("draw"))
				{
					bool next_is_draw_amount = false;
					int draw_amount = 0;
					foreach (string word in current_effect_snippet)
					{
						if (next_is_draw_amount)
						{
							//Value = 0 if controller would overdraw
							if (Int32.TryParse(word, out draw_amount)) value += max(0, 10 - (draw_amount + option.Controller.HandZone.Count)) * (double)draw_amount / max(option.Source.Card.Cost, 1);
							break;
						}
						if (word.Contains("draw")) next_is_draw_amount = true;
					}
					if (draw_amount == 0) value += 2 - (double)(option.Controller.HandZone.Count - 1) * 2 / 6;
				}

				//Get stats of the transformed or newly created token
				else if (text.Contains("transform"))
				{
					int new_atk, new_health = 0;
					foreach (string word in current_effect_snippet)
					{
						if (word.Contains("/") && !word.Contains("</b>"))
						{
							string substring = word.Substring(word.IndexOf("/") - 1);
							string[] tmp = word.Split("/");
							new_atk = Int32.Parse(tmp[0]);
							new_health = Int32.Parse(tmp[1]);
							break;
						}
					}
					//In theory every transform should have a target, but just to be sure to not throw an exception
					if (option.HasTarget)
					{
						int health, attack;
						option.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out health);
						option.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.ATK, out attack);
						value += (double)(attack - new_health + health - new_health) / option.Target.Card.Cost;
					}
				}

				//Cards like shadow word: Pain / Death or Assassinate
				else if (text.Contains("destroy") && option.HasTarget)
				{
					int health, attack;
					option.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.HEALTH, out health);
					option.Target.Card.Tags.TryGetValue(SabberStoneCore.Enums.GameTag.ATK, out attack);
					value += (double)option.Target.Card.Cost / option.Source.Card.Cost * (health + attack) / option.Target.Card.Cost;
				}

				//Keywords: Give -> Buffs (Hand, Hero, Target, Weapon) (+x/+y) +n Atk/health, Equip -> Weapon, Summon (by stats, if random hard coded 2), Restore (ähnlich deal), return to hand
			}




			//If weapon give +1/+1, otherwise equip 1/3 weapon
			//for each enemy minion 1/1 <b> charge
			//<b>Overload</b>c(1)
			//Deal $2-$3 <b>Overload (2)
			//<b> Choose one</b> 2dmg | two 1/1
			//Give a minion +2/+2 if beast draw card
			//Discard
			//deal $5 to all except Dragons
			/*
			// <b> Keywords: Freeze, Overload, Combo,Choose One, Secret, Spell Damage
				Overload</b> (overloaded_mana)
			// Keywords: Transform, Destroy, Deal, Give, Summon, Return to hand, Discard
				Transform into atk/health
				Deal $Damage
				Give +Value Health/Damge oder +atk/+health
				Summon atk/health
			*/
			return value;
		}
	}
}
