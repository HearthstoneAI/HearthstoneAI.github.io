using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using System.Linq;
using System.IO;
using SabberStoneCore.Enums;
using System.Xml.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	class BotAnonymousAuthors : AbstractAgent
	{

		// ADAPTABLE PARAMETER
		private int absoluteGames = 1000;           //absolute number of games being played
		private POGame.POGame poGame;
		private Random Rnd = new Random();

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			//Console.WriteLine(System.DateTime.Now);
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poG)
		{
			poGame = poG;
			List<PlayerTask> allOptions = poG.CurrentPlayer.Options();
			List<PlayerTask> filteredOptions = FilterOptions(allOptions);

			if (filteredOptions.Count < 1)
			{
				return poG.CurrentPlayer.Options()[0];
			}

			PlayerTask action = GetFaceHunterMove(filteredOptions);
			POGame.POGame pCopy = poG.getCopy();
			Dictionary<PlayerTask, POGame.POGame> simulation = TrySimulation(pCopy, filteredOptions);
			//Dictionary<PlayerTask, POGame.POGame> simulation = TryProcess(pCopy, filteredOptions);
			double currentReward = 0;
			double maxReward = Double.MinValue;

			//If the simulation fails, return the default action (facehuntermove)
			if (simulation.Count < 2)
			{
				return action;
			}

			//For each option look for the resulting state and calculate its reward
			foreach (PlayerTask opt in simulation.Keys)
			{
				bool contains = false;
				try
				{
					contains = simulation.ContainsKey(opt);
				}
				catch (Exception e)
				{
					currentReward = Double.MinValue;
				}
				if( contains )
				{ 
					POGame.POGame resultGame = simulation[opt];
					try
					{
						currentReward = GetReward(resultGame.CurrentPlayer);
					}
					catch (Exception e)
					{
						currentReward = Double.MinValue;
					}
				}
				else
				{
					currentReward = Double.MinValue;
				}				

				if (currentReward > maxReward)
				{
					maxReward = currentReward;
					action = opt;
				}

			}
			return action;
		}

		private List<PlayerTask> FilterOptions(List<PlayerTask> options)
		{
			// filter END_TURN of optional moves
			List<PlayerTask> filteredOptions = options.Where(
			x => x.PlayerTaskType == PlayerTaskType.MINION_ATTACK ||
			x.PlayerTaskType == PlayerTaskType.CHOOSE ||
			x.PlayerTaskType == PlayerTaskType.HERO_ATTACK ||
			x.PlayerTaskType == PlayerTaskType.HERO_POWER ||
			x.PlayerTaskType == PlayerTaskType.PLAY_CARD).ToList();

			return filteredOptions;
		}

		private Dictionary<PlayerTask, POGame.POGame> TryProcess(POGame.POGame game, List<PlayerTask> options)
		{
			Dictionary<PlayerTask, POGame.POGame> dict = new Dictionary<PlayerTask, POGame.POGame>();
			bool success = false;
			foreach( PlayerTask opt in options)
			{
				success = false;
				POGame.POGame gameCopy = game.getCopy();
				try
				{
					gameCopy.Process(opt);
					success = true;
				}
				catch
				{

				}
				if( success)
				{
					dict.Add(opt, gameCopy);
				}
			}
			return dict;
		}

		private Dictionary<PlayerTask, POGame.POGame> TrySimulation(POGame.POGame game, List<PlayerTask> options)
		{
			Dictionary<PlayerTask, POGame.POGame> simResults = new Dictionary<PlayerTask, POGame.POGame>();
			try
			{
				simResults = game.Simulate(options);
			}
			catch
			{
				Console.WriteLine("EXCEPTION");
				return simResults;
			}
			return simResults;
		}

		public PlayerTask GetFaceHunterMove(List<PlayerTask> options)
		{
			LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
				{
					minionAttacks.AddLast(task);
				}
			}
			if (minionAttacks.Count > 0)
				return minionAttacks.First.Value;

			PlayerTask summonMinion = null;
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
				{
					summonMinion = task;
				}
			}
			if (summonMinion != null)
				return summonMinion;

			else
				return options[0];
		}

		private double GetReward(SabberStoneCore.Model.Entities.Controller controller)
		{
			SabberStoneCoreAi.Score.FatigueScore scoring = new SabberStoneCoreAi.Score.FatigueScore();
			scoring.Controller = controller;
			int score = scoring.Rate();
			double r = Convert.ToDouble(score);
			return r;
		}

		public override void InitializeGame()
		{
		}

		public override void InitializeAgent()
		{
		}
	}
}
