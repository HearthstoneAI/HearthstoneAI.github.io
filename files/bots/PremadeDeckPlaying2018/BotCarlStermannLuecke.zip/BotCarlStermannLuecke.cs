using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	class BotCarlStermannLuecke : AbstractAgent
	{
		private Random Rnd = new Random();

		public override void InitializeAgent()
		{
		}

		public override void FinalizeAgent()
		{
			//Nothing to do here
		}

		public override void FinalizeGame()
		{
			//Nothing to do here
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			List<PlayerTask> options1 = new List<PlayerTask>();
			foreach (PlayerTask pt in options)
			{
				if (pt.Target != poGame.CurrentPlayer.Hero)
					options1.Add(pt);
			}
		
			return getBestMove(poGame, options1);
		}



		public override void InitializeGame()
		{
			//Nothing to do here
		}

		public PlayerTask getBestMove(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{

			PlayerTask summonMinion = null;
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
				{
					summonMinion = task;
				}
			}
			if (summonMinion != null)
				return summonMinion;

			LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
				{
					minionAttacks.AddLast(task);
				}
			}
			if (minionAttacks.Count > 0)
				return minionAttacks.First.Value;

			else
			{
				if (options.Count > 1 && options[0].PlayerTaskType == PlayerTaskType.END_TURN)
					return options[1];
				else
					return options[0];
			}
		}
		
	}
}
