﻿/***************************************************
 * File: CIGBot.cs                                 *
 * Developer:                                      *
 *     - Sebastian Schröder [Informatik(Bachelor)] *
 *     - Michelle Bieber    [Informatik(Master)]   *
 *                                                 *
 * Information: The CIGBot was created for the     *
 * "Computational Intelligence in Games"-course    *
 * exam requiremens in SS2018.                     *
 *                                                 *
 * Description: The CIGBot is a simple AI which    *
 * uses if-statements to simulate his behaviour.   *
 * More description are found in the code itself   *
 ***************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent;
using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Model;
using SabberStoneCore.Tasks.SimpleTasks;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Agent
{
	class BotSchroederBieber : AbstractAgent
	{
		public override void FinalizeAgent(){}
		public override void FinalizeGame(){}
		public override void InitializeAgent(){}
		public override void InitializeGame(){}

		public struct Info
		{
			public POGame.POGame poGame;
			public int opponentAttackStrength;
			public int myAttackStrength;
			public bool opponentHasEmptyBoardZone;
		}

		readonly string CoinID = "GAME_005";

		readonly string RenoJacksonID = "LOE_011";
		readonly string DirtyRatID = "CFM_790";
		readonly string DoomSayerID = "NEW1_021";
		readonly string AlexstraszaID = "EX1_561";
		readonly string MindControlTechID = "EX1_085";
		List<string> specialMinionCards = new List<string>();

		readonly string ArcaneBlastID = "AT_004";
		readonly string ForbiddenFlameID = "OG_086";
		readonly string ForgottenTorchID = "LOE_002";
		readonly string FireLandsPortalID = "KAR_076";
		readonly string FrostboltID = "CS2_024";
		readonly string BlizzardID = "CS2_028";
		List<string> specialSpellCards = new List<string>();

		bool onlyOneOfEachCard; // for Reno Jackson 

		bool IsInitialized = false;

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			if (IsInitialized == false)
				InitializeBot(poGame);

			Info info = new Info();
			info.poGame = poGame;
			info.opponentHasEmptyBoardZone = poGame.CurrentOpponent.BoardZone.Count == 0;
			info.myAttackStrength = GetAttackStrength(info.poGame.CurrentPlayer);
			info.opponentAttackStrength = GetAttackStrength(info.poGame.CurrentOpponent);

			Info coinInfo = new Info();

			PlayerTask bestTask = null;
			PlayerTask coinTask = null;
			PlayerTask bestTaskWithCoin = null;
			// Simulate poGame with coin and compare.
			if (poGame.CurrentPlayer.BaseMana > 2) // Do not use coin to early.
			{
				foreach (PlayerTask task in poGame.CurrentPlayer.Options())
				{
					if (task.HasSource
						&& task.Source.Card.Id == CoinID)
					{
						coinInfo.poGame = poGame.Simulate(new List<PlayerTask>() { task })[task];
						coinInfo.opponentHasEmptyBoardZone = coinInfo.poGame.CurrentOpponent.BoardZone.Count == 0;
						coinInfo.myAttackStrength = GetAttackStrength(coinInfo.poGame.CurrentPlayer);
						coinInfo.opponentAttackStrength = GetAttackStrength(coinInfo.poGame.CurrentOpponent);
						coinTask = task;
					}
				}
			}

			bestTask = GetBestMove(info);

			if (coinTask != null)
			{
				bestTaskWithCoin = GetBestMove(coinInfo);

				if (bestTaskWithCoin.HasSource
					&& bestTask.HasSource
					&& bestTaskWithCoin.Source.Card.Cost > bestTask.Source.Card.Cost)
				{
					bestTask = coinTask;
				}
			}

			return bestTask;
		}

		private void InitializeBot(POGame.POGame poGame)
		{
			onlyOneOfEachCard = true;
			for(int i = 0; i < poGame.CurrentPlayer.DeckCards.Count; ++i)
			{
				for (int j = 0; j < poGame.CurrentPlayer.DeckCards.Count; ++j)
				{
					if (i == j)
					{
						continue;
					}

					if(poGame.CurrentPlayer.DeckCards[i].Id == poGame.CurrentPlayer.DeckCards[j].Id)
					{
						onlyOneOfEachCard = false;
						break;
					}
				}
				if (onlyOneOfEachCard == false)
					break;
			}

			// Known cards of the competition which we hardcoded in the behaviour.
			specialMinionCards.Add(DirtyRatID);
			specialMinionCards.Add(DoomSayerID);
			specialMinionCards.Add(AlexstraszaID);
			if(onlyOneOfEachCard) specialMinionCards.Add(RenoJacksonID); // If false, use him as normal minion.
			specialMinionCards.Add(MindControlTechID);

			specialSpellCards.Add(ArcaneBlastID);
			specialSpellCards.Add(ForbiddenFlameID);
			specialSpellCards.Add(ForgottenTorchID);
			specialSpellCards.Add(FireLandsPortalID);
			specialSpellCards.Add(FrostboltID);
			specialSpellCards.Add(BlizzardID);

			IsInitialized = true;
		}

		public PlayerTask GetBestMove(Info info)
		{
			// If we can defeat the opponent with all attacks then we attack him with all we have.
			if(info.myAttackStrength >= info.poGame.CurrentOpponent.Hero.Health)
			{
				foreach(PlayerTask playertask in info.poGame.CurrentPlayer.Options())
				{
					if((playertask.PlayerTaskType == PlayerTaskType.MINION_ATTACK
							|| playertask.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
						&& playertask.Target == info.poGame.CurrentOpponent.Hero)
					{
						return playertask;
					}
				}
			}

			// Behaviour for each type of hero.
			PlayerTask task = null;
			bool aggressive = true;
			bool passive = false;
			switch (info.poGame.CurrentPlayer.HeroClass)
			{
				case CardClass.MAGE:
					task = PlayMinion(info, passive);		if (task != null) return task;
					task = MinionAttack(info, passive);		if (task != null) return task;
					task = UseHeroPower(info, passive);		if (task != null) return task;
					task = PlaySpell(info);					if (task != null) return task;
					task = UseHeroPower(info, aggressive);	if (task != null) return task;
					task = MinionAttack(info, aggressive);	if (task != null) return task;
					task = EquipWeapon(info);				if (task != null) return task;
					task = HeroAttack(info);				if (task != null) return task;
					break;

				case CardClass.WARRIOR:
					task = PlayMinion(info, aggressive);	if (task != null) return task;
					task = MinionAttack(info, passive);		if (task != null) return task;
					task = PlaySpell(info);					if (task != null) return task;
					task = UseHeroPower(info, passive);		if (task != null) return task;
					task = EquipWeapon(info);				if (task != null) return task;
					task = RandomAction(info);				if (task != null) return task; // to use weapon- and hero-buffs
					task = HeroAttack(info);				if (task != null) return task;
					task = MinionAttack(info, aggressive);	if (task != null) return task;
					break;

				default:
					task = PlayMinion(info, passive);		if (task != null) return task;
					task = MinionAttack(info, passive);		if (task != null) return task;
					task = PlaySpell(info);					if (task != null) return task;
					task = UseHeroPower(info, passive);		if (task != null) return task;
					task = EquipWeapon(info);				if (task != null) return task;
					task = HeroAttack(info);				if (task != null) return task;
					task = MinionAttack(info, aggressive);	if (task != null) return task;
					break;
			}

			// End your turn if no other task was useful.
			return info.poGame.CurrentPlayer.Options()[0];
		}

		private PlayerTask RandomAction(Info info)
		{
			if (info.poGame.CurrentPlayer.Options().Count == 1)
				return null;

			Random random = new Random();
			List<PlayerTask> tasks = new List<PlayerTask>();

			foreach(PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if(task.PlayerTaskType != PlayerTaskType.HERO_ATTACK && task.PlayerTaskType != PlayerTaskType.END_TURN)
				{
					tasks.Add(task);
				}
			}

			if (tasks.Count == 0)
				return null;

			return tasks[random.Next(0, tasks.Count)];
		}

		private PlayerTask EquipWeapon(Info info)
		{
			if (info.poGame.CurrentPlayer.Hero.Weapon != null)
				return null;

			PlayerTask bestWeaponTask = null;

			foreach(PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if(task.PlayerTaskType == PlayerTaskType.PLAY_CARD && task.Source.Card.Type == CardType.WEAPON)
				{
					if(bestWeaponTask == null || bestWeaponTask.Source.Card.Tags[GameTag.ATK] < bestWeaponTask.Source.Card.Tags[GameTag.ATK])
					{
						bestWeaponTask = task;
					}
				}
			}

			return bestWeaponTask;
		}

		private PlayerTask HeroAttack(Info info)
		{
			// Attack hero of opponent if he dies.
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK
					&& task.Target == info.poGame.CurrentOpponent.Hero
					&& info.poGame.CurrentPlayer.Hero.AttackDamage >= info.poGame.CurrentOpponent.Hero.Health)
				{
					return task;
				}
			}

			// Attack minion of opponent if this minion dies after this attack and we do not loose through the after-damage.
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK
					&& task.Target != info.poGame.CurrentOpponent.Hero
					&& info.poGame.CurrentPlayer.Hero.AttackDamage >= (task.Target as Minion).Health
					&& info.poGame.CurrentPlayer.Hero.Health > (task.Target as Minion).AttackDamage)
				{
					return task;
				}
			}

			// Attack hero of opponent.
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK
					&& task.Target == info.poGame.CurrentOpponent.Hero)
				{
					return task;
				}
			}
			return null;
		}
		
		private PlayerTask MinionAttack(Info info, bool aggressive)
		{
			List<PlayerTask> minionAttacks = new List<PlayerTask>();
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK
					&& task.Target.Controller == info.poGame.CurrentOpponent)
				{
					minionAttacks.Add(task);
				}
			}

			if(minionAttacks.Count == 0)
			{
				return null;
			}

			// Attack hero of opponent if boardzone of opponent is empty.
			if (info.opponentHasEmptyBoardZone)
			{
				foreach (PlayerTask task in minionAttacks)
				{
					if (task.Target == info.poGame.CurrentOpponent.Hero)
					{
						return task;
					}
				}
			}

			// Attack minion of opponent if attacking minion survives and minion of opponent dies and attack-damage:health ratio is 1:1.
			foreach (PlayerTask task in minionAttacks)
			{
				if (task.Target != info.poGame.CurrentOpponent.Hero
					&& (task.Source as Minion).AttackDamage == (task.Target as Minion).Health
					&& (task.Source as Minion).Health > (task.Target as Minion).AttackDamage)
				{
					return task;
				}
			}

			// Attack minion of opponent if attacking minion survives and minion of opponent dies.
			foreach (PlayerTask task in minionAttacks)
			{
				if (task.Target != info.poGame.CurrentOpponent.Hero
					&& (task.Source as Minion).AttackDamage >= (task.Target as Minion).Health
					&& (task.Source as Minion).Health > (task.Target as Minion).AttackDamage)
				{
					return task;
				}
			}

			// Attack minion of opponent if minion of opponent dies.
			if (aggressive == true)
			{
				foreach (PlayerTask task in minionAttacks)
				{
					if (task.Target != info.poGame.CurrentOpponent.Hero
						&& (task.Source as Minion).AttackDamage >= (task.Target as Minion).Health)
					{
						return task;
					}
				}

				// Attack minion of opponent with lowest AttackDamage if attacking minion survives.
				PlayerTask bestMinionAttackTask = null;
				foreach (PlayerTask task in minionAttacks)
				{
					if (task.Target != info.poGame.CurrentOpponent.Hero
						&& (task.Target as Minion).AttackDamage < (task.Source as Minion).Health)
					{
						if (bestMinionAttackTask == null
							|| (bestMinionAttackTask.Target as Minion).AttackDamage > (task.Target as Minion).AttackDamage)
						{
							bestMinionAttackTask = task;
						}
					}
				}
				if (bestMinionAttackTask != null)
					return bestMinionAttackTask;
			}

			// Attack hero of opponent (if you can not kill any minions of the opponent).
			foreach (PlayerTask task in minionAttacks)
			{
				if (task.Target == info.poGame.CurrentOpponent.Hero)
				{
					return task;
				}
			}

			return null;
		}

		private PlayerTask PlayMinion(Info info, bool aggressive)
		{
			PlayerTask bestMinionAsTask = null;

			// Filter hardcoded minions.
			List<PlayerTask> minions = new List<PlayerTask>();
			List<PlayerTask> specialMinions = new List<PlayerTask>();
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD
					&& task.Source.Card.Type == CardType.MINION)
				{
					bool isSpecial = false;
					foreach(string specialID in specialMinionCards)
					{
						if(specialID == task.Source.Card.Id)
						{
							isSpecial = true;
							break;
						}
					}
					if(isSpecial)
					{
						specialMinions.Add(task);
					}
					else
					{
						minions.Add(task);
					}
				}
			}

			int priority = 0;
			foreach(PlayerTask task in specialMinions)
			{
				// Play Reno Jackson if the enemy-strength is higher than your health or your health is very low.
				if ((task.Source as Minion).Card.Id == RenoJacksonID)
				{
					if ((info.poGame.CurrentPlayer.Hero.Health < 8
						|| info.poGame.CurrentPlayer.Hero.Health <= info.opponentAttackStrength))
					{
						if(priority < 4)
						{
							priority = 4;
							bestMinionAsTask = task;
						}
					}
				}
				// Play Alexstrasza on opponent if enemy has more than 15 health or on yourself if your health is low.
				else if ((task.Source as Minion).Card.Id == AlexstraszaID)
				{
					if (info.poGame.CurrentOpponent.Hero.Health > 15
						|| info.poGame.CurrentPlayer.Hero.Health < 8)
					{
						if (priority < 3)
						{
							priority = 3;
							bestMinionAsTask = task;
						}
					}
				}
				// Play MindControlTech if opponent has more than 3 minions on the boardzone.
				else if ((task.Source as Minion).Card.Id == MindControlTechID)
				{
					if (info.poGame.CurrentOpponent.BoardZone.Count > 3)
					{
						if (priority < 2)
						{
							priority = 2;
							bestMinionAsTask = task;
						}
					}
				}
				// Play DoomSayer if boardzone of opponent is not empty but yours.
				else if ((task.Source as Minion).Card.Id == DoomSayerID)
				{
					if (info.poGame.CurrentOpponent.BoardZone.Count > 0
						&& info.poGame.CurrentPlayer.BoardZone.Count == 0)
					{
						if (priority < 1)
						{
							priority = 1;
							bestMinionAsTask = task;
						}
					}
					else if (info.poGame.CurrentOpponent.BoardZone.Count > 3
						&& info.poGame.CurrentPlayer.BoardZone.Count == 0)
					{
						if (priority < 3)
						{
							priority = 3;
							bestMinionAsTask = task;
						}
					}
				}
			}
			if (bestMinionAsTask != null)
			{
				return bestMinionAsTask;
			}

			foreach (PlayerTask task in minions)
			{
				if(aggressive)
				{
					// Play the card with highest value. value = attack-damage.
					if (bestMinionAsTask == null
						|| (bestMinionAsTask.Source as Minion).AttackDamage < (task.Source as Minion).AttackDamage)
					{
						bestMinionAsTask = task;
					}
				}
				else
				{
					// Play the card with highest value. value = attack-damage + health.
					if (bestMinionAsTask == null
						|| ((bestMinionAsTask.Source as Minion).AttackDamage + (bestMinionAsTask.Source as Minion).Health) < ((task.Source as Minion).AttackDamage + (task.Source as Minion).Health))
					{
						bestMinionAsTask = task;
					}
				}
			}
			if(bestMinionAsTask != null)
			{
				return bestMinionAsTask;
			}

			priority = 0;
			foreach (PlayerTask task in specialMinions)
			{
				// Play MindControlTech if your boardzone is empty and you have no other minions left.
				if ((task.Source as Minion).Card.Id == MindControlTechID)
				{
					if (info.poGame.CurrentPlayer.BoardZone.Count > 0)
					{
						if (priority < 2)
						{
							priority = 2;
							bestMinionAsTask = task;
						}
					}
				}
				// Play DirtyRat only when you have no options left in late-game.
				else if ((task.Source as Minion).Card.Id == DirtyRatID)
				{
					if (info.poGame.CurrentPlayer.BaseMana >= 7 && bestMinionAsTask == null)
					{
						bestMinionAsTask = task;
					}
				}
			}

			return bestMinionAsTask;
		}

		private PlayerTask PlaySpell(Info info)
		{
			List<PlayerTask> complexSpells = new List<PlayerTask>();
			List<PlayerTask> specialCards = new List<PlayerTask>();
			List<PlayerTask> damageSpells = new List<PlayerTask>();
			List<PlayerTask> healSpells = new List<PlayerTask>();
			List<PlayerTask> transformSpells = new List<PlayerTask>();
			List<PlayerTask> drawSpells = new List<PlayerTask>();

			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD
					&& task.Source.Card.Type == CardType.SPELL)
				{
					bool isSpecial = false;
					foreach (string specialID in specialSpellCards)
					{
						if (specialID == task.Source.Card.Id)
						{
							specialCards.Add(task);
							isSpecial = true;
							break;
						}
					}

					if (isSpecial)
						continue;

					if (task.Source.Card.Power != null
						&& task.Source.Card.Power.PowerTask != null)
					{
						bool isHealTask = false;
						bool isDamageTask = false;
						bool isDrawTask = false;
						bool isTransformTask = false;

						//Check spellTask
						if (task.Source.Card.Power.PowerTask.ToString() == "DamageTask") isDamageTask = true;
						else if (task.Source.Card.Power.PowerTask.ToString() == "HealTask") isHealTask = true;
						else if (task.Source.Card.Power.PowerTask.ToString() == "TransformTask") isTransformTask = true;
						else if (task.Source.Card.Power.PowerTask.ToString() == "DrawTask") isDrawTask = true;
						else
						{
							POGame.POGame newPoGame = info.poGame.Simulate(new List<PlayerTask>() { task })[task];
							foreach (PlayerTask newTask in newPoGame.CurrentPlayer.Options())
							{
								if (task.HasTarget && newTask.HasTarget
									&& task.Target == newTask.Target
									&& task.Source == newTask.Source)
								{
									// Check damage behaviour
									if(((task.Target is Minion) && (task.Target as Minion).Health > (newTask.Target as Minion).Health)
										|| (task.Target is Hero) && (task.Target as Hero).Health > (newTask.Target as Hero).Health)
									{
										if(task.Target.Controller == info.poGame.CurrentOpponent)
											isDamageTask = true;
									}

									// Check heal behaviour
									if (((task.Target is Minion) && (task.Target as Minion).Health < (newTask.Target as Minion).Health)
										|| (task.Target is Hero) && (task.Target as Hero).Health < (newTask.Target as Hero).Health)
									{
										if (task.Target.Controller == info.poGame.CurrentPlayer)
											isHealTask = true;
									}
								}

								// Check Draw behaviour
								if (info.poGame.CurrentPlayer.HandZone.Count < newPoGame.CurrentPlayer.HandZone.Count)
								{
									isDrawTask = true;
								}
							}
						}

						if (isDamageTask) damageSpells.Add(task);
						else if (isHealTask) healSpells.Add(task);
						else if (isTransformTask) transformSpells.Add(task);
						else if (isDrawTask) drawSpells.Add(task);
						else
						{
							if (task.HasTarget == false || task.Target.Controller == info.poGame.CurrentOpponent)
								complexSpells.Add(task);
						}
					}
				}
			}

			PlayerTask bestSpellAsTask = null;
			int bestAmount = 0;

			// Play damage Spell on hero of opponent if he dies.
			foreach (PlayerTask task in damageSpells)
			{
				int damage = (task.Source.Card.Power.PowerTask as DamageTask).Amount;
				if (task.Target == info.poGame.CurrentOpponent.Hero
					&& (task.Target as Hero).Health <= damage)
				{
					return task;
				}
			}

			// Play Damage-Spell-Card on minion of opponent
			foreach (PlayerTask task in damageSpells)
			{
				int damage = (task.Source.Card.Power.PowerTask as DamageTask).Amount;
				if(task.Target != null
					&& task.Target.Controller == info.poGame.CurrentOpponent
					&& (task.Target is Minion)
					&& (task.Target as Minion).Health >= damage)
				{
					if (bestSpellAsTask == null || (bestSpellAsTask.Target as Minion).Health - damage > (task.Target as Minion).Health - damage)
					{
						bestSpellAsTask = task;
					}
				}
			}
			if(bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			bestAmount = 0;
			// Play damage spell on hero of oppinion.
			foreach (PlayerTask task in damageSpells)
			{
				int damage = (task.Source.Card.Power.PowerTask as DamageTask).Amount;
				if (task.Target == info.poGame.CurrentOpponent.Hero)
				{
					if (bestSpellAsTask == null || bestAmount < damage)
					{
						bestSpellAsTask = task;
						bestAmount = damage;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			// Play Damage-Spell-Card on opponent
			foreach (PlayerTask task in damageSpells)
			{
				if (task.HasTarget == false)
				{
					return task;
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			bestAmount = 0;
			// Play heal spell on your hero.
			foreach (PlayerTask task in healSpells)
			{
				int heal = (task.Source.Card.Power.PowerTask as HealTask).Amount;
				if (info.poGame.CurrentPlayer.Hero.Health < 8
					&& task.Target == info.poGame.CurrentPlayer.Hero)
				{
					if (bestSpellAsTask == null || bestAmount < heal)
					{
						bestSpellAsTask = task;
						bestAmount = heal;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			// Play heal spell on your damaged minion.
			foreach (PlayerTask task in healSpells)
			{
				if(task.Target == null)
				{
					return task;
				}
				if (task.Target.Controller == info.poGame.CurrentPlayer
					&& task.Target is Minion
					&& (task.Target as Minion).Health < (task.Target as Minion).BaseHealth)
				{
					int healthDifference = (task.Target as Minion).BaseHealth - (task.Target as Minion).Health;
					if (bestSpellAsTask == null || bestAmount < healthDifference)
					{
						bestSpellAsTask = task;
						bestAmount = healthDifference;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			bestAmount = 0;
			// Play transform card on the strongest minion of opponent
			foreach (PlayerTask task in transformSpells)
			{
				if (task.Target.Controller == info.poGame.CurrentOpponent
					&& task.Target is Minion
					&& (task.Target as Minion).Health + (task.Target as Minion).AttackDamage > 8)
				{
					int strength = (task.Target as Minion).Health + (task.Target as Minion).AttackDamage;
					if (bestSpellAsTask == null || bestAmount < strength)
					{
						bestSpellAsTask = task;
						bestAmount = strength;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			// Play draw card if handzone.count < 4
			foreach (PlayerTask task in drawSpells)
			{
				if (info.poGame.CurrentPlayer.HandZone.Count < 4)
				{
					return task;
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			bestAmount = 0;
			foreach (PlayerTask task in specialCards)
			{
				// Play Blizzard if opponent has more then 2 minions on board.
				if (task.Source.Card.Id == "CS2_028")
				{
					if (info.poGame.CurrentOpponent.BoardZone.Count > 2)
					{
						return task;
					}
				}
			}

			foreach (PlayerTask task in specialCards)
			{
				// Play Frostbolt against strongest minion of opponent.
				if (task.Source.Card.Id == "CS2_024")
				{
					if (task.Target.Controller == info.poGame.CurrentOpponent
						&& task.Target != info.poGame.CurrentOpponent.Hero)
					{
						if (bestSpellAsTask == null
							|| (bestSpellAsTask.Target as Minion).Health + (bestSpellAsTask.Target as Minion).AttackDamage < (task.Target as Minion).Health + (task.Target as Minion).AttackDamage)
							bestSpellAsTask = task;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			foreach (PlayerTask task in specialCards)
			{
				// Play Frostbolt against hero of opponent.
				if (task.Source.Card.Id == "CS2_024")
				{
					if (task.Target == info.poGame.CurrentOpponent.Hero)
					{
						return task;
					}
				}
			}

			foreach (PlayerTask task in specialCards)
			{
				// Play Forgotten Torch or Firelands Portal to damage the hero of opponent.
				if (task.Source.Card.Id == "LOE_002" || task.Source.Card.Id == "KAR_076")
				{
					if (task.Target == info.poGame.CurrentOpponent.Hero)
					{
						return task;
					}
				}
			}

			foreach (PlayerTask task in specialCards)
			{
				// Play Forbidden Flame if you can defeat a minion of opponent.
				if (task.Source.Card.Id == "OG_086")
				{
					if(task.Target.Controller == info.poGame.CurrentOpponent
						&& info.poGame.CurrentPlayer.RemainingMana >= (task.Target as Minion).Health)
					{
						if (bestSpellAsTask == null
							|| (bestSpellAsTask.Target as Minion).Health + (bestSpellAsTask.Target as Minion).AttackDamage < (task.Target as Minion).Health + (task.Target as Minion).AttackDamage)
							bestSpellAsTask = task;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			foreach (PlayerTask task in specialCards)
			{
				// Play Arcane Blast if you can defeat a minion of opponent.
				if (task.Source.Card.Id == "AT_004")
				{
					if (task.Target.Controller == info.poGame.CurrentOpponent
						&& info.poGame.CurrentPlayer.RemainingMana >= (task.Target as Minion).Health)
					{
						if (bestSpellAsTask == null
							|| (bestSpellAsTask.Target as Minion).Health + (bestSpellAsTask.Target as Minion).AttackDamage < (task.Target as Minion).Health + (task.Target as Minion).AttackDamage)
							bestSpellAsTask = task;
					}
				}
			}
			if (bestSpellAsTask != null)
			{
				return bestSpellAsTask;
			}

			// Play complex (taskList) card randomly on opponent
			if (complexSpells.Count > 0)
			{
				Random random = new Random();
				return complexSpells[random.Next(0, complexSpells.Count)];
			}

			return bestSpellAsTask;
		}

		private PlayerTask UseHeroPower(Info info, bool aggressive)
		{
			// aggressive == false := Attack only if target can die.
			// aggressive == true := Attack the best target.

			List<PlayerTask> heropower = new List<PlayerTask>();
			foreach (PlayerTask task in info.poGame.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
				{
					heropower.Add(task);
				}
			}

			if (heropower.Count == 0)
			{
				return null;
			}

			PlayerTask bestTargetAsTask = null;
			switch(info.poGame.CurrentPlayer.HeroClass)
			{
				case CardClass.MAGE:
					// Attack minion of opponent with 1 health left which has the highest attack damage.
					foreach (PlayerTask task in heropower)
					{
						if (task.Target is Minion
							&& (task.Target as Minion).Controller == info.poGame.CurrentOpponent
							&& (task.Target as Minion).Health == 1)
						{
							if (bestTargetAsTask == null
								|| (bestTargetAsTask.Target as Minion).AttackDamage < (task.Target as Minion).AttackDamage)
							{
								bestTargetAsTask = task;
							}
						}
					}
					if (bestTargetAsTask != null)
					{
						return bestTargetAsTask;
					}

					if(!aggressive)
					{
						break;
					}

					// Attack hero of opponent.
					foreach (PlayerTask task in heropower)
					{
						if (task.Target == info.poGame.CurrentOpponent.Hero)
						{
							return task;
						}
					}

					// Attack enemy minion with highest attack damage
					foreach (PlayerTask task in heropower)
					{
						if (task.Target is Minion
							&& (task.Target as Minion).Controller == info.poGame.CurrentOpponent)
						{
							if (bestTargetAsTask == null
								|| (bestTargetAsTask.Target as Minion).AttackDamage < (task.Target as Minion).AttackDamage)
							{
								bestTargetAsTask = task;
							}
						}
					}

					if (bestTargetAsTask != null)
					{
						return bestTargetAsTask;
					}
					break;

				case CardClass.PRIEST:
					// Heal your damaged minion with the most damage.
					foreach (PlayerTask task in heropower)
					{
						if (task.Target is Minion
							&& (task.Target as Minion).Controller == info.poGame.CurrentPlayer
							&& (task.Target as Minion).Health < (task.Target as Minion).BaseHealth)
						{
							if (bestTargetAsTask == null
								|| (bestTargetAsTask.Target as Minion).BaseHealth - (bestTargetAsTask.Target as Minion).Health < (task.Target as Minion).BaseHealth - (task.Target as Minion).Health)
							{
								bestTargetAsTask = task;
							}
						}
					}

					if (bestTargetAsTask != null)
					{
						return bestTargetAsTask;
					}

					// Heal your hero.
					foreach (PlayerTask task in heropower)
					{
						if (task.Target == info.poGame.CurrentPlayer.Hero)
						{
							return task;
						}
					}
					break;

				case CardClass.WARLOCK:
					// Use power only when enough health is left.
					foreach (PlayerTask task in heropower)
					{
						if (info.poGame.CurrentPlayer.Hero.Health > 8 && info.poGame.CurrentPlayer.DeckZone.Count > 10 && info.poGame.CurrentPlayer.HandZone.Count < 4)
						{
							return task;
						}
					}
					break;

				default:
					// Just use the power if possible!
					foreach (PlayerTask task in heropower)
					{
						return task;
					}
					break;
			}

			return null;
		}

		private int GetAttackStrength(Controller controller)
		{
			int value = 0;
			foreach(Minion minion in controller.BoardZone)
			{
				if (minion.CanAttack
					&& !minion.CantAttackHeroes)
				{
					value += minion.AttackDamage;
				}
			}

			value += controller.Hero.AttackDamage;
			return value;
		}
	}
}
