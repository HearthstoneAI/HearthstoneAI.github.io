﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;



namespace SabberStoneCoreAi.Agent.Anonymous
{
	public enum State
	{
		Choose,		// After card played
		EndTurn,	// -
		Attack,		// Attack with minions and hero
		SpendMana,	// Play card and use hero-power
		Mulligan	// Start of the game
	}

	class BotAnonymousAuthor : AbstractAgent
	{
		private Random Rnd = new Random();
		private State state = State.Mulligan;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			return getBestMove(poGame, options);
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
			state = State.SpendMana;
		}

		public PlayerTask getBestMove(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			//List<PlayerTask> Options = poGame.CurrentPlayer.Options();
			//IPlayable[] OwnHand = poGame.CurrentPlayer.HandZone.GetAll();
			//IPlayable[] OwnDeck = poGame.CurrentPlayer.DeckZone.GetAll();
			//Minion[] OwnBoard = poGame.CurrentPlayer.BoardZone.GetAll();
			//Minion[] OpponentsBoard = poGame.CurrentOpponent.BoardZone.GetAll();

			//List<PlayerTask> chooseTasks = new List<PlayerTask>();
			//List<PlayerTask> concedeTasks = new List<PlayerTask>();
			//List<PlayerTask> endTurnTasks = new List<PlayerTask>();
			//List<PlayerTask> heroAttackTasks = new List<PlayerTask>();
			//List<PlayerTask> heroPowerTasks = new List<PlayerTask>();
			//List<PlayerTask> minionAttackTasks = new List<PlayerTask>();
			//List<PlayerTask> playCardTasks = new List<PlayerTask>();

			//foreach (PlayerTask task in Options)
			//{
			//	if (task.PlayerTaskType == PlayerTaskType.CHOOSE)
			//		chooseTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.CONCEDE)
			//		concedeTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.END_TURN)
			//		endTurnTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
			//		heroAttackTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
			//		heroPowerTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK)
			//		minionAttackTasks.Add(task);
			//	if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
			//		playCardTasks.Add(task);
			//}

			PlayerTask decision = null;

			while (true)
			{
				switch (state)
				{
					case State.Mulligan: { decision = mulligan(poGame, options); break; }
					case State.SpendMana: { decision = spendMana(poGame, options); break; }
					case State.Attack: { decision = attack(poGame, options); break; }
					case State.EndTurn: { state = State.SpendMana; return options[0]; }
					default: { break; }
				}

				if (decision != null) break;
			}

			return decision;
		}

		public PlayerTask mulligan(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			poGame.CurrentPlayer.MulliganState = SabberStoneCore.Enums.Mulligan.WAITING;


			IPlayable[] OwnHand = poGame.CurrentPlayer.HandZone.GetAll();

			List<PlayerTask> chooseTasks = new List<PlayerTask>();

			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.CHOOSE)
					chooseTasks.Add(task);

			}
			return null;
		}

		public PlayerTask spendMana(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			List<PlayerTask> Options = poGame.CurrentPlayer.Options();
			IPlayable[] OwnHand = poGame.CurrentPlayer.HandZone.GetAll();
			IPlayable[] OwnDeck = poGame.CurrentPlayer.DeckZone.GetAll();
			Minion[] OpponentsBoard = poGame.CurrentOpponent.BoardZone.GetAll();

			List<PlayerTask> heroPowerTasks = new List<PlayerTask>();
			List<PlayerTask> playCardTasks = new List<PlayerTask>();
			List<PlayerTask> chooseTasks = new List<PlayerTask>();

			foreach (PlayerTask task in Options)
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
					heroPowerTasks.Add(task);
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
					playCardTasks.Add(task);
				if (task.PlayerTaskType == PlayerTaskType.CHOOSE)
					chooseTasks.Add(task);
			}

			foreach (PlayerTask task in chooseTasks)
			{
				return task;
			}
			if (poGame.CurrentPlayer.HeroClass != SabberStoneCore.Enums.CardClass.WARLOCK)
			{
				if (heroPowerTasks.Count == 0 && playCardTasks.Count == 0)
				{
					state = State.Attack;
					return null;
				}
			}
			else
			{
				if (playCardTasks.Count == 0)
				{
					state = State.Attack;
					return null;
				}
			}

			if (poGame.CurrentPlayer.Hero.Weapon == null)
			{
				foreach (PlayerTask task in playCardTasks)
				{
					if (task.Source.Card.Type == SabberStoneCore.Enums.CardType.WEAPON)
					{
						return task;
					}
				}
			}
			foreach (PlayerTask task in playCardTasks)
			{
				if (task.Source.Card.Type == SabberStoneCore.Enums.CardType.MINION)
				{
					if (task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.CHARGE))
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.CHARGE] == 1)
						{
							return task;
						}
					}
				}
			}

			foreach (PlayerTask task in playCardTasks)
			{
				if (task.Source.Card.Type == SabberStoneCore.Enums.CardType.MINION)
				{
					if (task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.TAUNT))
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1)
						{
							return task;
						}
					}
					
				}
			}

			PlayerTask card = null;

			foreach (PlayerTask task in playCardTasks)
			{
				if (task.Source.Card.Type == SabberStoneCore.Enums.CardType.MINION)
				{
					if (!task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.COST)) return task;
					if (card == null)
						card = task;
					else
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.COST] > card.Source.Card.Tags[SabberStoneCore.Enums.GameTag.COST])
						{
							 card = task;
						}
					}					
				}
			}

			if (card == null)
			{
				foreach (PlayerTask task in playCardTasks)
				{
					if (!task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.COST)) return task;
					if (card == null) card = task;
					else
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.COST] > card.Source.Card.Tags[SabberStoneCore.Enums.GameTag.COST])
						{
							 card = task;
						}
					}
				}

				if (card != null)
					return card;
				if (poGame.CurrentPlayer.HeroClass != SabberStoneCore.Enums.CardClass.WARLOCK)
				{
					return heroPowerTasks[0];
				}
				else
				{
					return null;
				}
			}
			else
			{
				return card;
			}
				
		}

		public PlayerTask attack(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{

			List<PlayerTask> Options = poGame.CurrentPlayer.Options();
			Minion[] OwnBoard = poGame.CurrentPlayer.BoardZone.GetAll();
			Minion[] OpponentsBoard = poGame.CurrentOpponent.BoardZone.GetAll();

			List<PlayerTask> heroAttackTasks = new List<PlayerTask>();
			List<PlayerTask> minionAttackTasks = new List<PlayerTask>();
			//List<PlayerTask> combined = new List<PlayerTask>(heroAttackTasks);
			//combined.AddRange(minionAttackTasks);

			foreach (PlayerTask task in Options)
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
					heroAttackTasks.Add(task);
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK)
					minionAttackTasks.Add(task);
			}

			foreach (PlayerTask task in heroAttackTasks)
			{
				if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
				{
					if (poGame.CurrentPlayer.Hero.AttackDamage >= task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH] && poGame.CurrentPlayer.Hero.Health > task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.ATK])
					{
						return task;
					}
				}
				else
				{
					if (poGame.CurrentPlayer.Hero.AttackDamage >= task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH])
					{
						return task;
					}
				}
			}

			foreach (PlayerTask task in minionAttackTasks)
			{
				if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
				{
					if (task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.ATK] >= task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH] && task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH] > task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.ATK])
						{
							return task;
						}
					}
				}
				else
				{
					if (task.Source.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
					{
						if (task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.ATK] >= task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH])
						{
							return task;
						}
					}
				}
			}

			foreach (PlayerTask task in heroAttackTasks)
			{
				if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.TAUNT))
				{
					if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
					{
						if (task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1 && poGame.CurrentPlayer.Hero.Health > task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.ATK])
						{
							return task;
						}
					}
					else
					{
						if(task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1)
						{
							return task;
						}
					}
				}
			}

			foreach (PlayerTask task in minionAttackTasks)
			{
				if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.TAUNT))
				{
					if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.ATK))
					{
						if (task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1 && task.Source.Card.Tags[SabberStoneCore.Enums.GameTag.HEALTH] > task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.ATK])
						{
							return task;
						}
					}
					else
					{
						if (task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1)
						{
							return task;
						}
					}
				}
			}

			foreach (PlayerTask task in minionAttackTasks)
			{
				if (task.Target.Card.Tags.ContainsKey(SabberStoneCore.Enums.GameTag.TAUNT))
				{
					if (task.Target.Card.Tags[SabberStoneCore.Enums.GameTag.TAUNT] == 1)
					{
						return task;
					}
				}
			}
			
			foreach (PlayerTask task in minionAttackTasks)
			{
				if (task.Target == poGame.CurrentOpponent.Hero)
				{
					return task;
				}
			}

			foreach (PlayerTask task in heroAttackTasks)
			{
				if (task.Target == poGame.CurrentOpponent.Hero)
				{
					return task;
				}
			}

			state = State.EndTurn;

			return null;
		}

	}
}
