﻿using System;
using System.Collections.Generic;
using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;

namespace SabberStoneCoreAi.src.Agent
{
	class TammiLuca : AbstractAgent
	{
		private Random Rnd = new Random();
		int mana;

//----------------------------- override agent methods ---------------------------------
		public override void InitializeAgent()
		{

		}

		public override void InitializeGame()
		{
			mana = 0;
		}

		public override void FinalizeAgent()
		{
			//throw new NotImplementedException();
		}

		public override void FinalizeGame()
		{
			//throw new NotImplementedException();
		}

//----------------------------- player getmove method ---------------------------------------
		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();

			/*
			bool killable = false;

			killable = opponentKillable(poGame);

			//if killable = true -> kill opponent by attacking opponent hero with every minion
			if (killable)
			{
				LinkedList<PlayerTask> minionAttacks = getMinionAttackList(poGame, options);
				if (minionAttacks.Count > 0)
				{
					return getMinionAttackList(poGame, options).First.Value;
				}
			}
			else if (ownPlayerCanAttack(poGame)) //if not in killing range, do smart trades
			{*/
				if (!poGame.CurrentOpponent.BoardZone.IsEmpty) //if opponent board has minions
				{
					if (doSmartTrades(poGame, options).Count > 0)
					{
						return doSmartTrades(poGame, options).First.Value;
					}
				}
				//else //else attack opponent hero directly
				//{
				
					LinkedList<PlayerTask> minionAttacksOppHero = getMinionAttackList(poGame, options);
					if (minionAttacksOppHero.Count > 0)
					{
						return minionAttacksOppHero.First.Value;
					}

			/*
		}

	 }
	 */



				PlayerTask minionSummon = summonBestMinion(poGame, options);
				if(minionSummon != null)
				{
					return minionSummon;
				}

				//PlayerTask aggressiveSpell = playAggressiveSpell(poGame, options);
				//if(aggressiveSpell != null)
				PlayerTask spell = playSpell(poGame, options);
				if(spell != null)
				{
					return spell;
				}

			PlayerTask heroPower = useHeroPower(poGame, options);
			if(heroPower != null)
			{
				return heroPower;
			}

			PlayerTask attackingHero = getAttackingHeroPowerTask(poGame, options);
			if (attackingHero != null)
			{
				return attackingHero;
			}

			if (mana < 10)
			{
				++mana;
			}
			//after all other moves, end turn
			foreach(PlayerTask task in options)
			{
				if(task.PlayerTaskType == PlayerTaskType.END_TURN)
				{
					return task;
				}
			}
			return options[0]; // backup if nothing works
		}

//----------------------------- systematic task methods ---------------------------------------

		
		private PlayerTask summonBestMinion(POGame.POGame poGame, List<PlayerTask> options)
		{
			int availableMana = mana - poGame.CurrentPlayer.UsedMana;
			PlayerTask minionWithHighestPlayableCost = null;
			int highestPlayableCost = -1;

			foreach(PlayerTask task in options)
			{
				if(task.PlayerTaskType == PlayerTaskType.PLAY_CARD && task.Source.Card.Type == CardType.MINION)
				{
					if(task.Source.Card.Cost > highestPlayableCost && task.Source.Card.Cost <= availableMana)
					{
						minionWithHighestPlayableCost = task;
						highestPlayableCost = task.Source.Card.Cost;
					}
				}
			}
			return minionWithHighestPlayableCost;
		}

		private PlayerTask playAggressiveSpell(POGame.POGame poGame, List<PlayerTask> options)
		{
			int availableMana = mana; // - poGame.CurrentPlayer.UsedMana;
			PlayerTask spellWithHighestPlayableCost = null;
			int highestPlayableCost = -1;

			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD && task.Source.Card.Type == CardType.SPELL && task.Target == poGame.CurrentOpponent.Hero)
				{
					if (task.Source.Card.Cost > highestPlayableCost && task.Source.Card.Cost <= availableMana)
					{
						spellWithHighestPlayableCost = task;
						highestPlayableCost = task.Source.Card.Cost;
					}
				}
			}
			return spellWithHighestPlayableCost;
		}


		private PlayerTask playSpell(POGame.POGame poGame, List<PlayerTask> options)
		{
			int availableMana = mana; // - poGame.CurrentPlayer.UsedMana;
			PlayerTask spellWithHighestPlayableCost = null;
			int highestPlayableCost = -1;

			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD && task.Source.Card.Type == CardType.SPELL)
				{
					//if (task.Source.Card.Cost > highestPlayableCost && task.Source.Card.Cost <= availableMana)
					//{
					//	spellWithHighestPlayableCost = task;
					//	highestPlayableCost = task.Source.Card.Cost;
					//}
					return task;
				}
			}
			return spellWithHighestPlayableCost;
		}

		private LinkedList<PlayerTask> doSmartTrades(POGame.POGame poGame, List<PlayerTask> options)
		{
			LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
			foreach (PlayerTask task in options)
			{
				//get all attacks, which are not against the opponent hero
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target != poGame.CurrentOpponent.Hero)
				{
					int[] ownCardStats = getOwnBoardMinionStats(poGame, task.Source.Card);
					int ownCardAttack = ownCardStats[0];
					int ownCardHealth = ownCardStats[1];

					int[] opponentCardStats = getOpponentBoardMinionStats(poGame, task.Target.Card);
					int opponentCardAttack = opponentCardStats[0];
					int opponentCardHealth = opponentCardStats[1];

					//check if no taunt minion is in way
					if (!opponentHasTaunt(poGame))
					{
						//check if own minions survives AND opponent minion dies
						if (ownCardHealth > opponentCardAttack && ownCardAttack >= opponentCardHealth)
						{
							minionAttacks.AddLast(task);
						}
					}
					//or opponent minion has taunt
					else if (hasOpponentBoardMinionTaunt(poGame, task.Target.Card))
					{
						minionAttacks.AddLast(task);
					}
					else
					{
						//do not add this task
					}
				}
			}
			return minionAttacks;
		}

		private PlayerTask useHeroPower(POGame.POGame poGame, List<PlayerTask> options)
		{
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
				{
					if (isHeropowerNeedingTarget(poGame) && isHeropowerAggressive(poGame))
					{
						if (task.Target == poGame.CurrentOpponent.Hero)
						{
							return task;
						}
					}
					else if (isHeropowerNeedingTarget(poGame) && !isHeropowerAggressive(poGame))
					{
						if (task.Target == poGame.CurrentPlayer.Hero)
						{
							return task;
						}
					}
					else //no need to target heropower
					{
						return task;
					}
				}
			}
			return null;
		}

		private PlayerTask getAttackingHeroPowerTask(POGame.POGame poGame, List<PlayerTask> options)
		{
			if (poGame.CurrentPlayer.Hero.CanAttack) {
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
					{
						return task;
					}
				}
			}
			return null;



			return null;
		}



		private bool opponentKillable(POGame.POGame poGame)
		{
			int opponentHealth = poGame.CurrentOpponent.Hero.Health + poGame.CurrentOpponent.Hero.Health;
			int maxAttackDmgThisTurn = 0;

			for (int i = 0; i < poGame.CurrentPlayer.BoardZone.Count; i++)
			{
				if (poGame.CurrentPlayer.BoardZone[i].CanAttack)
				{
					maxAttackDmgThisTurn += poGame.CurrentPlayer.BoardZone[i].AttackDamage;
				}
			}


			if(!opponentHasTaunt(poGame) && maxAttackDmgThisTurn >= opponentHealth)
			{
				return true;
			}
			else
			{
				return false;
			}
			
		}


		//----------------------------- helper method ---------------------------------------

		private LinkedList<PlayerTask> getMinionAttackList(POGame.POGame poGame, List<PlayerTask> options)
		{
			LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
				{
					minionAttacks.AddLast(task);
				}
			}
			return minionAttacks;
		}

		private bool opponentHasTaunt(POGame.POGame poGame)
		{
			for (int i = 0; i < poGame.CurrentOpponent.BoardZone.Count; i++)
			{
				if (poGame.CurrentOpponent.BoardZone[i].HasTaunt)
				{
					return true;
				}
			}
			return false;
		}

		private bool ownPlayerCanAttack(POGame.POGame poGame)
		{
			for (int i = 0; i < poGame.CurrentPlayer.BoardZone.Count; i++)
			{
				if (poGame.CurrentPlayer.BoardZone[i].CanAttack)
				{
					return true;
				}
			}
			return false;
		}

		//get stats from own minion [ 0=attack, 1=health ]
		private int[] getOwnBoardMinionStats(POGame.POGame poGame, Card card)
		{
			int ownCardAttack = 0;
			int ownCardHealth = 0;

			for (int i = 0; i < poGame.CurrentPlayer.BoardZone.Count; i++)
			{
				if (card == poGame.CurrentPlayer.BoardZone[i].Card)
				{
					ownCardAttack = poGame.CurrentPlayer.BoardZone[i].AttackDamage;
					ownCardHealth = poGame.CurrentPlayer.BoardZone[i].Health;
					break;
				}
			}
			int[] currentCardStats = { ownCardAttack, ownCardHealth };
			return currentCardStats;
		}

		//get stats from opponent minion [0=attack, 1=health ]
		private int[] getOpponentBoardMinionStats(POGame.POGame poGame, Card card)
		{
			int opponentCardAttack = 0;
			int opponentCardHealth = 0;

			for (int i = 0; i < poGame.CurrentOpponent.BoardZone.Count; i++)
			{
				if (card == poGame.CurrentOpponent.BoardZone[i].Card)
				{
					opponentCardAttack = poGame.CurrentOpponent.BoardZone[i].AttackDamage;
					opponentCardHealth = poGame.CurrentOpponent.BoardZone[i].Health;
					break;
				}
			}
			int[] opponentMinionStats = { opponentCardAttack, opponentCardHealth };
			return opponentMinionStats;
		}

		private bool hasOpponentBoardMinionTaunt(POGame.POGame poGame, Card card)
		{
			bool minionHasTaunt = false;

			for (int i = 0; i < poGame.CurrentOpponent.BoardZone.Count; i++)
			{
				if (card == poGame.CurrentOpponent.BoardZone[i].Card)
				{
					minionHasTaunt = poGame.CurrentOpponent.BoardZone[i].HasTaunt;
					break;
				}
			}
			return minionHasTaunt;
		}

		private bool isHeropowerAggressive(POGame.POGame poGame)
		{
			switch(poGame.CurrentPlayer.HeroClass)
			{
				case CardClass.DRUID: return true;
				case CardClass.HUNTER: return true;
				case CardClass.MAGE: return true;
				case CardClass.PALADIN: return true;
				case CardClass.PRIEST: return false;
				case CardClass.ROGUE: return true;
				case CardClass.SHAMAN: return true;
				case CardClass.WARLOCK: return false;
				case CardClass.WARRIOR: return false;
			}
			return false;
		}

		private bool isHeropowerNeedingTarget(POGame.POGame poGame)
		{
			switch (poGame.CurrentPlayer.HeroClass)
			{
				case CardClass.DRUID: return false;
				case CardClass.HUNTER: return false;
				case CardClass.MAGE: return true;
				case CardClass.PALADIN: return false;
				case CardClass.PRIEST: return true;
				case CardClass.ROGUE: return false;
				case CardClass.SHAMAN: return false;
				case CardClass.WARLOCK: return false;
				case CardClass.WARRIOR: return false;
			}
			return false;
		}

	} //end of class
} // end of namespace
