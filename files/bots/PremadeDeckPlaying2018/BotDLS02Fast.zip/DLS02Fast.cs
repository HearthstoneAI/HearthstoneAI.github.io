﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;
using SabberStoneCore.Tasks;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;

namespace SabberStoneCoreAi.src.Agent
{
	class DLS02Fast : AbstractAgent
	{
		private Random Rnd = new Random();
		private int gameNum;
		private Stopwatch stopwatch;
		private Stopwatch stopwatchAction;
		private int cTurn;
		private int actionNum;
		private int treeDepth;
		private bool timeUp;
		private double MAX_TIME = 10000;
		private int actionTime;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			//Console.WriteLine(gameNum + ". game ended ");
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			if (cTurn != poGame.Turn)
			{			
				stopwatch.Reset();
				stopwatch.Start();
				actionNum = 0;
				cTurn = poGame.Turn;
			}
			stopwatchAction.Reset();
			stopwatchAction.Start();
			timeUp = false;


			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			PlayerTask action = options[0];
			PlayerTask pivotAction = options[0];
			int maxDepth = 2;

			if (options.Count > 1)
			{
				treeDepth = 2;
				action = Greedy(poGame, options);
				while ((treeDepth == maxDepth) && (timeUp == false))
				{
					treeDepth = 0;
					pivotAction = DepthLimitedSearch(poGame, options, maxDepth++);
					if (timeUp == false)
					{
						action = pivotAction;
					}
				}
			}

			actionNum++;
			if (action.PlayerTaskType == PlayerTaskType.END_TURN)
			{
				//Console.WriteLine(gameNum + ". Game: DLS02 :" + poGame.Turn.ToString() + ". turn - Greedy - Time: " + stopwatch.ElapsedMilliseconds + " - Action Num :"+ actionNum);
				stopwatch.Reset();
			}

			//Console.WriteLine("_______Time: " + stopwatchAction.ElapsedMilliseconds + " - Depth :" + maxDepth + " - Option Num:"+options.Count);

			return action;
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
			stopwatch = new Stopwatch();
			stopwatchAction = new Stopwatch();		
			gameNum = 0;
			actionTime = 500;
		}

		public override void InitializeGame()
		{
			stopwatch.Start();
			stopwatchAction.Start();
			cTurn = 0;

			//Console.WriteLine(++gameNum + ". game started");
		}

		public PlayerTask Greedy(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			List<int> fitnessList = new List<int>();
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated = poGame.Simulate(options);
			for (int i = 0; i < simulated.Count; i++)
			{
				if (i == 0)
				{
					fitnessList.Add(GetFitnessNew(poGame));
				}
				else
				{
					SabberStoneCoreAi.POGame.POGame newGame = simulated[options[i]];
					fitnessList.Add(GetFitnessNew(newGame));
				}
			}
			int taskIndex = fitnessList.IndexOf(fitnessList.Max());
			return options[taskIndex];
		}

		public PlayerTask DepthLimitedSearch(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options, int maxDepth)
		{
			
			treeDepth = 0;
			List<int> fitnessList = new List<int>();
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated = poGame.Simulate(options);
			for (int i = 0; i < simulated.Count; i++)
			{
				if (i == 0)
				{
					fitnessList.Add(GetFitnessNew(poGame));
				}
				else
				{
					SabberStoneCoreAi.POGame.POGame newGame = simulated[options[i]];
					List<PlayerTask> newOptions = newGame.CurrentPlayer.Options();
					fitnessList.Add(GetSuccessors(newGame, newOptions, maxDepth, 1));
				}
			}
			int taskIndex = fitnessList.IndexOf(fitnessList.Max());
			return options[taskIndex];
		}

		public int GetSuccessors(SabberStoneCoreAi.POGame.POGame game, List<PlayerTask> options, int maxDepth, int depth)
		{
			//Console.WriteLine(currentProcess.WorkingSet64);
			if (treeDepth < depth)
			{
				treeDepth = depth;
			}
			if ((stopwatchAction.ElapsedMilliseconds < actionTime) &&(stopwatch.ElapsedMilliseconds < MAX_TIME))
			{
				if (depth <= maxDepth)
				{
					if (options.Count > 1)
					{
						List<int> fitnessList = new List<int>();
						Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulated = game.Simulate(options);
						for (int i = 0; i < simulated.Count; i++)
						{
							if (i == 0)
							{
								fitnessList.Add(GetFitnessNew(game));
							}
							else
							{
								SabberStoneCoreAi.POGame.POGame newGame = simulated[options[i]];
								List<PlayerTask> newOptions = newGame.CurrentPlayer.Options();
								fitnessList.Add(GetSuccessors(newGame, newOptions, maxDepth, depth + 1));
							}
						}
						return fitnessList.Max();
					}
					return GetFitnessNew(game);
				}
				else
				{
					return GetFitnessNew(game);
				}					
			}
			else
			{
				timeUp = true;
				return GetFitnessNew(game);
			}
			
		}

		public int GetFitnessNew(SabberStoneCoreAi.POGame.POGame game)
		{
			List<double> featureList = new List<double>();
			List<double> weightList = new List<double>();


			//HERO
			double ownHero = game.CurrentPlayer.Hero.Health + game.CurrentPlayer.Hero.Armor; //Own Hero Health
			if (ownHero < 1)
			{
				return -100000000;
			}

			double opponentHero = game.CurrentOpponent.Hero.Health + game.CurrentOpponent.Hero.Armor; //Opponent Hero Health
			if (opponentHero < 1)
			{
				return 100000000;
			}

			featureList.Add(ownHero / opponentHero);
			weightList.Add(1);

			//CONTROL
			double ownMinionPower = 1;
			double opponentMinionPower = 1;
			
			foreach (SabberStoneCore.Model.Entities.Minion minion in game.Minions)
			{
				if(minion.Controller == game.CurrentPlayer)
				{				
					if (minion.HasTaunt)
					{
						ownMinionPower += (minion.AttackDamage + minion.Health + minion.Armor)*1;
					}
					else 
					{
						ownMinionPower += minion.AttackDamage + minion.Health + minion.Armor;
					}
				}
				else
				{
					if (minion.HasTaunt)
					{
						opponentMinionPower += (minion.AttackDamage + minion.Health + minion.Armor)*1;
					}
					else
					{
						opponentMinionPower += minion.AttackDamage + minion.Health + minion.Armor;
					}
				}				
			}
			featureList.Add(ownMinionPower/ opponentMinionPower); //Own Minion Power
			weightList.Add(1);

			//RESERVE	
			featureList.Add(((double)game.CurrentPlayer.HandZone.Count+1)/((double)game.CurrentOpponent.HandZone.Count+1)); //Cards In Hand
			weightList.Add(1);

			double ret = 1;
			for(int i = 0; i < featureList.Count; i++)
			{
				ret *= (featureList[i] * weightList[i]);
			}

			int retInt = (int)(ret * 1000);
			return retInt;
		}

		public int GetFitness(SabberStoneCoreAi.POGame.POGame game)
		{
			int opponentHero = game.CurrentOpponent.Hero.Health;
			int ownHero = game.CurrentPlayer.Hero.Health;
			int ownMinionPower = 0;
			int opponentMinionPower = 0;
			foreach (SabberStoneCore.Model.Entities.Minion minion in game.Minions)
			{
				if (minion.Controller == game.CurrentPlayer)
				{
					ownMinionPower += minion.AttackDamage + minion.Health;
				}
				else
				{
					opponentMinionPower += minion.AttackDamage + minion.Health;
				}
			}
			return ownHero + ownMinionPower - opponentHero - opponentMinionPower;
		}
	}
}
