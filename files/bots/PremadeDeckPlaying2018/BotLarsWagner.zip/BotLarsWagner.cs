﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.Nodes;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Tasks.PlayerTasks;


//Developed by Lars Wagner
namespace SabberStoneCoreAi.Agent
{
	class BotLarsWagner : AbstractAgent
	{
		private Random Rnd = new Random();
		private int countFlamestrike;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			countFlamestrike = 0;
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<int> values = new List<int>();
			List<PlayerTask> turnList = new List<PlayerTask>();
			PlayerTask bestOption = null;
			int bestValue = int.MinValue;

			Score.ControlScore controlScore = new ControlScore();
			Score.AggroScore aggroScore = new AggroScore();
			//Score.ImprovedScore improvedScore = new ImprovedScore();
			Score.MidRangeScore midrange = new MidRangeScore();

			//Card card = new Card();
			//card.Name = "Flamestrike";

			Controller control = poGame.CurrentPlayer;

			Dictionary<PlayerTask, POGame.POGame> simulated = poGame.Simulate(control.Options());

			if (control.Options().Count == 1)
				return control.Options()[0];

			foreach (PlayerTask k in simulated.Keys)
			{
				if (poGame.CurrentOpponent.CardsPlayedThisTurn.Exists(x => x.Name=="Flamestrike"))
				{
					countFlamestrike = 1;
					Console.WriteLine("Played Flamestrike");
				}

				if (k.PlayerTaskType == PlayerTaskType.END_TURN)
				continue;

				if (poGame.CurrentPlayer.BoardZone.Count >= 3 && k.PlayerTaskType == PlayerTaskType.PLAY_CARD && k.Source.Card.Type == CardType.MINION)
					continue;

				if (poGame.CurrentOpponent.HeroClass == CardClass.MAGE && poGame.CurrentOpponent.BaseMana == 7 &&
				    countFlamestrike == 0 && k.PlayerTaskType == PlayerTaskType.PLAY_CARD && k.Source.Card.Type == CardType.MINION)
				{
					continue;
				}

				//debug for mage to see if I can register flamestrike
				//if (k.PlayerTaskType == PlayerTaskType.MINION_ATTACK && k.Target == poGame.CurrentOpponent)
				//	continue;

				//controller of simulated option
				control = simulated.First(x => x.Key == k).Value?.CurrentPlayer;

				if(control == null)
					continue;

				//set controller on rating function
				//controlScore.Controller = control;
				//improvedScore.Controller = control;
				midrange.Controller = control;

				//rate current option
				var currentValue = midrange.Rate();

				turnList.Add(k);
				values.Add(currentValue);

				if (bestValue < currentValue)
				{
					bestValue = currentValue;
					bestOption = k;
				}
			}

			//debug(turnList, values, bestOption, bestValue, poGame);

			return bestOption ??
			       (bestOption = poGame.CurrentPlayer.Options().Find(x => x.PlayerTaskType == PlayerTaskType.END_TURN));
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
			countFlamestrike = 0;
		}

		public void debug(List<PlayerTask> options, List<int> values, PlayerTask bestOption, int bestValue, POGame.POGame poGame)
		{
			foreach (PlayerTask task in options)
			{
				Console.WriteLine("Current Turn Options: " + task.FullPrint());
			}

			Console.WriteLine("\n\n");

			foreach (int value in values)
			{
				Console.WriteLine("Current Turn Options values: " + value);
			}

			Console.WriteLine("\n\n");

			Console.WriteLine("Option: " + bestOption.FullPrint() + "     Value: " + bestValue);

			Console.WriteLine("My health: " + poGame.CurrentPlayer.Hero.Health);
			Console.WriteLine("Opponent health: " + poGame.CurrentOpponent.Hero.Health);
		}
	}
}
