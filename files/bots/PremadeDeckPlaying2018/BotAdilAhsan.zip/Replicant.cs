﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Model.Entities;
using System.Collections;
using System.Diagnostics;
using System.Linq;
using SabberStoneCore.Enums;
using System.IO;
using SabberStoneCore.Tasks.PlayerTasks;


//Developed by Adil Ahsan
namespace SabberStoneCoreAi.Agent
{
	class Replicant : AbstractAgent
	{

		// constants
		const double minusInf = -1e32;
		const double uncertainTaskValue = 0;
		// random variable
		private Random Rnd = new Random();

		// thresholds for switching modes of exploration
		private int exploreAll = 2; // explore all values, for a single length horizon

		// for rolling horizon

		List<PlayerTask> episodeTasksBest = new List<PlayerTask>(); // keeps best episode Tasks found so far
		private double episodeValueBest = minusInf; // keeps track of the value of the best episode found so far
		private int episodeTasksExecuted = 0; // keeps track of the number of steps of the current  best episode that have been executed




		// parameters of rolling horizon
		private int lookAheadHorizon = 10; // no. of steps to look ahead while making a decision
		private int tasksHorizon = 100; //  no. f steps to take before initiating another look ahead - 6
		private bool simulateUntilEnd = true; // when true, the function will use the horizon parameters. otherwise it will simulate until the end of the turn

		private int optimaWaitConstant = 4; // controls the no. of iterations to wait for an improvement in the considered episode
											// after multiplying with the number of options available
		private int maxInvalidEpisodes = 100; // maximum times it can keep return invalid episodes before giving up and ending turn
											  // for stop watch
		private Stopwatch stopWatch = Stopwatch.StartNew(); // for monitoring time
		private int timeLimitSafe = 10000; // safe time in msec, after this start making best decision with single step look ahead
		private int timeLimitEnd = 15000; // time to end turn
		private int timeLimitEpisode = 500; // time to end episode search
		private int timeLimitBestEpisode = 8000; // time to end search for best episode







		// identity related
		private string agentName = "Deckard";

		// learning related
		private static int featuresLength = 29;
		private double[] featureWeights = new double[29] {0.000215954532213731, 0.000289068682758783, 0.01177662279517, -0.00563741759460388,
			0.00515374418781761, 0.00588020523942157, 0.000210071439206839, 0.00015476675864449,
			0.0016011552410183, 7.2109953922323E-05, 0.000252611127369031, 2.48977022928886E-05,
			0.000910342790632662, 1.89379332011684E-06, 1.72797854218133E-05, -0.000289068682758783,
			-0.01177662279517, 0.00563741759460388, -0.00515374418781761, -0.00588020523942157,
			-0.000210071439206839, -0.00015476675864449, -0.0016011552410183, -7.2109953922323E-05,
			-0.000252611127369031, -2.48977022928886E-05, -0.000910342790632662, -1.89379332011684E-06,
			-1.72797854218133E-05 };

		private int[] boardFeatures = new int[featuresLength];
		private double boardValue = 0.0;

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}

		public override void FinalizeAgent()
		{


		}

		public override void FinalizeGame()
		{

			
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			// ------------------------- Initial Configuration ---------------------

			// ----------- Timing -------------
			// if player turn just started, then reset timer and reset rolling horizon parameters
			if (poGame.CurrentPlayer.NumOptionsPlayedThisTurn == 0)
			{
				// for time monitoring
				stopWatch.Reset();
				stopWatch.Start();

				// for rolling horizon
				ClearRollingHorizonData();
			}


			// ---------- Player ID Establishment -----

			// utilized for assesing game stats
			// establish player ID if it's the first or second turn this game


			if (poGame.Turn == 1 || poGame.Turn == 2)
			{
				if (agentName.Equals("Deckard")) { agentName = GetAgentName(poGame); }
			}


			// ----------- Setting Up Data --------
			// options available in game
			List<PlayerTask> options = new List<PlayerTask>();
			options = poGame.CurrentPlayer.Options();
			// best Task
			PlayerTask bestTask = new PlayerTask();
			string bestTaskCode = "";
			double bestValue = minusInf;
			PlayerTask tempTask = new PlayerTask();
			double tempValue = minusInf;

			// ------------ Get Features ------------

			// update board features
			boardFeatures = GetBoardFeatures(poGame);
			boardValue = GetBoardValue(boardFeatures);



			// ---------- Making Decisions ------------

			// if time is exceeded, or there's just one option (end), then pick that option, otherwise
			// evalutes options more thoroughly
			if (stopWatch.ElapsedMilliseconds > timeLimitEnd)
			{
				// if the time has almost elapsed, end turn
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType == PlayerTaskType.END_TURN)
					{
						bestTask = task;
						bestTaskCode = "EndTurn, time elapsed";
						break;
					}
				}
				// in case the option did not contain end turn, pick one randomly (e.g. choose 1 of 3
				// cards
				if (bestTaskCode.Equals(""))
				{
					bestTask = options[Rnd.Next(options.Count)]; ;
					bestTaskCode = "Choose random card";
				}
			}
			else if (options.Count == 1)
			{
				// if there's just one options, take it
				bestTask = options[0];
				bestTaskCode = "EndTurn, only options available";
			}
			else
			{
				// -------------- Intelligent Execution ---------------------
				// ------------- if the time limit is not about to elapse ----------------------

				// get tasks other than end turn
				List<PlayerTask> validTasks = GetValidTasks(options);

				// -------------------- Attack Opponent Hero if Killable ----------------------
				/*
				// if own minion attacks are greater than or equal to the opponent hero's health and there aren't any enemy taunt minions, attack him directly
				LinkedList<PlayerTask> minionAttacks = new LinkedList<PlayerTask>();
				if (boardFeatures[23] == 0 && (boardFeatures[5] + boardFeatures[7] >= boardFeatures[16]))
				{
					foreach (PlayerTask task in options)
					{
						if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK && task.Target == poGame.CurrentOpponent.Hero)
						{
							minionAttacks.AddLast(task);
						}
					}
				}
				if (minionAttacks.Count > 0)
				{
					bestTask = minionAttacks.First.Value;
					bestTaskCode = "Go after boss";
				}

				
				// get best single step look ahead value


				// if there is just one Task other than end turn, then explore all possibilities deterministically
				// or if time is larger than safe time

				else */
				if (options.Count <= exploreAll || stopWatch.ElapsedMilliseconds > timeLimitSafe)
				{
					// --------------------- Deterministic Evaluation  -------------------------------
					// filter all non EndTurn Tasks
					Dictionary<PlayerTask, POGame.POGame> simulatedTasks = poGame.Simulate(validTasks);
					(bestTask, bestValue) = GetBestTask(simulatedTasks, options);

					// if the best task is not invalid, take it, otherwise, end turn
					if (bestValue != minusInf)
						bestTaskCode = "Just 2 choices or time exhausted, explore all neighbouring options";
					else
					{
						bestTask = options[0]; // pick end turn
						bestTaskCode = "Just 2 choices or time exhausted, deterministic, invalid action returned, end turn";
					}
				}

				else
				{
					// -------------------- Rolling Horizon / Random Episode Evaluation ---------------

					// ---------- Initializations -----------
					bool restartSimulation = new bool();
					restartSimulation = false;

					// ------------ Get Best Value for Single Step Lookahead

					// --------------------- Deterministic Evaluation  -------------------------------
					// filter all non EndTurn Tasks
					Dictionary<PlayerTask, POGame.POGame> simulatedTasks = poGame.Simulate(validTasks);
					(bestTask, bestValue) = GetBestTask(simulatedTasks, options);

					// if the best task is not invalid, take it, otherwise, end turn
					if (bestValue != minusInf)
						bestTaskCode = "Save best value single step look ahead value as reference, explored all neighbouring options";
					else
					{
						bestTask = options[0]; // pick end turn
						bestTaskCode = "Save best value single step look ahead value as reference, deterministic, invalid action returned, end turn";
					}



					// ---------- Continue Execution of Episode ----------


					if ((episodeTasksExecuted != 0) && (episodeTasksExecuted < tasksHorizon) && (episodeTasksExecuted <= episodeTasksBest.Count) && (bestValue < episodeValueBest))
					{
						// if some Task has been executed (this is the not fist time this turn) and
						// the number of Tasks executed does not exceed the Tasks horizon (which would necessitate re-simulating
						// for the next step and
						// if the Tasks executed are less than those stored in the episode

						// select next action in episode
						PlayerTask taskSelected = episodeTasksBest[episodeTasksExecuted];

						// execute if this task is still in the new list of possibilities, otherwise simulate again
						if (options.Contains(taskSelected))
						{
							bestTaskCode = "Continue Episode";
							bestTask = taskSelected;
							episodeTasksExecuted += 1; // increment counter for next cycle

						}
						else restartSimulation = true;

					}
					// get episode through simulation
					if ((restartSimulation == true) || (bestValue > episodeValueBest) || (episodeTasksExecuted == 0) || (episodeTasksExecuted >= tasksHorizon && !(bestTaskCode.Equals("Continue Episode"))))
					{
						// start simulating in the following cases
						// a. if this is the first time this turn/the number of tasks executed is 0
						// b. if there was a problem and restart simulation has been triggered
						// c. if the number of steps executed exceeds or equals the tasks horizon and they didn't become equal this turn

						// ------------------ Initialization ----------------- 

						ClearRollingHorizonData(); // clear data

						int optimaNoChange = 0; // to settle for adequate optima
						int invalidEpisodeCount = 0; // to break loop if all encountered episodes are invalid
						PlayerTask selectedTask = new PlayerTask();
						double generatedEpisodeValue = minusInf;
						List<PlayerTask> generatedEpisodeTasks = new List<PlayerTask>();
						// loop either up to a certain time or an optimum optima has been found

						while ((stopWatch.ElapsedMilliseconds < timeLimitBestEpisode) && optimaNoChange <= optimaWaitConstant * options.Count() && invalidEpisodeCount <= maxInvalidEpisodes)
						{
							// if task is not end turn, generate episode and compare with saved episode
							selectedTask = options[Rnd.Next(options.Count)]; // pick a random task
							if (selectedTask.PlayerTaskType != PlayerTaskType.END_TURN)
							{
								// generate episode
								(generatedEpisodeTasks, generatedEpisodeValue) = GenerateEpisode(selectedTask, poGame, simulateUntilEnd, lookAheadHorizon);
								// if the generate episode's end value is better than the current best, save it
								//Console.WriteLine("Episode Value: " + generatedEpisodeValue.ToString() + ", Best Value: " + bestValue.ToString());
								if (generatedEpisodeValue > episodeValueBest)
								{
									episodeValueBest = generatedEpisodeValue;
									episodeTasksBest = new List<PlayerTask>(generatedEpisodeTasks);
									optimaNoChange = 0;
									//Console.WriteLine("Episode Value: " + generatedEpisodeValue.ToString() + ", Best Value: " + bestValue.ToString());


								}
								else if (generatedEpisodeValue < minusInf)
								{
									// else increment counter if the episode value was at least valid
									optimaNoChange += 1;
								}
								else if (generatedEpisodeValue == minusInf)
								{
									invalidEpisodeCount += 1;
								}
							}

						}
						// assign best episode's first task as the one to take

						if ((episodeTasksBest.Count > 0) && (bestValue < episodeValueBest))
						{
							bestTask = episodeTasksBest[0];
							bestTaskCode = "Episode start";
						}
						else
						{
							// if didn't get anything useful, delete whatever we did get
							ClearRollingHorizonData(); // clear data
						}
						// if after the looop no valid episode was found, then end turn
						//else if (episodeValueBest == minusInf)
						//{
						//	bestTask = options[0];
						//	bestTaskCode = "Keeps generating invalid episodes, end turn";
						//}


					}
				}


				// ------------ Default Decision ------------------
				// if for some reason, the best task is still null and the best task code is blank, then depending on how many options are
				// avaialble, either the best options will be selected deterministically with a single step look ahead, or from the best of a
				// random subset of evaluated tasks

				if (bestTaskCode == "")
				{
					if (stopWatch.ElapsedMilliseconds > timeLimitEnd)
					{
						bestTask = options[0];
						bestTaskCode = "No option found, end turn";
					}
					else
					{
						// --------------------- Deterministic Evaluation  -------------------------------
						// filter all non EndTurn Tasks
						Dictionary<PlayerTask, POGame.POGame> simulatedTasks = poGame.Simulate(validTasks);
						(bestTask, bestValue) = GetBestTask(simulatedTasks, options);

						// if the best task is not invalid, take it, otherwise, end turn
						if (bestValue != minusInf)
							bestTaskCode = "No option found, explore all neighbouring options";
						else
						{
							bestTask = options[0]; // pick end turn
							bestTaskCode = "No option found, deterministic, invalid action returned, end turn";
						}
					}



				}

			}





			// return best decision found
			//if (bestTaskCode.Equals(""))
			//{ bool test; }
			//Console.WriteLine("Task Code: " + bestTaskCode);
			return bestTask;



		}





		// -------------------- Decision Making --------------------------

		// ------------------- Adaptation of Rolling Horizon ------------


		private (List<PlayerTask>, double) GenerateEpisode(PlayerTask selectedTask, POGame.POGame poGame, bool simulateUntilEnd = true, int lookAheadHorizon = 5)
		{
			double episodeValue = minusInf; // for getting the final episode value
			List<PlayerTask> episodeTasks = new List<PlayerTask>(); // for storing list of tasks in episodes
			List<PlayerTask> selectedTaskList = new List<PlayerTask>(); // for converting single task to list for simulation function
			selectedTaskList.Add(selectedTask);

			string episodeCode = "invalid";
			string simulationCode = "invalid";

			// simulate selected task
			Dictionary<PlayerTask, POGame.POGame> simulatedTask = poGame.Simulate(selectedTaskList);


			// check task validity
			simulationCode = CheckTaskValidity(selectedTask, simulatedTask, poGame.CurrentPlayer.Options());

			// add to list
			episodeTasks.Add(selectedTask); // add task to episode

			// if the episode has a problem with simulation, then just return this task and an uncertain task value
			if (simulationCode == "uncertain") { episodeValue = uncertainTaskValue; }
			// in case applying the given task resulted in an invalid state, return a large number
			else if (simulationCode == "invalid") { return (episodeTasks, minusInf); }
			else
			{
				// else proceed forward
				List<PlayerTask> remainingOptions = simulatedTask[selectedTask].CurrentPlayer.Options();
				List<PlayerTask> initialOptions = poGame.CurrentPlayer.Options();
				Dictionary<PlayerTask, POGame.POGame> lastValidSimulation = new Dictionary<PlayerTask, POGame.POGame>(simulatedTask);
				List<PlayerTask> lastValidTask = new List<PlayerTask>(selectedTaskList);
				// while the options are more than just end the game, and either we must simulate until the end, or the number of tasks
				// that we have added to the current episode are still less than the look ahead horizon, then keep adding tasks
				while (remainingOptions.Count > 1 && (simulateUntilEnd || (episodeTasks.Count < lookAheadHorizon)) && stopWatch.ElapsedMilliseconds < timeLimitEpisode)
				{
					// pick a random task, and if it is not end turn, then simulate it
					selectedTask = remainingOptions[Rnd.Next(remainingOptions.Count)]; // pick a random task
					if ((selectedTask.PlayerTaskType != PlayerTaskType.END_TURN)) //&& initialOptions.Contains(selectedTask))
					{
						episodeTasks.Add(selectedTask); // add task to list
														// convert task to list of tasks after deleting list elements
						selectedTaskList.Clear();
						selectedTaskList.Add(selectedTask);
						simulatedTask = poGame.Simulate(selectedTaskList); // add task to list
																		   // check task validity
						simulationCode = CheckTaskValidity(selectedTask, simulatedTask, poGame.CurrentPlayer.Options());

						// if there is no successor board, then break (invalid or uncertain)
						if (!(simulationCode == "valid"))
						{
							break;
						}
						//otherwise save results and proceed with iteration
						lastValidSimulation = new Dictionary<PlayerTask, POGame.POGame>(simulatedTask);
						lastValidTask = new List<PlayerTask>(selectedTaskList);
						remainingOptions = simulatedTask[selectedTask].CurrentPlayer.Options();
					}

				}

				// if it couldn't fill up the tasks up until the end or it is supposed to simulate until the end, then add end turn to final episode
				// additional checks can be added to ensure that the remaining task was end turn

				// get remaining options
				//remainingOptions = simulatedTask[selectedTask].CurrentPlayer.Options();

				// get value of final episode
				episodeValue = GetBoardValue(GetBoardFeatures(lastValidSimulation[lastValidTask[0]]));

				if ((episodeTasks.Count < lookAheadHorizon) || (simulateUntilEnd == true))
				{
					episodeTasks.Add(remainingOptions[0]); // add end turn task to list of tasks to perform
				}
			}
			return (episodeTasks, episodeValue); // return tuple with episode's sequence of tasks and episode value
		}


		// ---------------------------------------------------------------------------------------------------



		// ------------------- Randomly Evaluate a Task Set --------------
		// these functions are for picking a random subset of available options and then picking the task that generates the board
		// with the highest value

		// get list of valid tasks
		private List<PlayerTask> GetValidTasks(List<PlayerTask> options)
		{
			// initialize
			List<PlayerTask> validTasks = new List<PlayerTask>();
			if (options.Count > 1)
			{
				// filter all non EndTurn Tasks
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType != PlayerTaskType.END_TURN)
						validTasks.Add(task);
				}
			}
			return validTasks;
		}

		


		public (PlayerTask, double) GetBestTask(Dictionary<PlayerTask, POGame.POGame> simulatedTasks, List<PlayerTask> originalOptions)
		{
			PlayerTask bestTask = new PlayerTask();
			double bestValue = minusInf;
			double currentValue = minusInf;
			List<PlayerTask> uncertainTasks = new List<PlayerTask>();

			foreach (KeyValuePair<PlayerTask, POGame.POGame> simulatedTask in simulatedTasks)
			{
				// if the successor board is valid and the key is a part of the original options
				if (!(simulatedTask.Value == null) && originalOptions.Contains(simulatedTask.Key))
				{
					// if successor board is valid, evaluate as normal
					currentValue = GetBoardValue(GetBoardFeatures(simulatedTask.Value));
					if (currentValue > bestValue)
					{
						bestValue = currentValue;
						bestTask = simulatedTask.Key;
					}
				}
				else
				{
					// if board is invalid, maintain list of valid tasks and discard others
					if (originalOptions.Contains(simulatedTask.Key))
					{
						// push task to uncertain tasks' list
						uncertainTasks.Add(simulatedTask.Key);
					}
				}

			}
			// if no valid successor board was found, then pick a task randomly from availalbe options
			// and assign in the uncertain value
			if (bestValue == minusInf)
			{
				bestTask = uncertainTasks[Rnd.Next(uncertainTasks.Count)];
				bestValue = uncertainTaskValue;
			}
			return (bestTask, bestValue);


		}

		// ------------------- Error Check ---------------------------

		public string CheckTaskValidity(PlayerTask checkTask, Dictionary<PlayerTask, POGame.POGame> simulatedTasks, List<PlayerTask> originalOptions)
		{
			// checks validity of task and successor board. If board is invalid, the value returned is
			// a large negative no.
			// if the successive board isn't there, but the task is a part of the original tasks, then
			// it is considered valid and the episode value considered is 0 as the actual value in
			// uncertain. Otherwise, the task is assumed to be valid and the actual value may be used
			// note original options refers to the options from the very first board
			//double value = minusInf;
			string code = "invalid";

			// if the dictionary contains the selected action as one of its keys
			if (simulatedTasks.ContainsKey(checkTask))
			{
				// check if move is valid
				//	if the current simulated boards contains it (implies that the dictionary key is the same as the original task)
				// and that board isn't null

				if (simulatedTasks[checkTask] != null)
				{
					code = "valid";
					//value = GetBoardValue(GetBoardFeatures(simulatedTasks[checkTask]));
				}
				// if the successor board wasn't generated, but the key is a part of the original one,
				// then assign an uncertain value. should be used only for first step!!!
				else if (originalOptions.Contains(checkTask))
				{
					code = "unknown";
					//value = uncertainTaskValue;
				}
			}
			else
			{
				// dictionary does not have the selected action, but the selected action is a part of
				// the original options, then assign the episode an uncertain value.
				// should be used only for the 1st task !!!

			}
			// if successor does not exist
			if (simulatedTasks[checkTask] == null)
			{
				if (originalOptions.Contains(checkTask))
				{
					code = "unknown";
					//value = uncertainTaskValue;
				}

			}

			// if none of the above values were assigned, then the default value will be returns,
			// which should be invalid and -infinity
			return code;
		}



		// -------------------- Board Features and Value Calculation ------------

		// gets features of board
		public int[] GetBoardFeatures(SabberStoneCoreAi.POGame.POGame poGame)
		{
			agentName = GetAgentName(poGame);
			/* local variable declaration */
			int[] featuresHeroOwn = new int[2];
			int[] featuresHeroOpp = new int[2];
			int[] featuresMinionsOwn = new int[11];
			int[] featuresMinionsOpp = new int[11];
			int[] features = new int[2 * featuresHeroOwn.Length + 2 * featuresMinionsOpp.Length + 1 + 2]; // 1 is for the offset/bias term, 2 for cards
																										  // get hero features
			if (this.agentName.Equals(poGame.Heroes[0].Controller.Name))
			{   // if self is player 1
				featuresHeroOwn = GetHeroFeatures(poGame.Heroes[0]);
				featuresHeroOpp = GetHeroFeatures(poGame.Heroes[1]);
			}

			else
			{   // if self is player 2
				featuresHeroOwn = GetHeroFeatures(poGame.Heroes[1]);
				featuresHeroOpp = GetHeroFeatures(poGame.Heroes[0]);
			}

			// get minions'features
			//(int[], int[]) featuresMinions = GetMinionsFeatures(poGame.Minions);
			(featuresMinionsOwn, featuresMinionsOpp) = GetMinionsFeatures(poGame.Minions);

			// map tuples to array
			//featuresMinions.Item1.CopyTo(featuresMinionsOwn, 0);
			//featuresMinions.Item2.CopyTo(featuresMinionsOpp, 0);

			// ------------- map features to single array --------------
			features[0] = 1; // bias
							 // cards

			features[1] = poGame.CurrentPlayer.HandZone.Count(); // own cards
																 // own features
			featuresHeroOwn.CopyTo(features, 2); // hero health and damage
			featuresMinionsOwn.CopyTo(features, featuresHeroOwn.Length + 2); // minions
																			 // opponenent's features
			features[2 + featuresHeroOwn.Length + featuresMinionsOwn.Length] = poGame.CurrentOpponent.HandZone.Count(); // opponents cards
			featuresHeroOpp.CopyTo(features, featuresHeroOwn.Length + featuresMinionsOwn.Length + 3);
			featuresMinionsOpp.CopyTo(features, 2 * featuresHeroOwn.Length + featuresMinionsOwn.Length + 3);


			// return features					
			return features;
		}

		// gets value of board
		public double GetBoardValue(int[] features)
		{
			double boardValue = 0.0;
			double boardValueRegression = 0.0;

	
			for (int indexFeatures = 0; indexFeatures < featuresLength; indexFeatures++)
			{
				boardValueRegression += this.featureWeights[indexFeatures] * features[indexFeatures];
			}
			


			boardValue = boardValueRegression; 

			// assign board values for losing or winning, to keep from making a bad decision
			if (features[2] <= 0)
			{
				boardValue = -100;
			}
			else if (features[16] <= 0)
			{
				boardValue = 100;
			}

			// return board value
			return boardValue;
		}

		public int[] GetHeroFeatures(Hero hero)
		{
			/* local variable declaration */
			int[] features = new int[2];
			features[0] = hero.Armor + hero.Health;
			features[1] = hero.AttackDamage + hero.Damage;
			return features;
		}

		// get features of a single minion

		public (int, int, int, int, int, int, int, string) GetMinionFeatures(Minion minion)
		{
			/* local variable declaration */
			int health = new int();
			int attack = new int();
			int strongPower = new int();
			int weakPower = new int();
			int taunt = new int();
			int frozen = new int();
			int destroyed = new int();
			// features in dictionary
			IDictionary<string, int> features = new Dictionary<string, int>();

			// map features
			features.Add("Health", minion.Health);
			features.Add("AttackDamage", minion.AttackDamage);
			features.Add("HasBattleCry", ConvertBoolToInt(minion.HasBattleCry));
			features.Add("HasCharge", ConvertBoolToInt(minion.HasCharge));
			features.Add("HasDeathrattle", ConvertBoolToInt(minion.HasDeathrattle));
			features.Add("HasDivineShield", ConvertBoolToInt(minion.HasDivineShield));
			features.Add("HasInspire", ConvertBoolToInt(minion.HasInspire));
			features.Add("HasLifeSteal", ConvertBoolToInt(minion.HasLifeSteal));
			features.Add("HasStealth", ConvertBoolToInt(minion.HasStealth));
			features.Add("HasTaunt", ConvertBoolToInt(minion.HasTaunt));
			features.Add("HasWindfury", ConvertBoolToInt(minion.HasWindfury));
			features.Add("IsFrozen", ConvertBoolToInt(minion.IsFrozen));
			features.Add("Poisonous", ConvertBoolToInt(minion.Poisonous));
			features.Add("Untouchable", ConvertBoolToInt(minion.Untouchable));
			features.Add("ToBeDestroyed", ConvertBoolToInt(minion.ToBeDestroyed));
			string text = "";
			int hasText = 1;
			try
			{
				text = minion.Card.Text;
				hasText = ConvertBoolToInt(text.Equals(""));
			}
			catch
			{
				hasText = 0;
				text = "";
			}


			features.Add("HasText", hasText);
			features.Add("Epic", ConvertBoolToInt(minion.Card.Rarity.Equals("Epic")));
			features.Add("Legendary", ConvertBoolToInt(minion.Card.Rarity.Equals("Legendary")));
			features.Add("Rare", ConvertBoolToInt(minion.Card.Rarity.Equals("Rare")));
			features.Add("Cost", minion.Card.Cost);

			// transfer direct features to variables
			health = features["Health"];
			attack = features["AttackDamage"];
			taunt = features["HasTaunt"];
			frozen = features["IsFrozen"];
			destroyed = features["ToBeDestroyed"];
			// count powers
			strongPower = features["HasWindfury"] + features["Poisonous"] + features["HasInspire"] + features["HasLifeSteal"];
			weakPower = features["Untouchable"] + features["HasCharge"] + features["HasBattleCry"] + features["HasDeathrattle"] + features["HasStealth"] + features["HasDivineShield"];
			// identify critical texts through rarity and cost:health+attack difference
			// legendary minion
			if (strongPower == 0 && weakPower == 0 && taunt == 0 && features["HasText"] == 1)
			{
				// add legendary minion power
				if (features["Legendary"] == 1) { strongPower = strongPower + Math.Min(1, features["Cost"] - attack); }
				// add epic minion power
				else if (features["Epic"] == 1)
				{
					// add strong power if attack is less than cost
					strongPower = strongPower + Math.Min(0, features["Cost"] - attack);
					// else add weak power
					if (Math.Min(0, features["Cost"] - attack) == 0)
					{
						weakPower = weakPower + 1;
					}
				}
				// add rare minion power
				else if (features["Rare"] == 1) { weakPower = weakPower + Math.Min(1, features["Cost"] - attack); }
			}


			return (health, attack, strongPower, weakPower, taunt, frozen, destroyed, text);
		}

		// get features of all minions

		public (int[], int[]) GetMinionsFeatures(List<Minion> minions)
		{

			// output
			int[] featuresOwn = new int[11];
			int[] featuresOpp = new int[11];

			// mapped inputs
			int health = new int();
			int attack = new int();
			int strongPower = new int();
			int weakPower = new int();
			int taunt = new int();
			int frozen = new int();
			int destroyed = new int();
			string text = "";
			// for special card - doomsayer
			int indexDoomSayerOwn = -1;
			int indexDoomSayerOpp = -1;



			if (minions.Count > 0)
			{
				for (int indexMinion = 0; indexMinion < minions.Count; indexMinion++)
				{
					(health, attack, strongPower, weakPower, taunt, frozen, destroyed, text) = GetMinionFeatures(minions[indexMinion]);

					if (minions[indexMinion].Controller.Name.Equals(this.agentName))
					{
						// own minions
						if (taunt == 1)
						{
							// taunt minion
							featuresOwn[5] = featuresOwn[5] + 1; // add to count
							featuresOwn[2] = featuresOwn[2] + health;
							featuresOwn[3] = featuresOwn[3] + attack;
						}
						else
						{
							// all others
							featuresOwn[0] = featuresOwn[0] + health;
							featuresOwn[1] = featuresOwn[1] + attack;
						}
						// distinguish between powerful and weak minions
						if (health + attack >= 10) { featuresOwn[6] = featuresOwn[6] + 1; }
						else { featuresOwn[4] = featuresOwn[4] + 1; }
						// log power and state
						if (strongPower == 1) { featuresOwn[7] = featuresOwn[7] + 1; }
						if (weakPower == 1) { featuresOwn[8] = featuresOwn[8] + 1; }
						if (frozen == 1) { featuresOwn[9] = featuresOwn[9] + 1; }
						if (destroyed == 1) { featuresOwn[10] = featuresOwn[10] + 1; }
						// account for special card: Doomsayer
						if (text.Equals("At the start of your turn, destroy ALL minions."))
						{

							indexDoomSayerOwn = indexMinion;
						}



					}
					else
					{
						// opponent's minions
						if (taunt == 1)
						{
							// taunt minion
							featuresOpp[5] = featuresOpp[5] + 1;
							featuresOpp[2] = featuresOpp[2] + health;
							featuresOpp[3] = featuresOpp[3] + attack;
						}
						else
						{
							// all others
							featuresOpp[0] = featuresOpp[0] + health;
							featuresOpp[1] = featuresOpp[1] + attack;
						}
						// distinguish between powerful and weak minions
						if (health + attack >= 10) { featuresOpp[6] = featuresOpp[6] + 1; }
						else { featuresOpp[4] = featuresOpp[4] + 1; }
						// log power and state
						if (strongPower == 1) { featuresOpp[7] = featuresOpp[7] + 1; }
						if (weakPower == 1) { featuresOpp[8] = featuresOpp[8] + 1; }
						if (frozen == 1) { featuresOpp[9] = featuresOpp[9] + 1; }
						if (destroyed == 1) { featuresOpp[10] = featuresOpp[10] + 1; }
						// account for special card: Doomsayer
						if (text.Equals("At the start of your turn, destroy ALL minions."))
						{
							indexDoomSayerOpp = indexMinion;
						}
					}

				}
			}

			if (indexDoomSayerOwn > -1 || indexDoomSayerOpp > -1)
			{
				// add them to people about to be destroyed
				featuresOwn[10] = featuresOwn[5] + featuresOwn[6] + featuresOwn[4];
				featuresOpp[10] = featuresOpp[5] + featuresOpp[6] + featuresOpp[4];

				// adjust minion status subject to board control status
				// if there isn't an opponent doomsayer on the board
				if (indexDoomSayerOpp == -1)
				{
					// if your own minions are less than 1, then increase strong powered count, if the enemy can't kill them or if the enemy minions are frozen
					if (featuresOwn[5] + featuresOwn[6] + featuresOwn[4] <= 1)
					{
						featuresOwn[7] += featuresOpp[6] + featuresOpp[5] + featuresOpp[4] + featuresOpp[9];
					}
					else
					{
						// increase small power minion count based on difference between various minion types
						featuresOwn[8] += 3 * (featuresOpp[6] - featuresOwn[6]) + 2 * (featuresOpp[5] - featuresOwn[5]) + featuresOpp[4] - featuresOwn[4] + featuresOpp[9];
					}
				}
				else if (indexDoomSayerOpp > -1)
				{
					// if your own minions are less than 1, then increase strong powered count, if the enemy can't kill them or if the enemy minions are frozen
					if (featuresOpp[5] + featuresOpp[6] + featuresOpp[4] <= 1)
					{
						featuresOpp[7] += featuresOwn[6] + featuresOwn[5] + featuresOwn[4] + featuresOwn[9];
					}
					else
					{
						// increase small power minion count based on difference between various minion types
						featuresOpp[8] += 3 * (featuresOwn[6] - featuresOpp[6]) + 2 * (featuresOwn[5] - featuresOpp[5]) + featuresOwn[4] - featuresOpp[4] + featuresOwn[9];
					}
				}

			}

			return (featuresOwn, featuresOpp);
		}

		// ------------------- Utilities --------------------

		// convert bool to integer
		public int ConvertBoolToInt(bool boolean)
		{
			int result;
			if (boolean == true)
			{
				result = 1;
			}
			else
			{
				result = 0;
			}

			return result;
		}

		// convert integer to double
		public double ConvertIntToDouble(int integer)
		{
			double result;
			result = integer;

			return result;
		}

		// ---------------------------------------------


		

		// ------------ Clean Stuff Up -----------------

		// clean rolling horizon data variables

		public void ClearRollingHorizonData()
		{
			episodeTasksBest.Clear();
			episodeTasksExecuted = 0;
			episodeValueBest = minusInf;

		}

		// ------------------- object data access -------------

		

		public double[] GetFeatureWeights()
		{
			return featureWeights;
		}

		public void SetFeatureWeights(double[] featureWeightsUpdate)
		{
			for (int indexWeights = 0; indexWeights < featureWeights.Length; indexWeights++)
			{
				featureWeights[indexWeights] = featureWeightsUpdate[indexWeights];
			}
		}

		// get agent name

		public string GetAgentName(SabberStoneCoreAi.POGame.POGame poGame)
		{
			return poGame.CurrentPlayer.Name;
		}

		
	






	}



}






