Testing the Agent
==================

1. Copy Replicant.cs file into the relevant agent's directory

2. Add player of type src.Agent.Replicant()

3. Copy the weights.csv file into the bin folder (SabberStone\core-extensions\SabberStoneCoreAi\bin\Debug\netcoreapp2.0)

4. Run the configuration

