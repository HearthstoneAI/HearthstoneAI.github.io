﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model;

namespace SabberStoneCoreAi.Agent
{
	class HansMartin : AbstractAgent
	{
		private Random Rnd = new Random();
		private Queue<PlayerTask> ListPlayerTasksToDo;
		private int MAXDEPTH = 2;

		public override void InitializeGame()
		{
		}


		public override void InitializeAgent()
		{
			Rnd = new Random();
			ListPlayerTasksToDo = new Queue<PlayerTask>();
		}


		public override void FinalizeAgent()
		{
		}


		public override void FinalizeGame()
		{
			ListPlayerTasksToDo = new Queue<PlayerTask>();
		}


		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			return GetMoveAlphabeta(poGame);
		}


		public PlayerTask GetMoveRandom(POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			return options[Rnd.Next(options.Count)];
		}


		public PlayerTask GetMoveMinimax(POGame.POGame poGame, int depth)
		{
			if (poGame.CurrentPlayer.Options().Count == 1)
			{
				return poGame.CurrentPlayer.Options()[0];
			}
			if (ListPlayerTasksToDo.Count == 0)
			{
				ListPlayerTasksToDo = new Queue<PlayerTask>();
				var root = new NodeGameStateMiniMax(poGame.getCopy());
				root.IDDFS(depth);
				ListPlayerTasksToDo = root.GetPlayerTasks();
			}
			return ListPlayerTasksToDo.Dequeue();
		}


		public PlayerTask GetMoveAlphabeta(POGame.POGame poGame)
		{
			if (poGame.CurrentPlayer.Options().Count == 1)
			{
				return poGame.CurrentPlayer.Options()[0];
			}
			if (poGame.CurrentPlayer.Options().Count == 2)
			{
				if (poGame.CurrentPlayer.Options()[0].PlayerTaskType == PlayerTaskType.END_TURN)
				{
					return poGame.CurrentPlayer.Options()[1];
				}
				else
				{
					return poGame.CurrentPlayer.Options()[0];
				}
			}
			if (ListPlayerTasksToDo.Count == 0)
			{
				var root = new NodeGameStateAlphaBeta(poGame.getCopy());
				root.BuildTree(Int32.MinValue, Int32.MaxValue, MAXDEPTH);
				ListPlayerTasksToDo = root.GetPlayerTasks();
			}
			if(ListPlayerTasksToDo.Count == 0)
			{
				return GetMoveRandom(poGame);
			}
			return ListPlayerTasksToDo.Dequeue();
		}
	}


	class NodeGameStateMiniMax
	{
		public NodeGameStateMiniMax prt;   // parent
		public List<NodeGameStateMiniMax> chdr; // children
		public POGame.POGame game; //gamestate of the note
		int PlayerId;
		public PlayerTask task;
		public bool isEnemyNode;
		public bool WasExpanded;
		public float score;

		public NodeGameStateMiniMax(POGame.POGame poGame, PlayerTask task = null, NodeGameStateMiniMax parent = null)
		{
			chdr = new List<NodeGameStateMiniMax>();
			prt = parent;
			game = poGame.getCopy();
			this.task = task;
			WasExpanded = false;
			PlayerId = game.CurrentPlayer.PlayerId;
			if (parent == null) isEnemyNode = false; // root is always MyPlayer
			else if (PlayerId != parent.PlayerId)
			{
				isEnemyNode = !parent.isEnemyNode;
			}
			else
			{
				isEnemyNode = parent.isEnemyNode;
			}
		}


		public bool IsRoot
		{
			get { return prt == null; }
		}


		public bool IsLeaf
		{
			get { return chdr.Count == 0; }
		}


		/// <summary>
		/// Iterative deepening depth-first (recursive depth-limited DFS)
		/// </summary>
		public void IDDFS(int maxDepth)
		{
			for (int i = 0; i < maxDepth; i++)
			{
				DLS();
			}
		}


		private void DLS()
		{
			if (!WasExpanded)
			{
				//fill HandZone of enemy if it is enemys turn
				if (isEnemyNode)
				{
					int cardsToAdd = game.CurrentPlayer.HandZone.Count;
					//Added while loop because apparently the foreach only removes every 2nd card? :/
					while (game.CurrentPlayer.HandZone.Count > 0)
					{
						foreach (IPlayable x in game.CurrentPlayer.HandZone)
						{
							game.CurrentPlayer.HandZone.Remove(x);
						}
					}
					IEnumerable<Card> cards = game.CurrentPlayer.DeckZone.Controller.Standard;

					while (!game.CurrentPlayer.HandZone.IsFull && cardsToAdd > 0)
					{
						Card card = Util.Choose<Card>(cards.ToList());

						// don't add cards that have already reached max occurence in hand + graveyard + boardzone of current Player
						if (game.CurrentPlayer.HandZone.Count(c => c.Card == card) +
							game.CurrentPlayer.GraveyardZone.Count(c => c.Card == card) +
							game.CurrentPlayer.BoardZone.Count(c => c.Card == card) >= card.MaxAllowedInDeck)
							continue;

						IPlayable entity = Entity.FromCard(game.CurrentPlayer.DeckZone.Controller, card);
						game.CurrentPlayer.HandZone.Add(entity);

						cardsToAdd--;
					}
				}

				Expand();
			}
			else
			{
				foreach (NodeGameStateMiniMax child in chdr)
				{
					child.DLS();
				}
			}

		}


		/// <summary>
		/// MinMax Search
		/// </summary>
		/// <returns></returns>
		internal Queue<PlayerTask> GetPlayerTasks()
		{
			score = MiniMax();
			return GetPlayerTasksMinimax();
		}

		private Queue<PlayerTask> GetPlayerTasksMinimax()
		{
			var que = new Queue<PlayerTask>();
			if (!IsRoot) que.Enqueue(task);
			if (!IsLeaf)
			{
				IOrderedEnumerable<NodeGameStateMiniMax> orderedChildren = chdr.OrderByDescending(p => p.score);
				//Min if true, Max if false
				NodeGameStateMiniMax nextNode = isEnemyNode ? orderedChildren.Last() : orderedChildren.First();
				Queue<PlayerTask> queueTail = nextNode.GetPlayerTasksMinimax();
				while (queueTail.Count > 0)
				{
					que.Enqueue(queueTail.Dequeue());
				}
			}

			return que;
		}


		/// <summary>
		/// Minimax algorithm
		/// </summary>
		private float MiniMax()
		{
			if (IsLeaf)
			{
				return SelectionPolicy();
			}
			else
			{
				foreach (NodeGameStateMiniMax child in chdr)
				{
					child.score = child.MiniMax();
				}

				if (isEnemyNode)
				{
					//Minimize
					return chdr.Min(chdr => chdr.score);
				}
				else
				{
					//Maximize
					return chdr.Max(chdr => chdr.score);
				}
			}
		}

		private float SelectionPolicy()
		{
			Score.Score score = new Score.AggroScore();
			if (game.CurrentPlayer.HeroClass == CardClass.MAGE)
			{
				score = new Score.ControlScore();
			}
			if (game.CurrentPlayer.HeroClass == CardClass.WARRIOR)
			{
				score = new Score.AggroScore();
			}
			if (game.CurrentPlayer.HeroClass == CardClass.SHAMAN)
			{
				score = new Score.MidRangeScore();
			}
			score.Controller = isEnemyNode ? game.CurrentOpponent : game.CurrentPlayer;
			return score.Rate();
		}

		private void Expand()
		{
			WasExpanded = true;

			//avoid endturn (avoiding end turn in the tree which is generally a stupid tactic if you can do other moves)
			List<PlayerTask> validTasks = new List<PlayerTask>();
			foreach (PlayerTask task in game.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType != PlayerTaskType.END_TURN)
					validTasks.Add(task);
			}
			Dictionary<PlayerTask, POGame.POGame> dict = game.Simulate(validTasks);
			foreach (KeyValuePair<PlayerTask, POGame.POGame> item in dict)
			{
				//poGame is null if exception occurs
				if (item.Value != null)
				{
					chdr.Add(new NodeGameStateMiniMax(item.Value, item.Key, this));
				}
			}
		}
	}


	class NodeGameStateAlphaBeta
	{
		public NodeGameStateAlphaBeta prt;   // parent
		public List<NodeGameStateAlphaBeta> chdr; // children
		public POGame.POGame game; //gamestate of the note
		int PlayerId;
		public PlayerTask task;
		public bool isEnemyNode;
		public bool WasExpanded;
		public int score;


		public bool IsRoot
		{
			get { return prt == null; }
		}


		public bool IsLeaf
		{
			get { return chdr.Count == 0; }
		}


		public NodeGameStateAlphaBeta(POGame.POGame poGame, PlayerTask task = null, NodeGameStateAlphaBeta parent = null)
		{
			chdr = new List<NodeGameStateAlphaBeta>();
			prt = parent;
			game = poGame.getCopy();
			this.task = task;
			WasExpanded = false;
			PlayerId = game.CurrentPlayer.PlayerId;
			if (parent == null) isEnemyNode = false; // root is always MyPlayer
			else if (PlayerId != parent.PlayerId)
			{
				isEnemyNode = !parent.isEnemyNode;
			}
			else
			{
				isEnemyNode = parent.isEnemyNode;
			}
		}


		public int BuildTree(int alpha, int beta, int depth)
		{
			if (depth == 0)
			{
				score = SelectionPolicy();
				return score;
			}

			Expand();

			if (chdr.Count == 0)
			{
				score = SelectionPolicy();
				return score;
			}

			//Min if true, Max if false
			//sort to get better pruning
			//chdr = isEnemyNode ? chdr.OrderBy(p => SelectionPolicy()).ToList() : chdr.OrderByDescending(p => SelectionPolicy()).ToList();

			foreach (NodeGameStateAlphaBeta child in chdr)
			{
				if (alpha >= beta * 0.6)
				{
					child.score = isEnemyNode ? Int32.MaxValue : Int32.MinValue;
					continue;
				}
				int childscore = child.BuildTree(alpha, beta, depth - 1);

				if (isEnemyNode)
				{
					//minimize
					if (childscore < beta)
					{
						beta = childscore;
					}
					score = beta;
				}
				else
				{
					//Maximize
					if (childscore > alpha)
					{
						alpha = childscore;
					}
					score = alpha;
				}
			}
			return score;
		}


		/// <summary>
		/// MinMax Search
		/// </summary>
		/// <returns></returns>
		internal Queue<PlayerTask> GetPlayerTasks()
		{
			var que = new Queue<PlayerTask>();
			if (!IsRoot)
			{
				que.Enqueue(task);
			}
			if (!IsLeaf)
			{
				IOrderedEnumerable<NodeGameStateAlphaBeta> orderedChildren = chdr.OrderByDescending(p => p.score);
				//Min if true, Max if false
				NodeGameStateAlphaBeta nextNode = isEnemyNode ? orderedChildren.Last() : orderedChildren.First();
				Queue<PlayerTask> queueTail = nextNode.GetPlayerTasks();
				while (queueTail.Count > 0)
				{
					que.Enqueue(queueTail.Dequeue());
				}
			}

			return que;
		}

		private int SelectionPolicy()
		{
			Score.Score score = new Score.AggroScore();
			if (game.CurrentPlayer.HeroClass == CardClass.MAGE)
			{
				score = new Score.ControlScore();
			}
			if (game.CurrentPlayer.HeroClass == CardClass.WARRIOR)
			{
				score = new Score.AggroScore();
			}
			if (game.CurrentPlayer.HeroClass == CardClass.SHAMAN)
			{
				score = new Score.MidRangeScore();
			}
			score.Controller = isEnemyNode ? game.CurrentOpponent : game.CurrentPlayer;
			return score.Rate();
		}

		private void Expand()
		{
			WasExpanded = true;

			if (isEnemyNode)
			{
				//fill HandZone of enemy if it is enemys turn
				int cardsToAdd = game.CurrentPlayer.HandZone.Count;
				//Added while loop because apparently the foreach only removes every 2nd card? :/
				while (game.CurrentPlayer.HandZone.Count > 0)
				{
					foreach (IPlayable x in game.CurrentPlayer.HandZone)
					{
						game.CurrentPlayer.HandZone.Remove(x);
					}
				}
				IEnumerable<Card> cards = game.CurrentPlayer.DeckZone.Controller.Standard;

				while (!game.CurrentPlayer.HandZone.IsFull && cardsToAdd > 0)
				{
					Card card = Util.Choose<Card>(cards.ToList());

					// don't add cards that have already reached max occurence in hand + graveyard + boardzone of current Player
					if (game.CurrentPlayer.HandZone.Count(c => c.Card == card) +
						game.CurrentPlayer.GraveyardZone.Count(c => c.Card == card) +
						game.CurrentPlayer.BoardZone.Count(c => c.Card == card) >= card.MaxAllowedInDeck)
						continue;

					IPlayable entity = Entity.FromCard(game.CurrentPlayer.DeckZone.Controller, card);
					game.CurrentPlayer.HandZone.Add(entity);

					cardsToAdd--;
				}
			}
			//avoid endturn (avoiding end turn in the tree which is generally a stupid tactic if you can do other moves)
			List<PlayerTask> validTasks = new List<PlayerTask>();
			foreach (PlayerTask task in game.CurrentPlayer.Options())
			{
				if (task.PlayerTaskType != PlayerTaskType.END_TURN)
					validTasks.Add(task);
			}
			Dictionary<PlayerTask, POGame.POGame> dict = game.Simulate(validTasks);

			foreach (KeyValuePair<PlayerTask, POGame.POGame> item in dict)
			{
				//poGame is null if exception occurs
				if (item.Value != null)
				{
					chdr.Add(new NodeGameStateAlphaBeta(item.Value, item.Key, this));
				}
			}
		}

	}

}
