# Tyche 2.0.1 B

Modified version of Kai Bornemann Tyche 2.0 bot

This agent is for the Premade Deck Playing track:

## Installation
Move the folder `Tyche201B/` to `HearthstoneAICompetition/core-extensions/SabberStoneCoreAi/src/`

## Usage
In you main `Program.cs`, to instantiate the agent
```
AbstractAgent player1 = new TycheAgentB();
```
