# Tyche 2.0.1 A

Modified version of Kai Bornemann Tyche 2.0 bot

## Installation
Move the folder `Tyche201A/` to `HearthstoneAICompetition/core-extensions/SabberStoneCoreAi/src/`

## Usage
In you main `Program.cs`, to instantiate the agent
```
AbstractAgent player1 = new TycheAgentA();
```

## Deck for User Created Deck Playing-track

### First submission
Hunter class

```
public static List<Card> MechaHunter => new List<Card>()
{
	Cards.FromName("Cogmaster"),
	Cards.FromName("Cogmaster"),
	Cards.FromName("Faithful Lumi"),
	Cards.FromName("Faithful Lumi"),
	Cards.FromName("Mecharoo"),
	Cards.FromName("Mecharoo"),
	Cards.FromName("Annoy-o-Tron"),
	Cards.FromName("Annoy-o-Tron"),
	Cards.FromName("Galvanizer"),
	Cards.FromName("Galvanizer"),
	Cards.FromName("Mechwarper"),
	Cards.FromName("Mechwarper"),
	Cards.FromName("Upgradeable Framebot"),
	Cards.FromName("Upgradeable Framebot"),
	Cards.FromName("Venomizer"),
	Cards.FromName("Venomizer"),
	Cards.FromName("Metaltooth Leaper"),
	Cards.FromName("Metaltooth Leaper"),
	Cards.FromName("Spider Bomb"),
	Cards.FromName("Spider Bomb"),
	Cards.FromName("Enhance-o Mechano"),
	Cards.FromName("Explodinator"),
	Cards.FromName("Explodinator"),
	Cards.FromName("Jeeves"),
	Cards.FromName("Jeeves"),
	Cards.FromName("Replicating Menace"),
	Cards.FromName("Replicating Menace"),
	Cards.FromName("Wargear"),
	Cards.FromName("Wargear"),
	Cards.FromName("Zilliax"),
};
```

### Second submission
Paladin class

```
public static List<Card> TestPaladin => new List<Card>()
{
	Cards.FromName("Lost in the Jungle"),
	Cards.FromName("Lost in the Jungle"),
	Cards.FromName("Patches the Pirate"),
	Cards.FromName("Righteous Protector"),
	Cards.FromName("Righteous Protector"),
	Cards.FromName("Southsea Deckhand"),
	Cards.FromName("Southsea Deckhand"),
	Cards.FromName("Knife Juggler"),
	Cards.FromName("Knife Juggler"),
	Cards.FromName("Nerubian Egg"),
	Cards.FromName("Nerubian Egg"),
	Cards.FromName("Shielded Minibot"),
	Cards.FromName("Shielded Minibot"),
	Cards.FromName("Ship's Cannon"),
	Cards.FromName("Ship's Cannon"),
	Cards.FromName("Divine Favor"),
	Cards.FromName("Divine Favor"),
	Cards.FromName("High Priest Thekal"),
	Cards.FromName("Muster for Battle"),
	Cards.FromName("Muster for Battle"),
	Cards.FromName("Keeper of Uldaman"),
	Cards.FromName("Keeper of Uldaman"),
	Cards.FromName("Call to Arms"),
	Cards.FromName("Call to Arms"),
	Cards.FromName("Loatheb"),
	Cards.FromName("Sunkeeper Tarim"),
	Cards.FromName("Sea Giant"),
	Cards.FromName("Sea Giant"),
	Cards.FromName("Molten Giant"),
	Cards.FromName("Molten Giant"),
};
```
