﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using SabberStoneCore.Config;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent.ExampleAgents;
using SabberStoneCoreAi.Agent;
namespace SabberStoneCoreAi.src
{
	public class Genotype
	{
		public float[] weights = new float[12];


		public Genotype(float m_minionValue, float m_minionSpecial, float m_heroHealth, float m_handCount, float m_deckCount, float m_boardClear,
			float op_minionValue, float op_minionSpecial, float op_heroHealth, float op_handCount, float op_deckCount, float op_boardClear)
		{
			weights[0] = m_minionValue;//1
			weights[1] = m_minionSpecial;
			weights[2] = m_heroHealth;
			weights[3] = m_handCount;
			weights[4] = m_deckCount;
			weights[5] = m_boardClear;
			weights[6] = op_minionValue;
			weights[7] = op_minionSpecial;
			weights[8] = op_heroHealth;
			weights[9] = op_handCount;
			weights[10] = op_deckCount;
			weights[11] = op_boardClear;
		}
	}

	class GeneticAlgo
	{
		static readonly int POPULATION_SIZE = 25;
		static readonly int PARAM_SIZE = 12;
		public const string file = "D:\\CIG\\Genetic_Algo_LolliPoP.log";
		public static string fileContents = "";

		Genotype[] population = new Genotype[POPULATION_SIZE];
		Genotype[] reproduction = new Genotype[6];
		Random random = new Random();

		public void initializePopulation()
		{

			//initialize the four Genotypes with existing scores
			population[0] = new Genotype(1, 3, 2, 2.5f, 1, 3, 1, 3, 2, 2.5f, 1, 3);
			population[1] = new Genotype(2, 7.5f, 2, 1.5f, 1, 3, 3, 5.25f, 1.5f, 2.5f, 1, 1.5f);

			//initialize the rest with random function
			for (int i = 2; i < POPULATION_SIZE; i++)
			{
				float minionValue = random.Next(0, 5) + (float)random.NextDouble();
				float minionSpecial = random.Next(0, 15) + (float)random.NextDouble();
				float heroHealth = random.Next(0, 10) + (float)random.NextDouble();
				float handCount = random.Next(0, 10) + (float)random.NextDouble();
				float deckCount = random.Next(0, 10) + (float)random.NextDouble();
				float boardClear = random.Next(0, 15) + (float)random.NextDouble();


				float o_minionValue = random.Next(0, 5) + (float)random.NextDouble();
				float o_minionSpecial = random.Next(0, 15) + (float)random.NextDouble();
				float o_heroHealth = random.Next(0, 10) + (float)random.NextDouble();
				float o_handCount = random.Next(0, 10) + (float)random.NextDouble();
				float o_deckCount = random.Next(0, 10) + (float)random.NextDouble();
				float o_boardClear = random.Next(0, 15) + (float)random.NextDouble();

				population[i] = new Genotype(minionValue, minionSpecial, heroHealth, handCount, deckCount, boardClear,
					o_minionValue, o_minionSpecial, o_heroHealth, o_handCount, o_deckCount, o_boardClear);
			}
		}


		public float[] getPopulationPoolFitness(float[] m_populationPoolFitness)
		{
			for (int i = 0; i < POPULATION_SIZE; i++)
			{
				m_populationPoolFitness[i] = getFitness(population[i]);
			}

			return m_populationPoolFitness;
		}

		public float[] getOffspringPoolFitness(float[] m_matingPoolFitness)
		{
			for (int i = 0; i < reproduction.Length; i++)
			{
				m_matingPoolFitness[i] = getFitness(reproduction[i]);
			}

			return m_matingPoolFitness;
		}

		public int[] getParentsTournamentSelection(int SIZE, float[] fitness)
		{
			int[] parents = new int[2];

			for (int i = 0; i < 2; i++)
			{
				Dictionary<int, float> tournament = new Dictionary<int, float>();

				for (int p = 0; p < SIZE; p++)
				{
					int selectedGenotype = random.Next(0, POPULATION_SIZE);
					if (i == 0)
					{
						while (tournament.ContainsKey(selectedGenotype))
							selectedGenotype = random.Next(0, POPULATION_SIZE); //select until the individual not there in the tournament
					}
					else
					{
						while (tournament.ContainsKey(selectedGenotype) || selectedGenotype == parents[0])
							selectedGenotype = random.Next(0, POPULATION_SIZE); //select until the individual not there in the tournament
					}

					tournament.Add(selectedGenotype, fitness[selectedGenotype]);
				}

				System.Diagnostics.Debug.WriteLine("\nTournament {0}", i + 1);
				foreach (int k in tournament.Keys)
				{
					System.Diagnostics.Debug.WriteLine("Key {0}: Fitness: {1}", k, tournament[k]);
				}

				parents[i] = tournament.OrderBy(x => x.Value).Last().Key;
			}

			return parents;
		}

		public void applyCrossover(int[] parents)
		{
			int crossPoint = random.Next(1, PARAM_SIZE - 1);
			//System.Diagnostics.Debug.WriteLine(crossPoint);

			float[] weightsOffspring1 = new float[PARAM_SIZE];
			float[] weightsOffspring2 = new float[PARAM_SIZE];

			for (int i = 0; i <= crossPoint; i++)
			{
				weightsOffspring1[i] = population[parents[0]].weights[i];
				weightsOffspring2[i] = population[parents[1]].weights[i];
			}


			for (int i = crossPoint + 1; i < PARAM_SIZE; i++)
			{
				weightsOffspring1[i] = population[parents[1]].weights[i];
				weightsOffspring2[i] = population[parents[0]].weights[i];
			}

			Genotype genotype;

			genotype = new Genotype(weightsOffspring1[0], weightsOffspring1[1], weightsOffspring1[2],
				weightsOffspring1[3], weightsOffspring1[4], weightsOffspring1[5],
				weightsOffspring1[6], weightsOffspring1[7], weightsOffspring1[8],
				weightsOffspring1[9], weightsOffspring1[10], weightsOffspring1[11]);

			reproduction[0] = genotype;

			genotype = new Genotype(weightsOffspring2[0], weightsOffspring2[1], weightsOffspring2[2],
				weightsOffspring2[3], weightsOffspring2[4], weightsOffspring2[5],
				weightsOffspring2[6], weightsOffspring2[7], weightsOffspring2[8],
				weightsOffspring2[9], weightsOffspring2[10], weightsOffspring2[11]);

			reproduction[1] = genotype;

		}

		public void applyRecombination(int[] parents)
		{
			float[] weightsOffspring = new float[PARAM_SIZE];

			for (int i = 0; i < PARAM_SIZE; i++)
			{
				weightsOffspring[i] = (population[parents[0]].weights[i] + population[parents[1]].weights[i]) / 2;
			}

			Genotype genotype;

			genotype = new Genotype(weightsOffspring[0], weightsOffspring[1], weightsOffspring[2],
				weightsOffspring[3], weightsOffspring[4], weightsOffspring[5],
				weightsOffspring[6], weightsOffspring[7], weightsOffspring[8],
				weightsOffspring[9], weightsOffspring[10], weightsOffspring[11]);

			reproduction[2] = genotype;
		}

		public void applyMutation(int[] offspring)
		{
			int[] range1 = new int[1] { 0 };
			int[] range2 = new int[] { 1, 2 };

			foreach (int c in offspring)
			{
				int changePoint = random.Next(0, PARAM_SIZE - 1);
				float value;

				if (range1.Contains(changePoint))
				{
					value = random.Next(10, 10000) + (float)random.NextDouble();
				}
				else if (range2.Contains(changePoint))
				{
					value = random.Next(0, 1000) + (float)random.NextDouble();
				}
				else
				{
					value = random.Next(0, 100) + (float)random.NextDouble();
				}

				float[] weightsOffspring = new float[PARAM_SIZE];

				for (int i = 0; i < PARAM_SIZE; i++)
				{
					if (i == changePoint)
						weightsOffspring[i] = value;
					else
						weightsOffspring[i] = reproduction[offspring[c]].weights[i];
				}

				Genotype genotype;

				genotype = new Genotype(weightsOffspring[0], weightsOffspring[1], weightsOffspring[2],
					weightsOffspring[3], weightsOffspring[4], weightsOffspring[5],
					weightsOffspring[6], weightsOffspring[7], weightsOffspring[8],
				weightsOffspring[9], weightsOffspring[10], weightsOffspring[11]);

				reproduction[c + 3] = genotype;
			}

		}


		public int[] getBestOffsprings(float[] m_matingPoolFitness)
		{
			int indexOne = 0;
			int indexTwo = 0;
			for (int i = 0; i < m_matingPoolFitness.Length; i++)
			{
				if (m_matingPoolFitness[i] > m_matingPoolFitness[indexOne])
				{
					indexTwo = indexOne;
					indexOne = i;
				}
				else if (m_matingPoolFitness[i] > m_matingPoolFitness[indexTwo])
				{
					indexTwo = i;
				}
			}

			int[] m_offsprings = new int[2];

			m_offsprings[0] = indexOne;
			m_offsprings[1] = indexTwo;

			System.Diagnostics.Debug.Write("\nMax Fitness\n");
			System.Diagnostics.Debug.WriteLine(indexOne + " " + m_matingPoolFitness[indexOne]);
			System.Diagnostics.Debug.WriteLine(indexTwo + " " + m_matingPoolFitness[indexTwo]);

			return m_offsprings;
		}

		public int[] getWorstParents(float[] m_populationPoolFitness)
		{
			int indexOne = 0;
			int indexTwo = 0;
			for (int i = 0; i < m_populationPoolFitness.Length; i++)
			{
				if (m_populationPoolFitness[i] < m_populationPoolFitness[indexOne])
				{
					indexTwo = indexOne;
					indexOne = i;
				}
				else if (m_populationPoolFitness[i] < m_populationPoolFitness[indexTwo])
				{
					indexTwo = i;
				}
			}

			int[] m_parents = new int[2];

			m_parents[0] = indexOne;
			m_parents[1] = indexTwo;

			System.Diagnostics.Debug.Write("\nMin Fitness\n");
			System.Diagnostics.Debug.WriteLine(indexOne + " " + m_populationPoolFitness[indexOne]);
			System.Diagnostics.Debug.WriteLine(indexTwo + " " + m_populationPoolFitness[indexTwo]);

			return m_parents;
		}

		public void updatePopulation(int[] m_parents, int[] m_offsprings)
		{
			int parent1 = m_parents[0];
			int parent2 = m_parents[1];

			int offspring1 = m_offsprings[0];
			int offspring2 = m_offsprings[1];

			System.Diagnostics.Debug.WriteLine("\nBefore Update: PARENT 1");
			for (int i = 0; i < PARAM_SIZE; i++)
				System.Diagnostics.Debug.Write(population[parent1].weights[i] + " ");

			System.Diagnostics.Debug.WriteLine("\nBefore Update: PARENT 2");
			for (int i = 0; i < PARAM_SIZE; i++)
				System.Diagnostics.Debug.Write(population[parent2].weights[i] + " ");

			population[parent1] = reproduction[offspring1];
			population[parent2] = reproduction[offspring2];


			System.Diagnostics.Debug.WriteLine("\nAfter Update: PARENT 1");
			for (int i = 0; i < PARAM_SIZE; i++)
				System.Diagnostics.Debug.Write(population[parent1].weights[i] + " ");

			System.Diagnostics.Debug.WriteLine("\nAfter Update: PARENT 2");
			for (int i = 0; i < PARAM_SIZE; i++)
				System.Diagnostics.Debug.Write(population[parent2].weights[i] + " ");
		}


		public float getFitness(Genotype genotype)
		{
			return 0f;
			//return Program.startGame(genotype);
		}

		public static void Main_arc()//remove _arc to start
		{
			System.Diagnostics.Debug.WriteLine("Hello World");

			GeneticAlgo GA = new GeneticAlgo();

			//Initialize the Population Pool
			GA.initializePopulation();

			float[] populationPoolFitness = new float[POPULATION_SIZE];
			float[] matingPoolFitness = new float[6];


			int[] parents;
			int[] offsprings;



			for (int iter = 0; iter <= 1000; iter++)
			{
				System.Diagnostics.Debug.Write("\n\nGeneration: " + iter + "\n\n");

				foreach (Genotype g in GA.population)
				{
					for (int i = 0; i < PARAM_SIZE; i++)
						System.Diagnostics.Debug.Write(g.weights[i] + " ");

					System.Diagnostics.Debug.Write("\n");

				}

				System.Diagnostics.Debug.Write("\nFitness\n");
				populationPoolFitness = GA.getPopulationPoolFitness(populationPoolFitness);

				//Print the fitness of the current population
				foreach (float f in populationPoolFitness)
				{
					System.Diagnostics.Debug.Write(f + " ");
				}
				System.Diagnostics.Debug.Write("\n");

				//Make a tournamentSelection
				parents = GA.getParentsTournamentSelection(2, populationPoolFitness);
				System.Diagnostics.Debug.WriteLine("After Tournie");
				foreach (int i in parents)
				{
					System.Diagnostics.Debug.Write(i + " ");
				}

				System.Diagnostics.Debug.WriteLine("\n\nParent Weights");
				foreach (int i in parents)
				{
					System.Diagnostics.Debug.Write(i + ": ");
					foreach (int z in GA.population[i].weights)
						System.Diagnostics.Debug.Write(z + " ");

					System.Diagnostics.Debug.Write("\n");
				}

				//Apply Crossovers
				GA.applyCrossover(parents);
				System.Diagnostics.Debug.WriteLine("\nOffsprings Crossover");
				foreach (int i in new int[2] { 0, 1 })
				{
					System.Diagnostics.Debug.Write(i + ": ");
					foreach (int z in GA.reproduction[i].weights)
						System.Diagnostics.Debug.Write(z + " ");

					System.Diagnostics.Debug.Write("\n");
				}

				//Apply Crossovers
				GA.applyRecombination(parents);
				System.Diagnostics.Debug.WriteLine("\nOffsprings Recombo");
				foreach (int i in new int[1] { 2 })
				{
					System.Diagnostics.Debug.Write(i + ": ");
					foreach (int z in GA.reproduction[i].weights)
						System.Diagnostics.Debug.Write(z + " ");

					System.Diagnostics.Debug.Write("\n");
				}

				//Apply Mutations
				GA.applyMutation(new int[3] { 0, 1, 2 });
				System.Diagnostics.Debug.WriteLine("\nOffsprings Mutations");
				foreach (int i in new int[3] { 3, 4, 5 })
				{
					System.Diagnostics.Debug.Write(i + ": ");
					foreach (float z in GA.reproduction[i].weights)
						System.Diagnostics.Debug.Write(z + " ");

					System.Diagnostics.Debug.Write("\n");
				}

				//Get the fitness for the current offsprings
				matingPoolFitness = GA.getOffspringPoolFitness(matingPoolFitness);

				System.Diagnostics.Debug.Write("\nMatingPool Fitness\n");
				//Print the fitness of the current population
				foreach (float f in matingPoolFitness)
				{
					System.Diagnostics.Debug.Write(f + " ");
				}
				System.Diagnostics.Debug.Write("\n");

				//get Best Offsprings
				offsprings = GA.getBestOffsprings(matingPoolFitness);


				//get worst Parents
				int[] worstParents = new int[2];
				worstParents = GA.getWorstParents(populationPoolFitness);


				//Update Population
				GA.updatePopulation(worstParents, offsprings);

				System.Diagnostics.Debug.Write("\n\nGeneration END weights\n");
				fileContents += "Generation: " + iter + " ";
				for (int z = 0; z < POPULATION_SIZE; z++)
				{
					Genotype g = GA.population[z];
					System.Diagnostics.Debug.Write(z + ": ");
					fileContents += "\n\n" + z + ": ";
					for (int i = 0; i < PARAM_SIZE; i++)
					{
						System.Diagnostics.Debug.Write(g.weights[i] + " ");
						fileContents += g.weights[i] + " ";
					}
					System.Diagnostics.Debug.Write("\nFitness[" + z + "]: " + populationPoolFitness[z]);
					fileContents += "\nFitness[" + z + "]: " + populationPoolFitness[z];
					System.Diagnostics.Debug.Write("\n");
					fileContents += "\n";

				}

				System.Diagnostics.Debug.Write("*************************************************END*************************************************\n\n\n\n\n\n");

				fileContents += "*************************************************END*************************************************\n\n\n\n\n\n";
				System.IO.File.WriteAllText(file, fileContents);

			}
		}

	}
}
