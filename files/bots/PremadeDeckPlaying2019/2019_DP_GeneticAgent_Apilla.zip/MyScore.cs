﻿
using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class ApillaScore : Score
	{

		public override int Rate()
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			int result = 0;

			float playerValue = 0;
			float opponentValue = 0;

			//Calculate PlayerValue
			foreach (Minion minion in BoardZone)
			{
				playerValue += (minion.Health + minion.AttackDamage);
				if (minion.HasBattleCry || minion.HasCharge || minion.HasDeathrattle || minion.HasDivineShield || minion.HasInspire ||
					minion.HasLifeSteal || minion.HasStealth || minion.HasTaunt || minion.HasWindfury)
					playerValue += 0;
			}

			playerValue += 2 * (float) Math.Sqrt(HeroHp + Controller.Hero.Armor);

			playerValue += 3 * HandCnt;

			playerValue += (float) Math.Sqrt(DeckCnt);

			playerValue += MinionTotHealthTaunt;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
				playerValue += 3;




			//Calculate OpponentValue
			foreach (Minion minion in OpBoardZone)
			{
				opponentValue += (minion.Health + minion.AttackDamage);
				if (minion.HasBattleCry || minion.HasCharge || minion.HasDeathrattle || minion.HasDivineShield || minion.HasInspire ||
					minion.HasLifeSteal || minion.HasStealth || minion.HasTaunt || minion.HasWindfury)
					opponentValue += 1;
			}

			opponentValue += 2 * (float) Math.Sqrt(OpHeroHp + Controller.Opponent.Hero.Armor);

			opponentValue += 3 * OpHandCnt;

			opponentValue += (float) Math.Sqrt(OpDeckCnt);

			opponentValue += MinionTotHealthTaunt;

			if (BoardZone.Count == 0 && OpBoardZone.Count > 0)
				opponentValue += 3;





			//Calculate difference
			result = (int)(playerValue - opponentValue);


			//return score
			return result;


		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
