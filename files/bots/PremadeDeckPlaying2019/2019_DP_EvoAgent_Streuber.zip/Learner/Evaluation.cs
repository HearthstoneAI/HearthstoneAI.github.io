﻿#region copyright
// SabberStone, Hearthstone Simulator in C# .NET Core
// Copyright (C) 2017-2019 SabberStone Team, darkfriend77 & rnilva
//
// SabberStone is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License.
// SabberStone is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
#endregion
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using SabberStoneCore.Config;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent.ExampleAgents;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.Meta;
//using SabberStoneCoreAi.Competition.Agents;
using SabberStoneCoreAi.Competition;

namespace SabberStoneCoreAi
{
	internal partial class Evaluation
	{
		public static Tuple<int, int> Evaluate(EvolutionGreedyAgent botToTest1, EvolutionGreedyAgent botToTest2, int gamesToSimulatePerConfig)
		{
			//Console.WriteLine("Evaluate Master Criterias");
			var gameConfigs = PremadeDeckPlayingConstants.getConfigListPremadeDeckPlaying();
			var winsPerMatchup = new float[gameConfigs.Count];

			var i = 0;

			int win1 = 0;
			int win2 = 0;

			foreach (GameConfig gameConfig in gameConfigs)
			{
				//First Round: bot to evaluate is player 1
				AbstractAgent player1 = botToTest1 as AbstractAgent;
				AbstractAgent player2 = botToTest2 as AbstractAgent;

				var gameHandler = new POGameHandler(gameConfig, player1, player2, repeatDraws: false);
				gameHandler.PlayGames(nr_of_games: gamesToSimulatePerConfig, addResultToGameStats: true, debug: false);
				GameStats gameStats = gameHandler.getGameStats();
				//gameStats.printResults();
				win1 += gameStats.PlayerA_Wins;
				win2 += gameStats.PlayerB_Wins;

				//Second Round: bot to evaluate is player 2
				player1 = botToTest2 as AbstractAgent;
				player2 = botToTest1 as AbstractAgent;

				gameHandler = new POGameHandler(gameConfig, player1, player2, repeatDraws: false);
				gameHandler.PlayGames(nr_of_games: gamesToSimulatePerConfig, addResultToGameStats: true, debug: false);
				gameStats = gameHandler.getGameStats();
				//gameStats.printResults();
				win1 += gameStats.PlayerB_Wins;
				win2 += gameStats.PlayerA_Wins;

				i += 1;
			}

			return new Tuple<int, int>(win1, win2);
			/*
			Console.WriteLine();
			Console.WriteLine(String.Format("Simulation Finished"));
			Console.WriteLine(String.Format("Simulated games per gameConfig    =>   {0}", gamesToSimulatePerConfig * 2));
			Console.WriteLine(String.Format("Total number of simulated games   =>   {0}", gamesToSimulatePerConfig * 2 * gameConfigs.Count));

			for (int j = 0; j < gameConfigs.Count; j++)
			{
				Console.WriteLine(String.Format("Winrate for gameConfig {0}   =>   {1}", j, winsPerMatchup[j] / (2 * gamesToSimulatePerConfig)));
			}

			Console.ReadLine();
			*/

		}
		public static Tuple<int, int> Evaluate(EvolutionGreedyAgent botToTest, int gamesToSimulatePerConfig)
		{
			//Console.WriteLine("Evaluate Master Criterias");
			var gameConfigs = PremadeDeckPlayingConstants.getConfigListPremadeDeckPlaying();
			var winsPerMatchup = new float[gameConfigs.Count];

			var i = 0;

			int win1 = 0;
			int win2 = 0;

			foreach (GameConfig gameConfig in gameConfigs)
			{
				//First Round: bot to evaluate is player 1
				//AbstractAgent player1 = Activator.CreateInstance(botToTest) as AbstractAgent;
				AbstractAgent player1 = botToTest as AbstractAgent;
				AbstractAgent player2 = new GreedyAgent();

				var gameHandler = new POGameHandler(gameConfig, player1, player2, repeatDraws: false);
				gameHandler.PlayGames(nr_of_games: gamesToSimulatePerConfig, addResultToGameStats: true, debug: false);
				GameStats gameStats = gameHandler.getGameStats();
				//gameStats.printResults();
				win1 += gameStats.PlayerA_Wins;
				win2 += gameStats.PlayerB_Wins;

				//Second Round: bot to evaluate is player 2
				player1 = new GreedyAgent();
				player2 = botToTest as AbstractAgent;

				gameHandler = new POGameHandler(gameConfig, player1, player2, repeatDraws: false);
				gameHandler.PlayGames(nr_of_games: gamesToSimulatePerConfig, addResultToGameStats: true, debug: false);
				gameStats = gameHandler.getGameStats();
				//gameStats.printResults();
				win1 += gameStats.PlayerB_Wins;
				win2 += gameStats.PlayerA_Wins;

				i += 1;
			}

			return new Tuple<int, int>(win1, win2);
			/*
			Console.WriteLine();
			Console.WriteLine(String.Format("Simulation Finished"));
			Console.WriteLine(String.Format("Simulated games per gameConfig    =>   {0}", gamesToSimulatePerConfig * 2));
			Console.WriteLine(String.Format("Total number of simulated games   =>   {0}", gamesToSimulatePerConfig * 2 * gameConfigs.Count));

			for (int j = 0; j < gameConfigs.Count; j++)
			{
				Console.WriteLine(String.Format("Winrate for gameConfig {0}   =>   {1}", j, winsPerMatchup[j] / (2 * gamesToSimulatePerConfig)));
			}

			Console.ReadLine();
			*/

		}
	}
}
