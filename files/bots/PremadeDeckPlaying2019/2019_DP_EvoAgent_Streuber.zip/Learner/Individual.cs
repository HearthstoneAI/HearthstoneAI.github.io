﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.Agent;
using System.Threading;

namespace SabberStoneCoreAi.src.Agent.Learner
{
	public class Individual
	{
		private Random Rnd = new Random();

		public int TournamentScore { get; set; } = 0;


		public int AggroBoardClear { get; set; }
		public int AggroOpMinionFactor { get; set; }
		public int AggroHealthDiffFactor { get; set; }
		public int AggroAttackFactor { get; set; }


		public int ControlBoardClear { get; set; }
		public int ControlBoardFactor { get; set; }
		public int ControlOpMinionFactor { get; set; }
		public int ControlHealthDifFactor { get; set; }
		public int ControlAttackFactor { get; set; }


		public int MidRangeBoardClear { get; set; }
		public int MidRangeBoardFactor { get; set; }
		public int MidRangeOpMinionTauntFactor { get; set; }
		public int MidRangeOpMinionHealthFactor { get; set; }
		public int MidRangeOpMinionAtkFactor { get; set; }
		public int MidRangeHealthDiffFactor { get; set; }
		public int MidRangeAttackFactor { get; set; }

		public Individual(int aggroBoardClear, int aggroOpMinionFactor, int aggroHealthDiffFactor, int aggroAttackFactor,
						  int controlBoardClear, int controlBoardFactor, int controlOpMinionFactor, int controlHealthDifFactor, int controlAttackFactor,
						  int midRangeBoardClear, int midRangeBoardFactor, int midRangeOpMinionTauntFactor, int midRangeOpMinionHealthFactor, int midRangeOpMinionAtkFactor, int midRangeHealthDiffFactor, int midRangeAttackFactor)
		{
			AggroBoardClear = aggroBoardClear;
			AggroOpMinionFactor = aggroOpMinionFactor;
			AggroHealthDiffFactor = aggroHealthDiffFactor;
			AggroAttackFactor = aggroAttackFactor;

			ControlBoardClear = controlBoardClear;
			ControlBoardFactor = controlBoardFactor;
			ControlOpMinionFactor = controlOpMinionFactor;
			ControlHealthDifFactor = controlHealthDifFactor;
			ControlAttackFactor = controlAttackFactor;

			MidRangeBoardClear = midRangeBoardClear;
			MidRangeBoardFactor = midRangeBoardFactor;
			MidRangeOpMinionTauntFactor = midRangeOpMinionTauntFactor;
			MidRangeOpMinionHealthFactor = midRangeOpMinionHealthFactor;
			MidRangeOpMinionAtkFactor = midRangeOpMinionAtkFactor;
			MidRangeHealthDiffFactor = midRangeHealthDiffFactor;
			MidRangeAttackFactor = midRangeAttackFactor;
		}

		public Individual() { }


		public Individual(Individual parent, int maxMutagen)
		{

			AggroBoardClear = parent.AggroBoardClear + Rnd.Next(2*maxMutagen) - maxMutagen;
			AggroOpMinionFactor = parent.AggroOpMinionFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			AggroHealthDiffFactor = parent.AggroHealthDiffFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			AggroAttackFactor = parent.AggroAttackFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;

			ControlBoardClear = parent.ControlBoardClear + Rnd.Next(2 * maxMutagen) - maxMutagen;
			ControlBoardFactor = parent.ControlBoardFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			ControlOpMinionFactor = parent.ControlOpMinionFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			ControlHealthDifFactor = parent.ControlHealthDifFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			ControlAttackFactor = parent.ControlAttackFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;

			MidRangeBoardClear = parent.MidRangeBoardClear + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeBoardFactor = parent.MidRangeBoardFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeOpMinionTauntFactor = parent.MidRangeOpMinionTauntFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeOpMinionHealthFactor = parent.MidRangeOpMinionHealthFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeOpMinionAtkFactor = parent.MidRangeOpMinionAtkFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeHealthDiffFactor = parent.MidRangeHealthDiffFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
			MidRangeAttackFactor = parent.MidRangeAttackFactor + Rnd.Next(2 * maxMutagen) - maxMutagen;
		}

		//k-point Crossover
		public Individual(Individual parent1, Individual parent2, int maxMutagen)
		{
			bool kPoint = true;// Rnd.Next(2) == 0;

			if (kPoint)
			{
				AggroBoardClear = (Rnd.Next(2) == 0 ? parent1.AggroBoardClear : parent2.AggroBoardClear) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroOpMinionFactor = (Rnd.Next(2) == 0 ? parent1.AggroOpMinionFactor : parent2.AggroOpMinionFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroHealthDiffFactor = (Rnd.Next(2) == 0 ? parent1.AggroHealthDiffFactor : parent2.AggroHealthDiffFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroAttackFactor = (Rnd.Next(2) == 0 ? parent1.AggroAttackFactor : parent2.AggroAttackFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;

				ControlBoardClear = (Rnd.Next(2) == 0 ? parent1.ControlBoardClear : parent2.ControlBoardClear) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlBoardFactor = (Rnd.Next(2) == 0 ? parent1.ControlBoardFactor : parent2.ControlBoardFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlOpMinionFactor = (Rnd.Next(2) == 0 ? parent1.ControlOpMinionFactor : parent2.ControlOpMinionFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlHealthDifFactor = (Rnd.Next(2) == 0 ? parent1.ControlHealthDifFactor : parent2.ControlHealthDifFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlAttackFactor = (Rnd.Next(2) == 0 ? parent1.ControlAttackFactor : parent2.ControlAttackFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;

				MidRangeBoardClear = (Rnd.Next(2) == 0 ? parent1.MidRangeBoardClear : parent2.MidRangeBoardClear) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeBoardFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeBoardFactor : parent2.MidRangeBoardFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionTauntFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeOpMinionTauntFactor : parent2.MidRangeOpMinionTauntFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionHealthFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeOpMinionHealthFactor : parent2.MidRangeOpMinionHealthFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionAtkFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeOpMinionAtkFactor : parent2.MidRangeOpMinionAtkFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeHealthDiffFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeHealthDiffFactor : parent2.MidRangeHealthDiffFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeAttackFactor = (Rnd.Next(2) == 0 ? parent1.MidRangeAttackFactor : parent2.MidRangeAttackFactor) + Rnd.Next(2 * maxMutagen) - maxMutagen;
			}
			else
			{
				AggroBoardClear = (parent1.AggroBoardClear + parent2.AggroBoardClear)/2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroOpMinionFactor = (parent1.AggroOpMinionFactor + parent2.AggroOpMinionFactor)/2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroHealthDiffFactor = (parent1.AggroHealthDiffFactor + parent2.AggroHealthDiffFactor)/2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				AggroAttackFactor = (parent1.AggroAttackFactor + parent2.AggroAttackFactor)/2 + Rnd.Next(2 * maxMutagen) - maxMutagen;

				ControlBoardClear = (parent1.ControlBoardClear + parent2.ControlBoardClear) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlBoardFactor = (parent1.ControlBoardFactor + parent2.ControlBoardFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlOpMinionFactor = (parent1.ControlOpMinionFactor + parent2.ControlOpMinionFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlHealthDifFactor = (parent1.ControlHealthDifFactor + parent2.ControlHealthDifFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				ControlAttackFactor = (parent1.ControlAttackFactor + parent2.ControlAttackFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;

				MidRangeBoardClear = (parent1.MidRangeBoardClear + parent2.MidRangeBoardClear) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeBoardFactor = (parent1.MidRangeBoardFactor + parent2.MidRangeBoardFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionTauntFactor = (parent1.MidRangeOpMinionTauntFactor + parent2.MidRangeOpMinionTauntFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionHealthFactor = (parent1.MidRangeOpMinionHealthFactor + parent2.MidRangeOpMinionHealthFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeOpMinionAtkFactor = (parent1.MidRangeOpMinionAtkFactor + parent2.MidRangeOpMinionAtkFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeHealthDiffFactor = (parent1.MidRangeHealthDiffFactor + parent2.MidRangeHealthDiffFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
				MidRangeAttackFactor = (parent1.MidRangeAttackFactor + parent2.MidRangeAttackFactor) / 2 + Rnd.Next(2 * maxMutagen) - maxMutagen;
			}
		}
	}

	public class LearnAlgorithm
	{
		static private Random Rnd = new Random();
		public static List<Individual> MatingPool;
		public static List<Individual> Generation;
		public static List<Individual> Legacies;

		static int tournamentsPerGen = 5;
		static int legacySize = 2;
		static int generalTickets = 10;
		static int tournamentSize = 5;
		public static List<Individual>[] winners = new List<Individual>[tournamentsPerGen];
		static int tournamentTickets = 1;
		static double genPopMatingProb = 0.05;
		static int offspringPerGeneration = 55;
		static int maxMutagen = 5;
		static int numberOffGenerations = 10000;
		static int gamesPerEval = 2;
		static int matingPoolSize = tournamentTickets * tournamentsPerGen;
		static int matingPoolTickets = matingPoolSize / 3;
		static int generationSize = legacySize + matingPoolTickets + generalTickets + offspringPerGeneration + 1;

		static void SimulateTournament(List<EvolutionGreedyAgent> individuals/*, int k*/)
		{
			//List<int> scores = new List<int>(tournamentSize);
			for (int i = 0; i < tournamentSize; ++i)
				individuals[i].AgentGenom.TournamentScore = 0;

			for (int i = 0; i < tournamentSize; ++i)
			{
				for (int j = i + 1; j < tournamentSize; ++j)
				{
					var sc = Evaluation.Evaluate(individuals[i], individuals[i], gamesPerEval);
					individuals[i].AgentGenom.TournamentScore += sc.Item1;
					individuals[j].AgentGenom.TournamentScore += sc.Item2;
				}
				var scW = Evaluation.Evaluate(individuals[i], gamesPerEval);
				individuals[i].AgentGenom.TournamentScore += scW.Item1;
			}

			individuals = individuals.OrderByDescending(d => d.AgentGenom.TournamentScore).ToList();

			List<Individual> wins = new List<Individual>();
			for (int i = 0; i < tournamentTickets; ++i)
			{
				MatingPool.Add(individuals[i].AgentGenom);
				//wins.Add(individuals[i].AgentGenom);
			}
			//winners[k % tournamentsPerGen] = wins;
		}

		static void UpdateLegacies()
		{
			List<Individual> bestIndividuals = new List<Individual>();
			for(int i = 0; i<legacySize; ++i)
			{
				bestIndividuals.Add(MatingPool[Rnd.Next(MatingPool.Count)]);
			}
			//MatingPool.OrderByDescending(d => d.TournamentScore).ToList();
			List<EvolutionGreedyAgent> phenotypes = new List<EvolutionGreedyAgent>();

			for (int i = 0; i < legacySize; ++i)
			{
				bestIndividuals[i].TournamentScore = 0;
				Legacies[i].TournamentScore = 0;
				phenotypes.Add(new EvolutionGreedyAgent { AgentGenom = bestIndividuals[i] });
				phenotypes.Add(new EvolutionGreedyAgent { AgentGenom = Legacies[i] });
			}

			for (int i = 0; i < 2 * legacySize; ++i)
			{
				//for (int j = i + 1; j < 2 * legacySize; ++j)
				//{
				//	var sc = Evaluation.Evaluate(phenotypes[i], phenotypes[i], gamesPerEval);
				//	phenotypes[i].AgentGenom.TournamentScore += sc.Item1;
				//	phenotypes[j].AgentGenom.TournamentScore += sc.Item2;
				//}
				var scW = Evaluation.Evaluate(phenotypes[i], 20*gamesPerEval);
				phenotypes[i].AgentGenom.TournamentScore = scW.Item1;
				//Console.WriteLine();
				Console.WriteLine(String.Format("Winrate :{0}/{1}", scW.Item1, 2 * 3 * 20 * gamesPerEval));
			}

			var newLegacies = phenotypes.OrderByDescending(d => d.AgentGenom.TournamentScore).ToList();
			Legacies.Clear();
			for (int i = 0; i < legacySize; ++i)
			{
				Legacies.Add(newLegacies[i].AgentGenom);
			}
			Console.WriteLine("AggroAttackFactor: " + Legacies[0].AggroAttackFactor + ", AggroBoardClear: " + Legacies[0].AggroBoardClear + ", AggroHealthDiffFactor: " + Legacies[0].AggroHealthDiffFactor + ", AggroOpMinionFactor: " + Legacies[0].AggroOpMinionFactor
							  + ", ControlAttackFactor: " + Legacies[0].ControlAttackFactor + ", ControlBoardClear: " + Legacies[0].ControlBoardClear + ", ControlBoardFactor: " + Legacies[0].ControlBoardFactor + ", ControlHealthDifFactor: " + Legacies[0].ControlHealthDifFactor + ", ControlOpMinionFactor: " + Legacies[0].ControlOpMinionFactor
							  + ", MidRangeAttackFactor: " + Legacies[0].MidRangeAttackFactor + ", MidRangeBoardClear: " + Legacies[0].MidRangeBoardClear + ", MidRangeBoardFactor: " + Legacies[0].MidRangeBoardFactor + ", MidRangeHealthDiffFactor: " + Legacies[0].MidRangeHealthDiffFactor + ", MidRangeOpMinionAtkFactor: " + Legacies[0].MidRangeOpMinionAtkFactor + ", MidRangeOpMinionHealthFactor: " + Legacies[0].MidRangeOpMinionHealthFactor + ", MidRangeOpMinionTauntFactor: " + Legacies[0].MidRangeOpMinionTauntFactor);
			Console.WriteLine();
		}

		static void SimulateGeneration()
		{
			Console.WriteLine("NextGen");
			MatingPool.Clear();
			List<Thread> treads = new List<Thread>();
			for(int i = 0; i< tournamentsPerGen; ++i)
			{
				List<EvolutionGreedyAgent> agents = new List<EvolutionGreedyAgent>();
				for(int j = 0; j < tournamentSize; ++j)
				{
					agents.Add(new EvolutionGreedyAgent { AgentGenom = Generation[Rnd.Next(Generation.Count)] });
				}
				/*var t = new Thread(() => */
				SimulateTournament(agents);//,i));
				//t.Start();
				//treads.Add(t);
			}

			//for (int i = 0; i < treads.Count; i++)
			//{
				// Wait until thread is finished.
			//	treads[i].Join();
			//}


			for (int i = 0; i < treads.Count; i++)
			{
				for (int j = 0; j < tournamentTickets; ++j)
				{
					MatingPool.Add(winners[i][j]);
				}
			}

			UpdateLegacies();
			List<Individual> newGen = new List<Individual>();
			for(int i = 0; i < offspringPerGeneration; ++i)
			{
				if(Rnd.NextDouble() < genPopMatingProb)
				{
					newGen.Add(new Individual(Generation[Rnd.Next(Generation.Count)], Generation[Rnd.Next(Generation.Count)], maxMutagen));
				}
				else
				{
					newGen.Add(new Individual(MatingPool[Rnd.Next(MatingPool.Count)], MatingPool[Rnd.Next(MatingPool.Count)], maxMutagen));
				}
			}
			for (int i = 0; i < generalTickets; ++i)
			{
				newGen.Add(Generation[Rnd.Next(Generation.Count)]);
			}
			for (int i = 0; i < legacySize; ++i)
			{
				newGen.Add(Legacies[Rnd.Next(legacySize)]);
			}
			for (int i = 0; i < matingPoolTickets; ++i)
			{
				newGen.Add(MatingPool[Rnd.Next(matingPoolSize)]);
			}
			Generation.Clear();
			foreach(var ind in newGen)
			{
				Generation.Add(ind);
			}
			Generation.Add(new Individual(Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100),
										  Rnd.Next(100), Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100),
										  Rnd.Next(100), Rnd.Next(100), -Rnd.Next(100), -Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100)));
		}

		static void InitLearner()
		{
			Generation = new List<Individual>();
			MatingPool = new List<Individual>();
			Legacies = new List<Individual>();
			for(int i = 0; i<generationSize; ++i)
			{
				Generation.Add(new Individual(Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100),
											  Rnd.Next(100), Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100),
											  Rnd.Next(100), Rnd.Next(100), -Rnd.Next(100), -Rnd.Next(100), -Rnd.Next(100), Rnd.Next(100), Rnd.Next(100)));
			}

			Legacies.Add(new Individual(-20, -53, 56, 116,
										  2, 85, -10, 15, 66,
										  -34, 73, -43,-25, 12, 69, 30));
			Legacies.Add(new Individual(1000, -1000, 1000, 1,
										  1000, 50, 25, 10, 1,
										  5000, 5, -1000, 10, 10, 10, 1));
			//for (int i = 0; i < legacySize; ++i)
			//{
			//	Legacies.Add(Generation[Rnd.Next(Generation.Count)]);
			//}
		}

		public static void SimulateEvolution()
		{
			InitLearner();
			for(int i = 0; i<numberOffGenerations; ++i)
			{
				SimulateGeneration();
			}
		}
	}
	public class EvoAggroScore : SabberStoneCoreAi.Score.Score
	{
		public Individual Genotype { get; set; }
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			int result = 0;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
				result += Genotype.AggroBoardClear;

			if (OpMinionTotHealthTaunt > 0)
				result += OpMinionTotHealthTaunt * Genotype.AggroOpMinionFactor;

			result += MinionTotAtk * Genotype.AggroAttackFactor;

			result += (HeroHp - OpHeroHp) * Genotype.AggroHealthDiffFactor;

			return result;
		}

		//public EvoAggroScore(Individual genom)
		//{
		//	Genotype = genom;
		//}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}

	public class EvoControlScore : SabberStoneCoreAi.Score.Score
	{
		public Individual Genotype { get; set; }
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return int.MaxValue;

			if (HeroHp < 1)
				return int.MinValue;

			int result = 0;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
				result += Genotype.ControlBoardClear;

			result += (BoardZone.Count - OpBoardZone.Count) * Genotype.ControlBoardFactor;

			result += (MinionTotHealthTaunt - OpMinionTotHealthTaunt) * Genotype.ControlOpMinionFactor;

			result += MinionTotAtk * Genotype.ControlAttackFactor;

			result += (HeroHp - OpHeroHp) * Genotype.ControlHealthDifFactor;

			return result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}

	public class EvoMidRangeScore : SabberStoneCoreAi.Score.Score
	{
		public Individual Genotype { get; set; }
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return int.MaxValue;

			if (HeroHp < 1)
				return int.MinValue;

			int result = 0;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
				result += Genotype.MidRangeBoardClear;

			result += (BoardZone.Count - OpBoardZone.Count) * Genotype.MidRangeBoardFactor;

			if (OpMinionTotHealthTaunt > 0)
				result += OpMinionTotHealthTaunt * Genotype.MidRangeOpMinionTauntFactor;

			result += MinionTotAtk * Genotype.MidRangeAttackFactor;

			result += (HeroHp - OpHeroHp) * Genotype.MidRangeHealthDiffFactor;

			result += (MinionTotHealth - OpMinionTotHealth) * Genotype.MidRangeOpMinionHealthFactor;

			result += (MinionTotAtk - OpMinionTotAtk) * Genotype.MidRangeOpMinionAtkFactor;

			return result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}

}
