﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.src.Agent.Learner;


namespace SabberStoneCoreAi.Competition.Agents
{
	class EvolutionGreedyAgentFinal : AbstractAgent
	{
		private Random Rnd = new Random();

		public static Individual AgentGenom = new Individual
		{
			AggroAttackFactor = 1,
			AggroBoardClear = 1002,
			AggroHealthDiffFactor = 16,
			AggroOpMinionFactor = -60,
			ControlAttackFactor = 25,
			ControlBoardClear = 40,
			ControlBoardFactor = 53,
			ControlHealthDifFactor = 8,
			ControlOpMinionFactor = 21,
			MidRangeAttackFactor = 3,
			MidRangeBoardClear = 5002,
			MidRangeBoardFactor = 9,
			MidRangeHealthDiffFactor = 9,
			MidRangeOpMinionAtkFactor = 13,
			MidRangeOpMinionHealthFactor = 10,
			MidRangeOpMinionTauntFactor = -1002
		};


		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(POGame.POGame game)
		{
			var player = game.CurrentPlayer;

			// Get all simulation results for simulations that didn't fail
			var validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}

		// Calculate different scores based on our hero's class
		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new EvoAggroScore { Controller = p, Genotype = AgentGenom }.Rate();
				case CardClass.MAGE: return new EvoControlScore { Controller = p, Genotype = AgentGenom }.Rate();
				default: return new EvoMidRangeScore { Controller = p, Genotype = AgentGenom }.Rate();
			}
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}
		
	}
}
