﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.src.Agent.Learner;

namespace SabberStoneCoreAi.Agent
{
	class EvolutionGreedyAgent : AbstractAgent
	{
		private Random Rnd = new Random();

		public Individual AgentGenom { get; set; }

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(POGame.POGame game)
		{
			var player = game.CurrentPlayer;

			// Get all simulation results for simulations that didn't fail
			var validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}

		// Calculate different scores based on our hero's class
		private int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new EvoAggroScore { Controller = p, Genotype = AgentGenom }.Rate();
				case CardClass.MAGE: return new EvoControlScore { Controller = p, Genotype = AgentGenom }.Rate();
				default: return new EvoMidRangeScore { Controller = p, Genotype = AgentGenom }.Rate();
			}
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}
		
	}
}
