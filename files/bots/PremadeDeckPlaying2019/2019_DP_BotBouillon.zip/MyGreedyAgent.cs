﻿using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCore.Model;
using System.Collections.Generic;
using SabberStoneCoreAi.Agent;


namespace SabberStoneCoreAi.Competition.Agents
{
	//Greedy bot with optional lookahead by Christoph Bouillon
	class BotBouillon : AbstractAgent
	{
		private int my_ID;

		public override void InitializeAgent(){	}
		public override void InitializeGame() { }
		public override void FinalizeGame() { }
		public override void FinalizeAgent() { }

		private double evaluate(POGame.POGame poGame)
		{


			//--------------SIMPLE GAME EVALUATION---------------------

			if(poGame.CurrentPlayer.Id != my_ID)
			{
				return int.MinValue;
			}

			var player = poGame.CurrentPlayer;
			var opponent = poGame.CurrentOpponent;
			var my_boardzone = player.BoardZone;
			var op_boardzone = opponent.BoardZone;
			var my_hero = player.Hero;
			var op_hero = opponent.Hero;
			var my_class = my_hero.Card.Class;
			var op_class = op_hero.Card.Class;
			var my_hand = player.HandZone;

			if(my_hero.Health < 1)
			{
				return int.MinValue;
			}
			if (op_hero.Health < 1)
			{
				return int.MaxValue;
			}
			int my_minion_total_atk = 0;
			int op_minion_total_atk = 0;
			int my_minion_effective_atk = 0;
			int op_minion_effective_atk = 0;
			int my_minion_total_hp = 0;
			int op_minion_total_hp = 0;
			int my_minion_taunt_hp = 0;
			int op_minion_taunt_hp = 0;

			foreach (var minion in my_boardzone)
			{
				int windfury = 0;
				int taunt = 0;
				int divine_shield = 0;
				int can_attack = 0;

				if (minion.HasDivineShield) { divine_shield = 1; }
				if (minion.HasTaunt) { taunt = 1; }
				if (minion.HasWindfury) { windfury = 1; }
				if (minion.CanAttack) { can_attack = 1; }

				my_minion_effective_atk += minion.AttackDamage * can_attack + minion.AttackDamage * can_attack * windfury;
				my_minion_total_atk += minion.AttackDamage + minion.AttackDamage * windfury;
				my_minion_total_hp += minion.Health + minion.Health * divine_shield;
				my_minion_taunt_hp += minion.Health * taunt + minion.Health * taunt * divine_shield;
				
			}
			foreach (var minion in op_boardzone)
			{
				int windfury = 0;
				int taunt = 0;
				int divine_shield = 0;
				int can_attack = 0;

				if (minion.HasDivineShield) { divine_shield = 1; }
				if (minion.HasTaunt) { taunt = 1; }
				if (minion.HasWindfury) { windfury = 1; }
				if (minion.CanAttack) { can_attack = 1; }

				op_minion_effective_atk += minion.AttackDamage * can_attack + minion.AttackDamage * can_attack * windfury;
				op_minion_total_atk += minion.AttackDamage + minion.AttackDamage * windfury;
				op_minion_total_hp += minion.Health + minion.Health * divine_shield;
				op_minion_taunt_hp += minion.Health * taunt + minion.Health * taunt * divine_shield;
			}
			double my_offensive_value = 0;
			double my_defensive_value = 0;
			double op_offensive_value = 0;
			double op_defensive_value = 0;
			double my_control_value = 0;

			my_offensive_value += my_minion_total_atk + player.CurrentSpellPower + my_hero.TotalAttackDamage;
			my_defensive_value += my_minion_taunt_hp + my_minion_total_hp;
			my_control_value += my_boardzone.Count - op_boardzone.Count;
			op_offensive_value += op_minion_total_atk + op_minion_effective_atk;
			op_defensive_value += op_minion_taunt_hp + op_minion_total_hp;

			double value = 0;

			//---------------MAGE, WARRIOR, PALADIN CALC--------------

			if (my_class == CardClass.MAGE || my_class==CardClass.WARRIOR || my_class == CardClass.PALADIN)
			{
				value = 1 * my_offensive_value + 1 * my_defensive_value + 1 * my_control_value - op_offensive_value - op_defensive_value + my_hero.Health - op_hero.Health;
				return value;
			}

			//------------------- SHAMAN, HUNTER, DRUID CALC ---------------------

			if (my_class == CardClass.SHAMAN  || my_class == CardClass.DRUID || my_class == CardClass.HUNTER) 
			{
				value = 2*my_offensive_value + my_defensive_value + 1*my_control_value - 2*op_offensive_value - 2*op_defensive_value + my_hero.Health - op_hero.Health;
				return value;
			}

			//---------------ROGUE CALC----------------
			if(my_class == CardClass.ROGUE )
			{
				int mana = player.RemainingMana;
				value = 1 * my_offensive_value + 1 * my_defensive_value + 1*my_control_value - 1*op_offensive_value - 1*op_defensive_value + 1*my_hero.Health - 0.5*op_hero.Health + 0.5* mana;
				return value;

			}

			//------------WARLOCK------------
			if(my_class == CardClass.WARLOCK )
			{
				value = 0.5 * my_offensive_value + 5 * my_defensive_value + 1 * my_control_value - 1 * op_offensive_value - 1 * op_defensive_value + 1 * my_hero.Health - 1 * op_hero.Health;
			}
			//----------------PRIEST------------
			if (my_class == CardClass.PRIEST)
			{
				value = 1 * my_offensive_value + 1 * my_defensive_value + 10 * my_control_value - 2*op_offensive_value - 1*op_defensive_value + 1*my_hero.Health - 1*op_hero.Health;
				if (player.DragonInHand)
				{
				}
			}

			return value;
		}


		public PlayerTask GetMoveGreedy(POGame.POGame game)
		{
			var player = game.CurrentPlayer;
			var validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);
			return validOpts.Any() ?
				validOpts.OrderBy(x => evaluate(x.Value)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}
		public PlayerTask GetMoveLookahead(POGame.POGame game)
		{
			var player = game.CurrentPlayer;
			var validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);
			PlayerTask best_move = null;
			double best_value = 0;
			foreach (KeyValuePair<PlayerTask, POGame.POGame> pair in validOpts)
			{
				var game_ = pair.Value;
				var player_ = game_.CurrentPlayer;
				var move_ = pair.Key;

				if (player_.Id == player.Id)
				{
					var validOpts_ = game_.Simulate(player_.Options()).Where(x => x.Value != null);
					foreach (KeyValuePair<PlayerTask, POGame.POGame> pair_ in validOpts_)
					{
						double value = evaluate(pair_.Value);
						if (value > best_value)
						{
							best_value = value;
							best_move = move_;
						}
					}
				}

			}
			if (best_move == null)
			{
				best_move = validOpts.OrderBy(x => evaluate(x.Value)).Last().Key;
			}
			return best_move;
		}
		public override PlayerTask GetMove(POGame.POGame game)
		{
			this.my_ID = game.CurrentPlayer.Id;
			bool lookahead = false;
			switch (game.CurrentPlayer.HeroClass)
			{
				case CardClass.PALADIN: lookahead = true; break;
				case CardClass.DRUID: lookahead = true; break;
				case CardClass.SHAMAN: lookahead = true; break;
				case CardClass.WARRIOR: lookahead = true; break;
				case CardClass.MAGE: lookahead = true; break;
				case CardClass.WARLOCK: lookahead = false; break;
				case CardClass.ROGUE: lookahead = true; break;
				case CardClass.PRIEST: lookahead = true; break;
				case CardClass.HUNTER: lookahead = false; break;
			}

			if (lookahead)
			{
				return GetMoveLookahead(game);
			}
			return GetMoveGreedy(game);
		}
	}
}
