﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SabberStoneCoreAi.src.Agent.Helper
{
	internal class Utility
	{
		/// <summary>
		/// Returns seconds since start of game
		/// </summary>
		/// <returns>time in seconds since start</returns>
		public static double getSecondsSinceStart()
		{
			return Environment.TickCount / 1000;
		}
	}
}
