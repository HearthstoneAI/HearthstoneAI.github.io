﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SabberStoneCoreAi.src.Agent.Helper
{
	/// <summary>
	/// Extension of the Standard Random-Class
	/// can give Random numbers in Ranges for double and float ranges
	/// </summary>
	public class Random : System.Random
	{
		/// <summary>
		/// Initialize base class with a seed, e.g. DateTime.Now.Milliseconds
		/// </summary>
		/// <param name="Seed">Seed for random number generation to be used</param>
		public Random(int Seed) : base(Seed) { }

		/// <summary>
		/// Returns a random double value between lower and upper boundaries
		/// </summary>
		/// <param name="lower">lower boundary</param>
		/// <param name="upper">upper boundary</param>
		/// <returns>random double value inside bounderies</returns>
		public double NextDouble(double lower, double upper)
		{
			//var rand = new Random(DateTime.Now.Millisecond);
			return lower + NextDouble() * (upper - lower);
		}

		/// <summary>
		/// Returns a random float value between lower and upper boundaries
		/// </summary>
		/// <param name="lower">lower boundary</param>
		/// <param name="upper">upper boundary</param>
		/// <returns>random flot value inside bounderies</returns>
		public float NextFloat(float lower, float upper)
		{
			return (float)NextDouble(lower, upper);
		}
	}
}
