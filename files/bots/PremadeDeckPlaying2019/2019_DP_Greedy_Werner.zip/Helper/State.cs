﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.src.Agent.SearchTree;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SabberStoneCoreAi.src.Agent.Helper
{
	internal class State : IComparable<State>
	{
		public POGame.POGame Game { get; private set; }

		public Weights Weights { get; set; }

		public int TimesWon { get; set; } = 0;
		public int TimesLost { get; set; } = 0;

		/// <summary>
		/// The Turn-Count is used as ID
		/// </summary>
		public int ID { get; private set; }
		/// <summary>
		/// Task with which this state y was achiched from state y
		/// S_x => task => S_y
		/// </summary>
		public PlayerTask Task { get; private set; }

		public double Reward { get; set; } = 0;

		public double Value { get; set; } = 0;

		public int Visits { get; set; } = 0;

		private bool IsDead(Controller controller)
		{
			return controller.Hero.Health < 1;
		}

		public bool IsEnd(Controller player, Controller opponent)
		{
			return IsDead(player) || IsDead(opponent);
		}
		public bool Won(Controller player, Controller opponent)
		{
			return !IsDead(player) && IsDead(opponent);
		}

		internal void SimulateGame(POGame.POGame parent)
		{
			Game = parent.Simulate(new List<PlayerTask>() { Task })[Task];
			if(Game != null)
			{
				CalcReward(Game);
			}
		}


		/// <summary>
		/// 
		/// </summary>
		/// <param name="simGame"></param>
		/// <param name="player"></param>
		/// <param name="opponent"></param>
		/// <param name="task"></param>
		public State(POGame.POGame poGame, PlayerTask task, Weights weights)
		{
			Game = poGame;
			ID = Game.Turn;

			Task = task; // actions
			Weights = weights;
		}

		public State()
		{
		}
		public State(POGame.POGame parent, Weights weights)
		{
			Game = parent;
			Weights = weights;
		}
		public State(PlayerTask task, Weights weights)
		{
			Weights = weights;
			Task = task;
		}

		/// <summary>
		/// Updates the Value for this State (S_t)
		/// Value is computed with the value function for temporal difference td(0)
		/// </summary>
		/// <param name="nextState">State S_t+1</param>
		internal void UpdateValue()
		{
			Value = Value + 1d / Visits * (Reward - Value);
			//Value = Reward;// / Visits;
		}

		internal void Reset()
		{
			Value = 0;
			Reward = 0;
			TimesWon = 0;
			TimesLost = 0;
		}

		public double AvgReward()
		{
			return Reward / Visits;
		}

		/// <summary>
		/// Calculates the Reward of this state
		/// </summary>
		public void CalcReward(POGame.POGame parent)
		{
			Controller player = parent.CurrentPlayer;
			Controller opponent = parent.CurrentOpponent;
			if (player.PlayerId != CakeWinner.PlayerID)
			{
				player = parent.CurrentOpponent;
				opponent = parent.CurrentPlayer;
			}

			if (IsDead(opponent))
			{
				TimesWon++;
				Reward += Single.MaxValue;
			}
			else if (IsDead(player))
			{
				TimesLost++;
				Reward += Single.MinValue;
			}
			else
			{
				//Works also with the Scores used in Greedy
				var p = Game.CurrentPlayer.PlayerId == CakeWinner.PlayerID ? Game.CurrentPlayer : Game.CurrentOpponent;
				switch (Game.CurrentPlayer.HeroClass)
				{
					case CardClass.WARRIOR: Reward += new RampScore { Controller = p }.Rate(); break;
					case CardClass.MAGE: Reward += new MyControlScore { Controller = p }.Rate(); break;
					case CardClass.HUNTER: Reward += new HunterMidRangeScore { Controller = p }.Rate(); break;
					case CardClass.ROGUE: Reward += new RogueRangeScore { Controller = p }.Rate(); break;
					case CardClass.SHAMAN: Reward += new RogueRangeScore { Controller = p }.Rate(); break;
					case CardClass.PALADIN: Reward += new RogueRangeScore { Controller = p }.Rate(); break;
					case CardClass.WARLOCK: Reward += new MyControlScore { Controller = p }.Rate(); break;
					case CardClass.PRIEST: Reward += new RogueRangeScore { Controller = p }.Rate(); break;
					default: Reward += new MidRangeScore { Controller = p }.Rate(); break;
				}
				return;

				double reward = 0;

				//reward for each minion
				reward += MinionValue(player) * Weights.MinionWeight;
				int rewardHand = RewardHandCards(player, opponent);
				//if(Task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
				//{
				//	if(Task.Source is Minion minion)
				//	{
				//		//check if it would be wasted
				//		if (minion.HasBattleCry)
				//		{
				//			var text = minion.Card.Text;
				//			bool affectsOpponent = text.Contains("opponent");
				//			bool affectsHand = text.Contains("in your hand");
				//			bool toHand = text.Contains("Return");
				//			bool isWeapon = text.Contains("weapon");

				//			if (toHand)
				//			{
				//				if(isWeapon && (player.GraveyardZone.Count == 0 || player.GraveyardZone.Where(p => p is Weapon).Count() == 0))
				//				{
				//					reward -= 100;
				//				}
				//			}

				//			if(affectsOpponent && isWeapon)
				//			{
				//				if(opponent.Hero.Weapon == null)
				//				{
				//					reward -= 100;
				//				}
				//				else
				//				{
				//					reward += 100;
				//				}

				//			}

				//			if(Regex.IsMatch(text, "\\w*\\s[0-9]{1}[\\s|\\w]*(minions?)"))
				//			{
				//				var number = new string(text.SkipWhile(c => !char.IsDigit(c))
				//							 .TakeWhile(c => char.IsDigit(c))
				//							 .ToArray());
				//				int.TryParse(number, out int mCount);
				//				if (opponent.BoardZone.Count < mCount)
				//				{
				//					reward -= 100;
				//				}
				//			}
				//			if(affectsHand )
				//			{
				//				if(player.HandZone.Count == 0)
				//				{
				//					reward -= 100;
				//				}
				//				else
				//				{
				//					reward += 100 * player.HandZone.Count;
				//				}

				//			}
				//		}
				//	}
				//}


				//if(Task.PlayerTaskType == PlayerTaskType.MINION_ATTACK)
				//{
				//	bool ownMinionDies = Task.Source.Card.Health - Task.Target.AttackDamage < 0;
				//	if (ownMinionDies && opponent.BoardZone.Count() > 0)
				//		reward -= 100;
				//	else
				//		reward += 500;
				//}

				//if (Task.HasSource)
				//{
				//	var source = Task.Source;

				//	if(source is Spell spell)
				//	{
				//		if (spell.Cost == 0)
				//		{
				//			if (spell.Card.Name.Equals("The Coin"))
				//			{

				//				if (player.BaseMana == 10)
				//					reward -= 1000;
				//				if (parent.Turn < 4)
				//					reward -= 1000;

				//				if (player.HandZone.Count == 0)
				//				{
				//					reward -= 1000;
				//				}
				//				else
				//				{
				//					List<string> cardsPlayed = new List<string>()
				//					{
				//						"Lorewalker Cho", "Mind Vision", "Cutpurse", "Mana Wyrm"
				//					};
				//					var handzone = player.HandZone;
				//					var deckzone = player.DeckZone;
				//					var onHand = handzone.Where(c => cardsPlayed.Contains(c.Card.Name));
				//					var inDeck = deckzone.Where(c => cardsPlayed.Contains(c.Card.Name));
				//					//play it first after turn 4

				//					//don't play it when full mana
				//					var cardsCosts = player.HandZone.Where(c => c.Cost > 0);
				//					if(cardsCosts.Count() > 0)
				//					{
				//						IPlayable lowestCostCard = cardsCosts.OrderBy(c => { return c.Cost; }).First();
				//						if (player.RemainingMana == lowestCostCard.Cost)
				//						{
				//							reward += 100;
				//						}
				//						else
				//						{
				//							reward -= 100;
				//						}
				//					}									
				//					else
				//					{
				//						reward -= 1000;
				//					}
				//				}
				//			}
				//			else
				//			{
				//				reward += 100;
				//			}

				//		}
				//		else
				//		{
				//			rewardHand += spell.Cost;
				//		}
				//	}


				//}
				reward += rewardHand * Weights.HandWeight;
				//reward for each player's minion
				reward += (MinionValue(player) - MinionValue(opponent)) * Weights.MinionWeight;

				reward += RewardHealing(player, opponent) * Weights.HealthWeight;

				reward += (player.HandZone.Count - opponent.HandZone.Count) * Weights.HandWeight;

				foreach (Spell secret in player.SecretZone)
				{
					switch (secret.Card.Name)
					{
						//Hunter Secrets
						/*
						case "Explosive Trap":
							break;
						case "Freezing Trap":
							break;
						case "Misdirection":
							break;
						case "Rat Trap":
							break;*/
						case "Snake Trap":
							if (opponent.NumFriendlyMinionsThatAttackedThisTurn > 0)
							{
								var snaketags = new Dictionary<GameTag, int>();
								snaketags.Add(GameTag.HEALTH, 45);
								snaketags.Add(GameTag.ATK, 47);
								snaketags.Add(GameTag.COST, 48);
								snaketags.Add(GameTag.CARD_SET, 183);
								snaketags.Add(GameTag.CLASS, 199);
								snaketags.Add(GameTag.CARDRACE, 200);
								snaketags.Add(GameTag.FACTION, 201);
								snaketags.Add(GameTag.CARDTYPE, 202);
								snaketags.Add(GameTag.AttackVisualType, 251);
								reward += GetMinionValue(new Minion(player, Cards.FromId("EX1_554t"), snaketags)) * Weights.MinionWeight;
							}
							break;
						case "Snipe":
							//after op plays a minion deal 4 damge to it
							reward += 100;
							break;
						//Mage Secrets
						case "Counterspell":
							//counters opponent's spell
							reward += 100;
							break;
						case "Ice Barrier":
							//when your hero is attacked gain 8 armor;
							reward += (opponent.Hero.ValidAttackTargets.Contains(player.Hero) ? 8 : 0) * Weights.HealthWeight;
							break;
						case "Mirror Entity":
							//summons a copy of the recent played enemy minion
							reward += opponent.NumMinionsPlayedThisTurn > 0 ? 100 : 0;
							break;
						case "Spellbender":
							//if enemy cast a spell on minion, summon a 1/3 as the new target
							reward += 100;
							break;
						case "Splitting Image":
							//summons a minion of one of player's minion which is attacked
							var attackedMinion = opponent.BoardZone.Where(m => m.IsAttacking).FirstOrDefault();
							if (attackedMinion != null)
							{
								int a = 0;
								//	reward += GetMinionValue(attackedMinion.ValidAttackTargets.FirstOrDefault());
							}

							break;
						case "Vaporize":
							//if op minion attacks pl hero, destroy it
							reward += 100;
							break;
						//Paladin Secrets
						case "Autodefense Matrix":
							//same weight as for minion value for divine shield
							if (opponent.NumAttacksThisTurn > 0)
								reward += 2 * Weights.SecretsWeight;
							break;
						case "Eye for an Eye":
							int maxAttack = 0;
							int countAttacks = opponent.BoardZone.Count;
							if (opponent.BoardZone.Count > 0)
								maxAttack = opponent.BoardZone.Sum(m => m.AttackDamage);
							if (opponent.Hero.Weapon != null)
							{
								maxAttack += opponent.Hero.Weapon.AttackDamage;
								countAttacks++;
							}
							if (opponent.Hero.HeroPowerDamage > 0)
							{
								maxAttack += opponent.Hero.HeroPowerDamage;
								countAttacks++;
							}
							if (countAttacks > 0)
							{
								maxAttack /= countAttacks;
							}


							reward += (maxAttack + secret.Cost) * Weights.SecretsWeight;
							break;
						case "Hidden Wisdom":
							reward += (opponent.NumCardsPlayedThisTurn > 3 ? 2 : 0) * Weights.SecretsWeight;
							break;
						/*case "Never Surrender":
							break;*/
						case "Noble Sacrifice":
							if (opponent.NumFriendlyMinionsThatAttackedThisTurn > 0)
							{
								var defenderTags = new Dictionary<GameTag, int>();
								defenderTags.Add(GameTag.HEALTH, 45);
								defenderTags.Add(GameTag.ATK, 47);
								defenderTags.Add(GameTag.COST, 48);
								defenderTags.Add(GameTag.CARD_SET, 183);
								defenderTags.Add(GameTag.CLASS, 199);
								defenderTags.Add(GameTag.CARDRACE, 200);
								defenderTags.Add(GameTag.FACTION, 201);
								defenderTags.Add(GameTag.CARDTYPE, 202);
								defenderTags.Add(GameTag.RARITY, 203);
								defenderTags.Add(GameTag.SECRET, 219);
								defenderTags.Add(GameTag.COLLECTIBLE, 321);
								defenderTags.Add(GameTag.AttackVisualType, 251);
								defenderTags.Add(GameTag.ARTISTNAME, 342);

								reward += GetMinionValue(new Minion(player, Cards.FromId("EX1_554t"), defenderTags)) * Weights.MinionWeight; ;
							}
							break;
						case "Redemption":
							if (player.GraveyardZone.Count > 0 && player.GraveyardZone.Last() is Minion graveMinion)
							{
								reward += (GetMinionValue(graveMinion) - graveMinion.BaseHealth + 1) * Weights.MinionWeight;
							}

							break;
						case "Repentance":
							if (opponent.NumMinionsPlayedThisTurn > 0)
							{
								int maxHealth = 0;
								int countHealth = opponent.BoardZone.Count;
								if (opponent.BoardZone.Count > 0)
									maxAttack = opponent.BoardZone.Sum(m => m.Health);
								if (opponent.Hero.Weapon != null)
								{
									maxHealth += opponent.Hero.Weapon.AttackDamage;
									countHealth++;
								}
								maxHealth += opponent.Hero.HeroPowerDamage;
								maxHealth /= (countHealth + 1);

								reward += (maxHealth + secret.Cost) * Weights.SecretsWeight;

							}
							else
							{
								reward += secret.Cost * Weights.SecretsWeight;
							}
							break;
						//Wild Format Secrets
						/*case "Avenge":
							break;
						case "Competitive Spirit":
							break;
						case "Getaway Kodo":
							break;
						case "Sacred Trial":
							break;
						case "Bear Trap":
							break;
						case "Cat Trick":
							break;
						case "Cheat Death":
							break;
						case "Dart Trap":
							break;
						case "Evasion":
							break;
						case "Hidden Cache":
							break;*/
						case "Sudden Betrayal":
							// an op minion which trys to attack pl hero, attacks one of it's neighbors
							if (opponent.BoardZone.Count > 1)
								reward += 100;
							break;
						/*case "Venomstrike Trap":
							break;*/
						case "Arcane Blast":
							if (opponent.BoardZone.Where(m => { return m.Id == secret.CardTarget; }).FirstOrDefault() != null
								|| opponent.Hero.Id == secret.CardTarget)
								reward += 2 + player.CurrentSpellPower * 2;
							break;

						case "Frozen Clone":
							//add two copies of a minion to pl's hand which was currently played by the opponent
							if (opponent.BoardZone.Count > 0)
							{
								//this minion must not be the last summoned/played one
								var minion = opponent.BoardZone.Where(m => m.TurnStart).FirstOrDefault();
								if (minion != null)
								{

									//remove costs from reward
									reward += (GetMinionValue(minion) - minion.Cost) * 2;
								}
							}

							break;
						/*case "Ice Block":
							break;*/
						case "Mana Bind":
							//get a copy of opponents casted spell
							reward += 100;
							break;
						/*case "Potion of Polymorph":
							break;
						//Other Secrets
						case "Desperate Measures":
							break;
						case "Secret Plan":
							break;
						case "Secretkeeper":
							break;
						case "Flare":
							break;
						case "Mysterious Blade":
							break;
						case "Sunreaver Spy":
							break;
						case "Commander Rhyssa":
							break;
						case "Eaglehorn Bow":
							break;
						case "Ethereal Arcanist":
							break;
						case "Chief Inspector":
							break;
						case "Subject 9":
							break;
						*/
						//found during playing
						case "Open the Waygate":
							//cast 6 spells that didn't start in your deck
							//reward: extra turn
							reward += 500;
							break;
						case "Explosive Runes":
							//deals 6 damage to minion, reminding to op hero
							int damage = 6;
							reward += damage + player.CurrentSpellPower;
							break;
						case "The Last Kaleidosaur":
							//cast 6 spells on your minions
							//TODO how to reward this?
							break;
						case "Awaken the Makers":
							//summon 7 deathrattle minions
							//TODO how to reward this?
							break;
						case "Lakkari Sacrifice":
							//discard 6 carts, get nether portal
							//summons 2x 3/2 imps at the end of each turn
							//see Carddefs.xml "Nether Imp"
							var netherimptags = new Dictionary<GameTag, int>();
							netherimptags.Add(GameTag.ARTISTNAME, 342);
							netherimptags.Add(GameTag.HEALTH, 47);
							netherimptags.Add(GameTag.ATK, 47);
							netherimptags.Add(GameTag.COST, 48);
							netherimptags.Add(GameTag.CARD_SET, 183);
							netherimptags.Add(GameTag.CLASS, 199);
							netherimptags.Add(GameTag.CARDRACE, 200);
							netherimptags.Add(GameTag.CARDTYPE, 202);
							reward += 2 * GetMinionValue(new Minion(player, Cards.FromId("UNG_829t3"), netherimptags)) * Weights.MinionWeight;
							break;
						default:
							//Console.WriteLine("Unknown Secret: " + secret.Card.FullPrint());
							reward += secret.Cost * Weights.SecretsWeight;
							break;

					}
				}

				if(player.Hero.Power != null)
				{
					int power = 0;
				}
				reward += player.Hero.Weapon != null ? player.Hero.Weapon.AttackDamage + player.Hero.Weapon.Durability : 0;

				reward += (player.Hero.Health + player.Hero.Armor - (opponent.Hero.Health + opponent.Hero.Armor)) * Weights.HealthWeight;
				reward += (player.NumSecretsPlayedThisGame - opponent.NumSecretsPlayedThisGame) * Weights.SecretsWeight;
				//deck reward
				reward += (Math.Sqrt(player.DeckZone.Count) - player.Hero.Fatigue) * Weights.DeckWeight
						- (Math.Sqrt(opponent.DeckZone.Count) - opponent.Hero.Fatigue) * Weights.DeckWeight;
				//reward for empty enemy board zone
				reward += (player.BoardZone.Count - opponent.BoardZone.Count) * Weights.BoardZoneCountWeight;

				//if(opponent.HeroClass == CardClass.PALADIN || opponent.HeroClass == CardClass.ROGUE
				//	|| opponent.HeroClass == CardClass.SHAMAN || opponent.HeroClass == CardClass.PRIEST)
				reward += (player.CurrentSpellPower - opponent.CurrentSpellPower) * Weights.SpellPowerWeight;

				Reward += reward;
			}
		}

		private int GetMinionValue(Minion minion)
		{
			int reward = 0;
			if (minion.IsFrozen)
			{   //ignore it completly or add some reward since it can still be used as shield?
				if (minion.HasTaunt)
				{
					reward += minion.Health + minion.Armor;
				}
			}
			else
			{
				reward += minion.Health + minion.AttackDamage + minion.Armor;
			}

			if (minion.IsSilenced)
				reward -= 1;

			if (minion.Poisonous)
				reward += 1;

			if (minion.HasBattleCry)
				reward += 2;

			if (minion.HasCharge)
				reward += 2;

			if (minion.HasDeathrattle)
				reward += 2;

			if (minion.HasDivineShield)
				reward += 2;

			if (minion.HasInspire)
				reward += 1;

			if (minion.HasLifeSteal)
				reward += 1;

			if (minion.HasStealth)
				reward += 1;

			if (minion.HasTaunt)
				reward += 2;

			if (minion.HasWindfury)
				reward += 1;

			if (minion.HasAnyValidAttackTargets && minion.CanAttack)
				reward += 10;

			if (minion.NumAttacksThisTurn > 0)
				reward += 5;

			return reward;
		}
		private int MinionValue(Controller player)
		{
			int reward = 0;
			foreach (Minion m in player.BoardZone)
			{
				reward += GetMinionValue(m);

			}
			return reward;
		}

		/// <summary>
		/// Calcs Reward for Cards in HandZone.
		/// TODO Not sure how to rate them..
		/// </summary>
		/// <returns>rward</returns>
		private int RewardHandCards(Controller player, Controller opponent)
		{
			//give punishment for more than 5 cards, prefere

			int firstThreeCardsWeight = 4;
			int lastTwoCarsWeight = firstThreeCardsWeight - 1;
			int cardsOnHand = player.HandZone.Count;

			int rewardFirstThree = firstThreeCardsWeight * Math.Min(3, cardsOnHand);
			int rewardLastTwo = 0;
			int additonalReward = 0;
			if (cardsOnHand > 3 && cardsOnHand <= 5)
			{
				rewardLastTwo = lastTwoCarsWeight * Math.Min(2, cardsOnHand - 3);
			}
			else
			{
				//punishement smaller 0?
			}
			//if (CakeWinner.Strategy == Meta.Strategy.Fatigue && opponent.HandZone.Count > 9)
			//{
			//	additonalReward += 1000;
			//}
			return rewardFirstThree + lastTwoCarsWeight + additonalReward;
		}

		private int RewardHealing(Controller player, Controller opponent)
		{
			if (player.Hero.BaseHealth > player.Hero.Health && player.AmountHeroHealedThisTurn > 0)
			{
				if (opponent.HeroClass == CardClass.HUNTER)
					return 200;
				return 150;
			}
			else
				return 0;
		}


		public override string ToString()
		{
			string text = Task != null ? Task.ToString() : "";
			return text + " Value: " + Value;
		}

		public int CompareTo(State other)
		{
			return Value.CompareTo(other.Value);
		}
	}
}
