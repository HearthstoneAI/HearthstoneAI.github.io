﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SabberStoneCoreAi.src.Agent.Helper
{
	class Weights
	{
		public float BoardZoneCountWeight { get; set; } = 1;
		public float MinionToHealthTauntWeight { get; set; } = 1;
		public float MinionAttackWeight { get; set; } = 1;
		public float HealthWeight { get; set; } = 1;
		public float DeckWeight { get; set; } = 1;
		public float BoardHealthWeight { get; set; } = 1;
		public float SpellPowerWeight { get; set; } = 1;
		public float SecretsWeight { get; set; } = 1;
		public float MinionsKilledWeight { get; set; } = 1;
		public float NumAttackWeight { get; set; } = 1;
		public float HandWeight { get; internal set; } = 1;
		//Combination of MinionAttack-, MinionHealthToTauntWeight
		public float MinionWeight { get; internal set; } = 1;

		public float SpellDamageBonusWeight { get; set; } = 1;

		public float HealWeight { get; set;} = 1;
		public float BoardSpellPowerWeight { get; set; } = 1;

		public Weights Copy()
		{
			var copy = new Weights();

			copy.BoardZoneCountWeight = BoardZoneCountWeight;
			copy.HealthWeight = HealthWeight;
			copy.DeckWeight = DeckWeight;
			copy.SecretsWeight = SecretsWeight;
			copy.MinionWeight = MinionWeight;
			copy.HandWeight = HandWeight;

			//used only in the score classes
			copy.MinionToHealthTauntWeight = MinionToHealthTauntWeight;
			copy.MinionAttackWeight = MinionAttackWeight;
			copy.BoardHealthWeight = BoardHealthWeight;
			copy.SpellPowerWeight = SpellPowerWeight;
			copy.MinionsKilledWeight = MinionsKilledWeight;
			copy.NumAttackWeight = NumAttackWeight;
			copy.SpellDamageBonusWeight = SpellDamageBonusWeight;
			copy.HealWeight = HealWeight;
			copy.BoardSpellPowerWeight = BoardSpellPowerWeight;
			return copy;
		}



		public void AddWeights(Weights add)
		{
			BoardZoneCountWeight += add.BoardZoneCountWeight;
			HealthWeight += add.HealthWeight;
			DeckWeight += add.DeckWeight;
			SecretsWeight += add.SecretsWeight;
			MinionWeight += add.MinionWeight;
			HandWeight += add.HandWeight;

			//used only in the score classes
			MinionToHealthTauntWeight += add.MinionToHealthTauntWeight;
			MinionAttackWeight += add.MinionAttackWeight;
			BoardHealthWeight += add.BoardHealthWeight;
			SpellPowerWeight += add.SpellPowerWeight;
			MinionsKilledWeight += add.MinionsKilledWeight;
			NumAttackWeight += add.NumAttackWeight;
			SpellDamageBonusWeight += add.SpellDamageBonusWeight;
			HealWeight += add.HealWeight;
			BoardSpellPowerWeight += add.BoardSpellPowerWeight;
		}

		public void AvgWeights(int count)
		{
			BoardZoneCountWeight /= count;
			HealthWeight /= count;
			DeckWeight /= count;
			SecretsWeight /= count;
			MinionWeight /= count;
			HandWeight /= count;

			//used only in the score classes
			MinionToHealthTauntWeight /= count;
			MinionAttackWeight /= count;
			BoardHealthWeight /= count;
			SpellPowerWeight /= count;
			MinionsKilledWeight /= count;
			NumAttackWeight /= count;
			SpellDamageBonusWeight /= count;
			HealWeight /= count;
			SpellPowerWeight /= count;
		}
		public void FactorWeights(float factor)
		{
			BoardZoneCountWeight *= factor;
			HealthWeight *= factor;
			DeckWeight *= factor;
			SecretsWeight *= factor;
			MinionWeight *= factor;
			HandWeight *= factor;

			//used only in the score classes
			MinionToHealthTauntWeight *= factor;
			MinionAttackWeight *= factor;
			BoardHealthWeight *= factor;
			SpellPowerWeight *= factor;
			MinionsKilledWeight *= factor;
			NumAttackWeight *= factor;
			SpellDamageBonusWeight *= factor;
			HealWeight *= factor;
			SpellPowerWeight *= factor;
		}
		internal void InitZero()
		{
			BoardZoneCountWeight = 0;
			HealthWeight = 0;
			DeckWeight = 0;
			SecretsWeight = 0;
			MinionWeight = 0;
			HandWeight = 0;

			//used only in the score classes
			MinionToHealthTauntWeight = 0;
			MinionAttackWeight = 0;
			BoardHealthWeight = 0;
			SpellPowerWeight = 0;
			MinionsKilledWeight = 0;
			NumAttackWeight = 0;
			SpellDamageBonusWeight = 0;
		}

		internal void InitRandom(Random random, int lower = 1, int upper = 100)
		{
			BoardZoneCountWeight = random.Next(lower, upper);
			MinionToHealthTauntWeight = random.Next(lower, upper);
			MinionAttackWeight = random.Next(lower, upper);
			HealthWeight = random.Next(lower, upper);
			DeckWeight = random.Next(lower, upper);
			BoardHealthWeight = random.Next(lower, upper);
			SpellPowerWeight = random.Next(lower, upper);
			SecretsWeight = random.Next(lower, upper);
			MinionsKilledWeight = random.Next(lower, upper);
			NumAttackWeight = random.Next(lower, upper);
			MinionWeight = random.Next(lower, upper);
			HandWeight = random.Next(lower, upper);
			SpellDamageBonusWeight = random.Next(lower, upper);
			HealWeight = random.Next(lower, upper);
			BoardSpellPowerWeight = random.Next(lower, upper);
		}

		internal void SetHunterRangeScore()
		{
			BoardZoneCountWeight = 5;
			MinionToHealthTauntWeight = -1000;
			MinionAttackWeight = 10;
			HealthWeight = 10;
			BoardHealthWeight = 10;
			SpellPowerWeight = 10;
			SecretsWeight = 10;
		}

		internal void SetRougeScore()
		{
			BoardZoneCountWeight = 5;
			MinionToHealthTauntWeight = -1000;
			MinionAttackWeight = 10;
			HealthWeight = 10;
			DeckWeight = (DeckWeight + 67.1f) / 2;
			BoardHealthWeight = 10;
			SpellPowerWeight = 10;
			SecretsWeight = 10;
			SpellDamageBonusWeight = 500;
		}

		public void SetControlScoreWeight()
		{
			BoardZoneCountWeight = 50;
			MinionToHealthTauntWeight = 60;
			MinionAttackWeight = 50;
			HealthWeight = 40;
			DeckWeight = 10;
			BoardHealthWeight = 40;
			SpellPowerWeight = 60;
			SecretsWeight = 60;
			MinionsKilledWeight = 50;
			NumAttackWeight = 50;
			HealWeight = 50;
			BoardSpellPowerWeight = 20;
			HandWeight = 300;
		}

		public void SetFatiqueScoreWeight()
		{
			BoardZoneCountWeight = 10;
			MinionToHealthTauntWeight = 10;
			MinionAttackWeight = 50;
			HealthWeight = 5;
			DeckWeight = 50;
			BoardHealthWeight = 40;
			SpellPowerWeight = 40;
			SecretsWeight = 60;
			MinionsKilledWeight = 50;
			NumAttackWeight = 50;
		}

		public void SetRenoKazakusMageWeights()
		{
			BoardZoneCountWeight = 22.5f;
			MinionToHealthTauntWeight = 0;
			MinionAttackWeight = 91;
			HealthWeight = 63;
			DeckWeight = 67.1f;
			BoardHealthWeight = 36;
			SpellPowerWeight = 60;
			SecretsWeight = 35.9f;
			MinionsKilledWeight = 1;
			NumAttackWeight = 1;
			MinionWeight = 5;
			HandWeight = 5;
		}

		public void SetPalaWeight()
		{
			BoardZoneCountWeight = 48.3f;
			MinionToHealthTauntWeight = 25;
			MinionAttackWeight = 46.4f;
			HealthWeight = 49.9f;
			DeckWeight = 37.4f;
			BoardHealthWeight = 61;
			SpellPowerWeight = 73;
			SecretsWeight =  52.6f;
			MinionsKilledWeight = 31;
			NumAttackWeight = 87;
			MinionWeight = 38.6f;
			HandWeight = 51.4f;
		}

		public void SetPriestWeight()
		{
			BoardZoneCountWeight = 54.2f;
			HealthWeight = 42.2f;
			DeckWeight = 70.7f;
			SecretsWeight = 23.2f;
			MinionWeight = 50;
			HandWeight = 80;

			MinionToHealthTauntWeight = 45.9f;
			MinionAttackWeight = 49;
			BoardHealthWeight = 3;
			SpellPowerWeight = 90;
			MinionsKilledWeight = 25;
			NumAttackWeight = 7;

		}

		public void SetRougeWeight()
		{
			BoardZoneCountWeight = 31.1f;
			MinionToHealthTauntWeight = 95;
			MinionAttackWeight = 77;
			HealthWeight = 34.5f;
			DeckWeight =  53.9f;
			BoardHealthWeight = 30;
			SpellPowerWeight = 97;
			SecretsWeight = 44.8f;
			MinionsKilledWeight = 62;
			NumAttackWeight = 35;
			MinionWeight = 5;
			HandWeight = 5;
		}

		public void SetShamanWeight()
		{
			BoardZoneCountWeight = 55.7f;
			MinionToHealthTauntWeight = 47;
			MinionAttackWeight =  31;
			HealthWeight = 53.8f;
			DeckWeight = 44.5f;
			BoardHealthWeight = 87;
			SpellPowerWeight = 94;
			SecretsWeight = 31.3f;
			MinionsKilledWeight = 51;
			NumAttackWeight = 45;
			MinionWeight = 5;
			HandWeight = 5;
		}

		public void SetWarlockWeight()
		{
			BoardZoneCountWeight = 45;
			MinionToHealthTauntWeight = 6;
			MinionAttackWeight = 68;
			HealthWeight = 63.1f;
			DeckWeight = 48.6f;
			BoardHealthWeight = 7;
			SpellPowerWeight = 5;
			SecretsWeight = 48.9f;
			MinionsKilledWeight = 48;
			NumAttackWeight = 13;
			MinionWeight = 5;
			HandWeight = 5;
		}
		public void SetWarriorWeight()
		{
			BoardZoneCountWeight = 55.2f;
			MinionToHealthTauntWeight = 15;
			MinionAttackWeight = 37;
			HealthWeight = 55.4f;
			DeckWeight = 49.8f;
			BoardHealthWeight = 88;
			SpellPowerWeight = 41;
			SecretsWeight = 24;
			MinionsKilledWeight = 91;
			NumAttackWeight = 16;
			MinionWeight = 5;
			HandWeight = 5;
		}

		
		public void PrintWeights()
		{
			Console.WriteLine(BoardZoneCountWeight + " " + MinionToHealthTauntWeight + " " + MinionAttackWeight + " "
				+ HealthWeight + " " + DeckWeight + " " + BoardHealthWeight + " " + SpellPowerWeight + " "
				+ SecretsWeight + " " + MinionsKilledWeight + " " + NumAttackWeight + " " + MinionWeight + " " + HandWeight + " "
				+ SpellDamageBonusWeight + " " + HealWeight + " " + BoardSpellPowerWeight);
		}
	}
}
