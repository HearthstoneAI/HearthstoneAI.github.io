﻿using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.src.Agent.SearchTree;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SabberStoneCoreAi.src.Agent
{
	/// <summary>
	/// Like the normal ggreedy but uses our state class for the scores
	/// </summary>
	class Greedy
	{
		private readonly float EPSILON = 1e-3f;

		/// <summary>
		/// Simulates games using e-greedy from parent node
		/// Adds successfull simulation as childs to parent node
		/// and returns a child node based upon e-greedy method
		/// </summary>
		/// <param name="currentNode"></param>
		/// <returns></returns>
		public TreeNode ChooseAction(TreeNode currentNode)
		{
			POGame.POGame game = currentNode.Value.Game;
			if(game == null && currentNode.ParentNode != null)
			{
				game = currentNode.ParentNode.Value.Game;
			}
			//Check if simulation is necessary
			if (currentNode.IsLeaf())
			{
				
				Controller player = game.CurrentPlayer;

				// Get all simulation results for simulations that didn't fail
				//IEnumerable<KeyValuePair<PlayerTask, POGame.POGame>> validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);
				var states = new List<Helper.State>();
				foreach (PlayerTask opt in player.Options())
				{
					//var state = new Helper.State(opt.Value, opt.Key, CakeWinner.weights);
					var state = new Helper.State(opt, CakeWinner.Weights);
					state.SimulateGame(game);
					state.Visits++;

					if (state.Game != null)
					{
						states.Add(state);
					}

				}
				// If all simulations failed, play end turn option (always exists), else best according to score function
				//fi no childs return parent node
				if (CakeWinner.Random.NextFloat(0, 1) < EPSILON)
				{
					//Chooose Random
					return states.Any() ? new TreeNode(states[CakeWinner.Random.Next(states.Count)]) : currentNode;
				}
				else
				{
					//Choose best state so far
					return states.Any() ? new TreeNode(states.OrderBy(x => x.AvgReward()).Last()) : currentNode;
				}
			}
			else
			{
				List<TreeNode> childs = currentNode.ChildNodes;
				if (CakeWinner.Random.NextFloat(0, 10) < EPSILON)
				{
					//Chooose Random
					return childs.Any() ? childs[CakeWinner.Random.Next(childs.Count)] : currentNode;
				}
				else
				{
					//Choose best state so far
					return childs.Any() ? childs.OrderBy(x => x.Value.AvgReward()).Last() : currentNode;
				}
			}
			
		}

		/// <summary>
		/// Simulates all choices of current player of game and returns the best Task based upon e-greedy-method
		/// </summary>
		/// <param name="game"></param>
		/// <returns></returns>
		public PlayerTask ChooseAction(POGame.POGame game)
		{
			var player = game.CurrentPlayer;
			var validOpts = game.Simulate(player.Options()).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			if (CakeWinner.Random.NextFloat(0, 1) < EPSILON)
			{
				int count = validOpts.Count();
				//Chooose Random
				return validOpts.Any() ?
				validOpts.ElementAt(CakeWinner.Random.Next(count)).Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
			}
			else
			{
				// If all simulations failed, play end turn option (always exists), else best according to score function
				return validOpts.Any() ?
					validOpts.OrderBy(x => CalcScore(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
			}
		}

			private double CalcScore(POGame.POGame state, int playerId)
			{
				var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
				switch (state.CurrentPlayer.HeroClass)
				{
					case CardClass.WARRIOR: return new RampScore { Controller = p }.Rate(); 
					case CardClass.MAGE: return new MyControlScore { Controller = p }.Rate();
					case CardClass.HUNTER: return new HunterMidRangeScore { Controller = p }.Rate(); 
					case CardClass.ROGUE: return new RogueRangeScore { Controller = p }.Rate();
					case CardClass.SHAMAN: return new RogueRangeScore { Controller = p }.Rate(); 
					case CardClass.PALADIN: return new RogueRangeScore { Controller = p }.Rate(); 
					case CardClass.WARLOCK: return new MyControlScore { Controller = p }.Rate(); 
					case CardClass.PRIEST: return new RogueRangeScore { Controller = p }.Rate(); 
				default: return new MidRangeScore { Controller = p }.Rate();
				}
			}
		}
}
