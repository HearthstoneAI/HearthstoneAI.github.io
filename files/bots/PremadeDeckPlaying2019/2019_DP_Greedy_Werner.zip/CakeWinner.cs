﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.src.Agent.Helper;
using SabberStoneCoreAi.src.Agent.SearchTree;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.Meta;
using SabberStoneCoreAi.src.Agent;

namespace SabberStoneCoreAi.src.Agent
{
	class CakeWinner : AbstractAgent
	{
		public static Weights Weights = new Weights();
		public static readonly Helper.Random Random = new Helper.Random(DateTime.Now.Millisecond);
		public static int PlayerID { get; private set; } = -1;
		private int enemyID = -1;
		public static double TimeTurnStart { get; private set; } = 0;
		public static readonly double MAXTURNTIME = 75000.0; //ms
		public static int currentTurn = -1;

		private bool useGreedyOnly = false;

		private SearchTree.SearchTree searchTree;

		private bool BeginTurn { get; set; } = true;
		Greedy Greedy = new Greedy();

		public override void FinalizeAgent() {}

		public override void FinalizeGame() {}

		public override void InitializeAgent() {}

		public override void InitializeGame() {}

		public override PlayerTask GetMove(POGame.POGame game)
		{
			//Console.WriteLine("Turn " + game.Turn);
			//Console.WriteLine("Enemy: " + game.CurrentOpponent.Hero.FullPrint());
			//Console.WriteLine("Player: " + game.CurrentPlayer.Hero.FullPrint());
			//Console.WriteLine("Game Board");
			//Console.WriteLine(game.FullPrint());


			if (BeginTurn)
			{
				TimeTurnStart = Utility.getSecondsSinceStart();
				currentTurn = game.Turn;
				if (PlayerID == -1)
				{					
					PlayerID = game.CurrentPlayer.PlayerId;
					enemyID = game.CurrentOpponent.PlayerId;
				}
				//TODO get better weights for Pala, Priest, Rouge, Shaman and Warlock
				// They cause a -20% when CakeWinner is P2, default weights make around 50% :D
				// Also they reduce the winrate a bit as P1 as well :(
				switch (game.CurrentPlayer.HeroClass)
				{
					case CardClass.MAGE:
						//Currently a ca. +5%
						Weights.SetRenoKazakusMageWeights();
						break;
					case CardClass.PALADIN:
						//Weights.SetPalaWeight();
						break;
					case CardClass.PRIEST:
						//Weights.SetPriestWeight();
						break;
					case CardClass.ROGUE:
						//Weights.SetRougeWeight();
						break;
					case CardClass.SHAMAN:
						//Weights.SetShamanWeight();
						break;
					case CardClass.WARLOCK:
						//Weights.SetWarlockWeight();
						break;
					case CardClass.WARRIOR:
						//as P1 around 80% as p2 around 70 (or +10% vs. defaults)
						Weights.SetWarriorWeight();
						break;
					case CardClass.DEATHKNIGHT:
					case CardClass.DRUID:
					case CardClass.HUNTER:
					case CardClass.DREAM:
					case CardClass.NEUTRAL:
					case CardClass.WHIZBANG:
					case CardClass.INVALID:
					default:
						Weights.InitRandom(Random);
						break;
				}

				//resulting pogame of search is not the same when GetMove() is called again 
				BeginTurn = false;
			}


			PlayerTask selectedTask;
			if (game.CurrentPlayer.Options().Count > 1)
			{
				if (useGreedyOnly )//||  game.CurrentPlayer.PlayerId != 1)
				{
					selectedTask = Greedy.ChooseAction(game);
				}
				else
				{
					searchTree = new SearchTree.SearchTree(game, Random);
					selectedTask = searchTree.ChooseAction();
				}
			}
			else
			{
				selectedTask = game.CurrentPlayer.Options()[0];
			}
			
			
			if (selectedTask.PlayerTaskType == PlayerTaskType.END_TURN)
			{
				//Console.WriteLine("Used time: " + (Utility.getSecondsSinceStart() - TimeTurnStart) + "ms");
				BeginTurn = true;
			}

			return selectedTask;
		}
	}
			
}
