﻿
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Meta;
using SabberStoneCoreAi.src.Agent.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SabberStoneCoreAi.src.Agent.SearchTree
{
	class SearchTree
	{
		private POGame.POGame RootGame { get; set; }
		private TreeNode RootNode { get; set; }
		private readonly float EPSILON = 1e-6f;
		private readonly double EXPLORATIONTHRESHOLD = 2 * (1 / Math.Sqrt(2));
		private Helper.Random Random { get; set; }
		private static int maxEpisodes = 100;
		public SearchTree(POGame.POGame rootGame, Helper.Random random)
		{
			RootGame = rootGame;
			Random = random;
			RootNode = new TreeNode(new State(RootGame, null, CakeWinner.Weights));
		}

		public PlayerTask ChooseAction()
		{
			//maybe run more simulations..
			Expand(RootNode);
			if(RootNode.ChildNodes.Count == 0)
			{
				return new Greedy().ChooseAction(RootGame);
			}
			for (int sims = 1; sims <= maxEpisodes; sims++)
			{
				if ((Utility.getSecondsSinceStart() - CakeWinner.TimeTurnStart) > CakeWinner.TimeTurnStart)
				{
					//Console.WriteLine("Took to long, num episodes complete: " + (sims - 1) );
					//break;
				}
				//do some simulations
				TreeNode simNode = Select(RootNode, sims);
				if (simNode != null)
				{
					State state = simNode.Value;

					Simulation(simNode);
					state.UpdateValue();
				}
			}

			IOrderedEnumerable<TreeNode> select = RootNode.ChildNodes.OrderBy(c =>
			{
				return c.Value.Value;
			});
			var test = select.Last().Value.Task;

			return select.Last().Value.Task;
		}

		private void Expand(TreeNode expandNode)
		{
			State expandState = expandNode.Value;
			POGame.POGame poGame = expandState.Game;
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			if(options.Count() > 0)
			{
				foreach(PlayerTask option in options)
				{
					var childState = new State(option, CakeWinner.Weights);
					childState.SimulateGame(poGame);
					if(childState.Game != null)
					{
						expandNode.AddChildNode(childState);
					}
					else
					{
						int nullVal = 0;
					}
					
				}
			} else
			{
				int how = 0;
			}
		}
	
		private TreeNode Select(TreeNode currentNode, int episode)
		{
			State currentState = currentNode.Value;

			IOrderedEnumerable<TreeNode> select = currentNode.ChildNodes.OrderBy(c =>
			{
				return (c.Value.TimesWon / (c.Value.Visits + EPSILON) +
				EXPLORATIONTHRESHOLD * Math.Sqrt(2*Math.Log(episode) / c.Value.Visits)
				+ Random.NextDouble() * EPSILON);
				// small random number to break ties randomly in unexpanded nodes
			});

			return select.Last();
		} 

		private void Simulation(TreeNode node)
		{
			var nodeState = node.Value;
			var parent = nodeState.Game;
			var options = parent.CurrentPlayer.Options();
			var option = options[Random.Next(options.Count())];

			var child = parent.Simulate(new List<PlayerTask>() { option })[option];
			node.Explore(child, Random);
		}
	}
}
