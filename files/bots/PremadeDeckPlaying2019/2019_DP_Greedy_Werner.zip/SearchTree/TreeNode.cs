﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.src.Agent.Helper;

namespace SabberStoneCoreAi.src.Agent.SearchTree
{
	class TreeNode
	{
		public State Value { get; private set; }
		public TreeNode ParentNode { get; set; } = null;

		public int CountIgnored { get; set; } = 0;
		public int CountExplored { get; set; } = 0;
		public bool Explored { get; set; } = false;
		public bool Expanded { get; set; } = false;
		public int DepthToRoot { get; set; } = 0;

		public List<TreeNode> ChildNodes { get; private set; } = new List<TreeNode>();

		private TreeNode() {}

		public TreeNode(State node)
		{
			Value = node;
		}

		public TreeNode AddChildNode(TreeNode childNode)
		{
			if (!ChildNodes.Contains(childNode))
			{
				childNode.ParentNode = this;
				childNode.DepthToRoot = DepthToRoot + 1;
				ChildNodes.Add(childNode);
			}
			
			return childNode;
		}

		internal bool IsLeaf()
		{
			return ChildNodes.Count == 0;
		}

		public TreeNode AddChildNode(State child)
		{
			return AddChildNode(new TreeNode(child));
		}

		public void Traverse(Func<TreeNode, bool> action)
		{
			bool stop = action(this);
			if (!stop)
			{
				foreach (TreeNode child in ChildNodes)
				{
					stop = action(child);
					if (!stop)
					{
						child.Traverse(action);
					}
				}
			}
			
			//ChildNodes.ForEach(child => child.Traverse(action));
		}

		internal TreeNode GetRandomChildNode(Helper.Random random)
		{
			if (ChildNodes.Count == 0)
			{
				return null;
			}
			else if (ChildNodes.TrueForAll(node => node.Explored))
			{
				TreeNode leastExploredNode = null;
				foreach(TreeNode node in ChildNodes)
				{
					if (leastExploredNode == null)
					{
						leastExploredNode = node;
					}
					else if(leastExploredNode.CountExplored > node.CountExplored)
					{
						leastExploredNode = node;	
					}
				}
				return leastExploredNode;
			}
			else
			{
				return ChildNodes[random.Next(0, ChildNodes.Count)];
			}
		}

		internal void Reset()
		{
			//ChildNodes.Clear();
			Value.Reset();
		}

		internal void Explore(POGame.POGame child, Helper.Random random)
		{
			if (child != null)
			{
				var options = child.CurrentPlayer.Options();
				var task = options[random.Next(options.Count())];
				
				var simGame = child.Simulate(new List<SabberStoneCore.Tasks.PlayerTasks.PlayerTask>() { task })[task];

				if (simGame != null /*&& simGame.Turn == CakeWinner.currentTurn + 2*/ && task.PlayerTaskType != SabberStoneCore.Tasks.PlayerTasks.PlayerTaskType.END_TURN)
				//if (simGame != null && simGame.State == SabberStoneCore.Enums.State.RUNNING)
				{
					Explore(simGame, random);
				}
				else
				{
					Value.Visits++;

					if (simGame != null)
					{
						Value.CalcReward(simGame);
					}
					else
					{
						Value.CalcReward(child);
					}

				}
			}

		}
	}
}
