﻿#region copyright
// SabberStone, Hearthstone Simulator in C# .NET Core
// Copyright (C) 2017-2019 SabberStone Team, darkfriend77 & rnilva
//
// SabberStone is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License.
// SabberStone is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.src.Agent;
using SabberStoneCoreAi.src.Agent.Helper;

namespace SabberStoneCoreAi.Score
{
	public class MyControlScore : Score
	{
		private Weights Weights { get; set; }

		public MyControlScore()
		{
			Weights = new Weights();
			Weights.SetControlScoreWeight();
			Weights.FactorWeights(1.05f);
		}

		public override int Rate()
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			float result = 0;

			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
				result += 1000;

			result += (BoardZone.Count - OpBoardZone.Count) * Weights.BoardZoneCountWeight;

			result += (MinionTotHealthTaunt - OpMinionTotHealthTaunt) * Weights.MinionToHealthTauntWeight;

			result += MinionTotAtk * Weights.MinionAttackWeight;

			result += (HeroHp - OpHeroHp) * Weights.HealthWeight;
			if (OpHandCnt <= 1)
				result += 300;
			result += (DeckCnt - OpDeckCnt) * Weights.DeckWeight;

			result += (BoardZone.Sum(p => p.Health) - OpBoardZone.Sum(p => p.Health)) * Weights.BoardHealthWeight;

			//result += (BoardZone.Sum(p => p.SpellPower) - OpBoardZone.Sum(p => p.SpellPower)) * Weights.SpellPowerWeight; // ?
			result += Controller.NumSecretsPlayedThisGame * Weights.SecretsWeight;
			result += Controller.NumMinionsPlayerKilledThisTurn * Weights.MinionsKilledWeight;
			result += Controller.NumAttacksThisTurn * Weights.NumAttackWeight;

			//result += Controller.HeroPowerActivationsThisTurn * (CakeWinner.currentTurn < 5 ? 10 : 80);

			result += (BoardZone.Sum(p => p.SpellPower) - OpBoardZone.Sum(p => p.SpellPower)) * Weights.SpellPowerWeight;// 20 // ?
			result += Controller.AmountHeroHealedThisTurn * Weights.HealWeight;// 50;
			result += Controller.CurrentSpellPower * Weights.SpellPowerWeight;//60;
			return (int)result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
