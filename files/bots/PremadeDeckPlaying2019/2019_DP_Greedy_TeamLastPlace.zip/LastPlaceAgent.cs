﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Score;

namespace SabberStoneCoreAi.Competition.Agents
{
	class TeamLastPlace : AbstractAgent
	{
		private Random Rnd = new Random();
		Score.Score controlScore = new ControlScore();
		Score.Score midRangeScore = new MidRangeScore();
		Score.Score aggroScore = new AggroScore();


		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			var player = poGame.CurrentPlayer;

			var validOpts = poGame.Simulate(player.Options()).Where(x => x.Value != null);

			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);

		}

		// Calculate different scores based on our hero's class
		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new AggroScore { Controller = p }.Rate();
				//case CardClass.WARLOCK: return new AggroScore { Controller = p }.Rate();
				//case CardClass.ROGUE: return new AggroScore { Controller = p }.Rate();
				case CardClass.MAGE: return new ControlScore { Controller = p }.Rate();
				case CardClass.PRIEST: return new ControlScore { Controller = p }.Rate();
				default: return new MidRangeScore { Controller = p }.Rate();
			}
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}
	}
}
