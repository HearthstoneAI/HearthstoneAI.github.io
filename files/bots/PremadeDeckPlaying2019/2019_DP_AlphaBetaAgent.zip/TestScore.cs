﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class TestScore : Score
	{
		public Controller EnemyController;
		public int Turn;

		public double emptyFieldValue;
		public double healthValue;
		public double deckValue;
		public double handValue;
		public double minionValue;

		public override int Rate()
		{
			setValues(Controller.HeroClass);

			if (OpHeroHp < 1)
				return int.MaxValue;

			if (HeroHp < 1)
				return int.MinValue;

			int result = 0;

			if (OpBoardZone.Count == 0) result += (int) (emptyFieldValue * (2000 + 1000*Math.Min(Turn, 10)));

			result += (int) (1000 * healthValue * (Math.Sqrt(HeroHp + Controller.Hero.Armor) - Math.Sqrt(OpHeroHp + EnemyController.Hero.Armor)));

			result += (int) (1000 * deckValue * Math.Sqrt(DeckCnt) - Controller.Hero.Fatigue);

			int myHandVal = 3000 * Math.Min(HandCnt, 3) + 2000 * Math.Abs(HandCnt - Math.Min(HandCnt, 3));
			int enemyHandVaL = 3000 * Math.Min(OpHandCnt, 3) + 2000 * Math.Abs(OpHandCnt - Math.Min(OpHandCnt, 3));
			result += (int) (handValue * (myHandVal - enemyHandVaL));

			result += (int) (1000 * minionValue * (getMinionValues(Controller) - getMinionValues(EnemyController)));

			return result;

		}

		float getValueForMinion(Minion minion)
		{
			float value = 0.0f;

			if (!minion.IsFrozen) value += minion.Health + 2*minion.AttackDamage*Math.Max(minion.NumAttacksThisTurn - 1, 0);

			if (minion.HasTaunt) value += 2;
			if (minion.Poisonous) value += 2;
			if (minion.HasDeathrattle) value += 2;
			if (minion.HasInspire) value += 2;
			if (minion.HasDivineShield) value += 2;
			if (minion.HasLifeSteal) value += 2;
			if (minion.HasCharge) value += 1;
			if (minion.HasStealth) value += 1;
			if (minion.HasBattleCry) value += 1;

			return value;
		}

		float getMinionValues(Controller controller)
		{
			float value = 0.0f;

			foreach (Minion m in controller.BoardZone)
			{
				value += getValueForMinion(m);
			}

			return value;
		}

		public void setValues(CardClass myClass)
		{
			//All Values optimized by evolutionary algorithm
			if (myClass == CardClass.WARRIOR)
			{
				emptyFieldValue = 5.2;
				healthValue = 3.9;
				deckValue = 4.2;
				handValue = 1.4;
				minionValue = 8.7;
			}
			else if (myClass == CardClass.SHAMAN)
			{
				emptyFieldValue = 2.8;
				healthValue = 6.4;
				deckValue = 1;
				handValue = 1.9;
				minionValue = 7.7;
			}
			else if (myClass == CardClass.MAGE)
			{
				emptyFieldValue = 3.8;
				healthValue = 3.6;
				deckValue = 10;
				handValue = 0.9;
				minionValue = 4.4;
			}
			else if(myClass == CardClass.DRUID)
			{
				emptyFieldValue = 0.8;
				healthValue = 0.6;
				deckValue = 2.6;
				handValue = 0.6;
				minionValue = 8.4;
			}

			else if(myClass == CardClass.PRIEST)
			{
				emptyFieldValue = 1;
				healthValue = 6.4;
				deckValue = 2.2;
				handValue = 5.7;
				minionValue = 9.2;
			}

			else if(myClass == CardClass.WARLOCK)
			{
				emptyFieldValue = 3.8;
				healthValue = 3.6;
				deckValue = 10;
				handValue = 0.9;
				minionValue = 4.4;
			}

			else if(myClass == CardClass.PALADIN)
			{
				emptyFieldValue = 1.5;
				healthValue = 9.1;
				deckValue = 3.5;
				handValue = 3.5;
				minionValue = 7.1;
			}

			else if(myClass == CardClass.ROGUE)
			{
				emptyFieldValue = 7.6;
				healthValue = 6.9;
				deckValue = 10;
				handValue = 2.2;
				minionValue = 10;
			}

			else if(myClass == CardClass.HUNTER)
			{
				emptyFieldValue = 2.8;
				healthValue = 6.4;
				deckValue = 1;
				handValue = 1;
				minionValue = 9.7;
			}
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
