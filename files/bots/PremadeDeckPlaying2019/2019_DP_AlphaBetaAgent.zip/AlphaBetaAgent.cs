﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Agent.ExampleAgents;
using SabberStoneCoreAi.Meta;
using SabberStoneCoreAi.Score;
using SabberStoneCoreAi.Agent;


namespace SabberStoneCoreAi.Competition.Agents
{
	// Plain old Greedy Bot
	class AlphaBetaAgent : AbstractAgent
	{
		private Queue<PlayerTask> tasks;
		public override void InitializeAgent()
		{
			tasks = new Queue<PlayerTask>();
		}

		public override void InitializeGame()
		{}

		public override void FinalizeGame()
		{
			tasks = new Queue<PlayerTask>();
		}
		public override void FinalizeAgent() {}


		public override PlayerTask GetMove( POGame.POGame game )
		{
			if (game.CurrentPlayer.Options().Count == 1) return game.CurrentPlayer.Options()[0];

			if (tasks.Count == 0)
			{
				var root = new GameNode(game, null, null);
				try
				{
					root.alphabeta(Int32.MinValue, Int32.MaxValue, 3);
					tasks = root.getTasks(game);
				}
				catch (Exception e)
				{
					//Fallback because there are unknown errors which occurs sometimes in the normal method,
					//mostly caused by buggy cards i think?
					var validOpts = game.Simulate( game.CurrentPlayer.Options() ).Where( x => x.Value != null );
					return validOpts.Any() ?
						validOpts.OrderBy( x => FallBack( x.Value) ).Last().Key :
						game.CurrentPlayer.Options().First( x => x.PlayerTaskType == PlayerTaskType.END_TURN );
				}
			}

			//If no viable move found, end turn
			if(tasks.Count == 0) return game.CurrentPlayer.Options()[0];

			return tasks.Dequeue();
		}

		private static int FallBack( POGame.POGame state)
		{
			TestScore myScore = new TestScore();
			myScore.Controller = state.CurrentPlayer;
			myScore.EnemyController = state.CurrentOpponent;
			myScore.Turn = state.Turn;

			return myScore.Rate();
		}
	}
}
