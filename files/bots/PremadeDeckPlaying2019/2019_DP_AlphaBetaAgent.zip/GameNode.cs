﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;

namespace SabberStoneCoreAi.Agent
{
	class GameNode
	{
		public GameNode parent;
		public List<GameNode> children;
		public POGame.POGame state;
		public PlayerTask task;
		public bool myNode;
		public int value;
		public int tasknum;

		public GameNode(POGame.POGame game, PlayerTask task, GameNode parent)
		{
			this.children = new List<GameNode>();
			this.state = game.getCopy();
			this.task = task;
			this.parent = parent;

			if (parent != null)
			{
				if (state.CurrentPlayer.PlayerId == parent.state.CurrentPlayer.PlayerId) myNode = parent.myNode;
				else myNode = !parent.myNode;
			}
			else myNode = true;
		}

		public int alphabeta(int alpha, int beta, int depth)
		{
			if (depth == 0)
			{
				var val = calcValue();

				//Set state and task to null to save ram, tasknum will be used to reconstruct the task at the end
				//The state wont be needed after this
				state = null;
				task = null;

				return val;
			}

			value = myNode ? Int32.MinValue : Int32.MaxValue;

			//To avoid cheating, randomize enemy cards in hand with card from his deck(which we know because its a mirror match)
			//Possible improvement: Implement some kind of learner to learn the most probable cards that could be in the enemy hand
			if (!myNode)
			{
				int numCards = 0;

				foreach (IPlayable c in state.CurrentPlayer.HandZone)
				{
					state.CurrentPlayer.HandZone.Remove(c);
					numCards++;
				}

				while (numCards > 0)
				{
					Card card = Util.Choose(state.CurrentPlayer.DeckZone.Controller.DeckCards.ToList());

					//Dont add more than two of the same card or more than one of the same legendary
					if (state.CurrentPlayer.HandZone.Count(c => c.Card == card) +
					    state.CurrentPlayer.GraveyardZone.Count(c => c.Card == card) +
					    state.CurrentPlayer.BoardZone.Count(c => c.Card == card) < card.MaxAllowedInDeck)
					{
						state.CurrentPlayer.HandZone.Add( Entity.FromCard(state.CurrentPlayer.DeckZone.Controller, card));
						numCards--;
					}
				}
			}

			//Without this the state bugs out, probably because of the randomized cards in hand
			state = state.getCopy();

			for (int i = 0; i < state.CurrentPlayer.Options().Count; i++)
			{
				//Alpha-Beta cutoff
				if (alpha >= beta) break;

				//Simulate task and get new state
				Dictionary<PlayerTask, POGame.POGame> dict = state.Simulate(new List<PlayerTask>
					{state.CurrentPlayer.Options()[i]});

				children.Add(new GameNode(dict.Values.ToList()[0], dict.Keys.ToList()[0], this));

				if (myNode) //Maximizing Player - Me
				{
					value = Math.Max(value, children[i].alphabeta(alpha, beta, depth - 1));
					alpha = Math.Max(alpha, value);
				}
				else //Minimizing Player - Opponent
				{
					value = Math.Min(value, children[i].alphabeta(alpha, beta, depth - 1));
					beta = Math.Min(beta, value);
				}

				//Set state and task of child to null to save ram, tasknum will be used to reconstruct the task at the end
				//The state wont be needed after this
				children[i].tasknum = i;
				children[i].task = null;
				children[i].state = null;
			}

			return value;
		}

		int calcValue()
		{
			TestScore myScore = new TestScore();
			myScore.Controller = myNode ? state.CurrentPlayer : state.CurrentOpponent;
			myScore.EnemyController = myNode ? state.CurrentOpponent : state.CurrentPlayer;
			myScore.Turn = state.Turn;

			return myScore.Rate();
		}

		public Queue<PlayerTask> getTasks(POGame.POGame game)
		{
			var queue = new Queue<PlayerTask>();
			var childArray = children;
			var currentState = game;
			while (childArray.Count != 0)
			{
				var bestChild = childArray.OrderByDescending(p => p.value).First();

				if (bestChild.myNode)
				{
					Dictionary<PlayerTask, POGame.POGame> dict = currentState.Simulate(new List<PlayerTask>
						{currentState.CurrentPlayer.Options()[bestChild.tasknum]});
					currentState = dict.Values.ToList()[0];
					queue.Enqueue(dict.Keys.ToList()[0]);
					childArray = bestChild.children;
				}
				else
				{
					break;
				}
			}

			return queue;
		}
	}
}
