using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;

namespace SabberStoneCoreAi.MCTS
{
	class MonteCarloNode
	{

		private PlayerTask _action;

		private List<MonteCarloNode> _children;

		private POGame.POGame _gameState;

		private int _playerId;

		private double _boardValue;

		private MonteCarloNode _parent;

		private Score.Score _scoreEvaluator;

		private int _endTurn = 0;

		public int PlayerId
		{
			get { return _playerId; }
		}


		public bool IsRunning
		{
			get
			{
				return (_gameState.State == State.RUNNING);
			}
		}

		public double NumberOfVisits { get; set; }

		public double Reward { get; set; }

		public double BoardValue
		{
			get { return _boardValue; }
		}

		public bool IsLeaf
		{
			get { return (_children == null || (_children.Count < 1)); }
		}

		public bool IsEndTurn
		{
			get
			{
				return (_endTurn > 0 || (Action != null && Action.PlayerTaskType == PlayerTaskType.END_TURN));
			}
		}

		public MonteCarloNode Parent
		{
			get { return _parent; }
		}

		public List<MonteCarloNode> Children
		{
			get { return _children; }
			set { _children = value; }
		}

		public SabberStoneCore.Model.Entities.Controller PlayerController
		{
			get
			{
				if (_gameState != null)
				{
					return (_gameState.CurrentPlayer.Id == _playerId) ?
						_gameState.CurrentPlayer : _gameState.CurrentOpponent;
				}
				return null;
			}
		}

		public List<PlayerTask> AvailableActions
		{
			get
			{
				if (PlayerController != null)
				{
					return PlayerController.Options();
				}
				return new List<PlayerTask>();
			}
		}

		public PlayerTask Action
		{
			get
			{
				return _action;
			}
		}

		public POGame.POGame GameState => _gameState;

		public MonteCarloNode(int playerId, Score.Score scoreEvaluator, POGame.POGame gameState, PlayerTask action, MonteCarloNode parent)
		{
			_parent = parent;
			_scoreEvaluator = scoreEvaluator;
			_playerId = playerId;
			_gameState = gameState.getCopy();
			_action = action;

			NumberOfVisits = 1;

			if (_action != null)
			{
				Dictionary<PlayerTask, POGame.POGame> dir = _gameState.Simulate(new List<PlayerTask> { Action });
				POGame.POGame newGame = dir[Action];

				_gameState = newGame;
				if (_gameState == null)
				{
					_endTurn = 1;
				}
				else
				{
					_scoreEvaluator.Controller = PlayerController;
					_boardValue += _scoreEvaluator.Rate();
					Reward += _boardValue;
				}
			}
		}

		public MonteCarloNode(POGame.POGame game, PlayerTask task, MonteCarloNode parent)
			: this(parent.PlayerId, parent._scoreEvaluator, game, task, parent) { }

		public List<PlayerTask> GetSolution()
		{
			var solutions = new List<PlayerTask>();
			MonteCarloNode bestChild = this;
			while (!bestChild.IsEndTurn && !bestChild.IsLeaf)
			{
				solutions.Add(bestChild.Action);
				bestChild = bestChild.Children.OrderByDescending(c => c.Reward).First();
			}

			if (bestChild.IsEndTurn || bestChild.IsLeaf)
			{
				solutions.Add(bestChild.Action);
				return solutions;
			}
			return solutions;
		}
	}
}
