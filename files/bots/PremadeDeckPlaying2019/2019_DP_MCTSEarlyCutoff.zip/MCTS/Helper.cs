using System;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;

namespace SabberStoneCoreAi.MCTS
{
	class Helper
	{

		public static Score.Score getStrategy(CardClass hero)
		{
			switch (hero)
			{
				case CardClass.SHAMAN:
					return new MidRangeScore();
				case CardClass.MAGE:
					return new ControlScore();
				case CardClass.ROGUE:
					return new MidRangeScore();
				case CardClass.WARLOCK:
					return new MidRangeScore();
				case CardClass.WARRIOR:
					return new AggroScore();
				case CardClass.DRUID:
					return new AggroScore();
				case CardClass.PALADIN:
					return new ControlScore();
				case CardClass.PRIEST:
					return new ControlScore();
				case CardClass.HUNTER:
					return new MidRangeScore();
				default:
					return new MidRangeScore();
			}
		}
		public static double upperConfidenceBound(MonteCarloNode currentNode)
		{
			var result = Math.Sqrt(2 * (Math.Log(currentNode.Parent.NumberOfVisits) / currentNode.NumberOfVisits));
			return currentNode.Reward + Hyperparameters.UCT_CONSTANT * result;
		}


	}
}
