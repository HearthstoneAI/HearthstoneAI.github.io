using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace SabberStoneCoreAi.MCTS
{
	class MonteCarloTree
	{
		public Stopwatch Watch
		{
			private get; set;
		}

		private int _playerId;

		private double _timeLimit;

		private Score.Score _scoreEvaluator;



		public MonteCarloTree(int playerId, Score.Score scoreEvaluator)
		{
			_playerId = playerId;
			_scoreEvaluator = scoreEvaluator;

			_timeLimit = Hyperparameters.MAX_SIMULATION_TIME - Hyperparameters.SAFETY_MARGIN * 2;
		}

		public MonteCarloNode retrieveBestNode(POGame.POGame game)
		{
			POGame.POGame gameCopy = game.getCopy();

			// initials root node
			var initLeafs = new List<MonteCarloNode>();
			var root = new MonteCarloNode(_playerId, new Score.MyScore(), gameCopy, null, null);

			// simulate
			MonteCarloNode bestNode = buildTree(_timeLimit, root, ref initLeafs);

			return bestNode;
		}

		private MonteCarloNode buildTree(double simulationTime, MonteCarloNode root, ref List<MonteCarloNode> leafNodes)
		{
			while (Watch.Elapsed.TotalMilliseconds <= simulationTime)
			{
				MonteCarloNode selectedNode = select(root);

				MonteCarloNode leafNode = selectedNode;
				if (!leafNode.IsEndTurn)
				{
					expand(selectedNode);
					leafNode = greedySimulate( selectedNode);
				}

				backpropagate(leafNode, leafNode.BoardValue);

				if (selectedNode.IsEndTurn && !leafNodes.Contains(selectedNode))
				{
					leafNodes.Add(selectedNode);
				}
			}

			if (root.Children == null)
			{
				expand(root);
			}

			if (root.Children.Count < 1)
			{
				return root;
			}

			return root.Children
				.OrderByDescending(c => c.Reward)
				.First();
		}


		private MonteCarloNode select(MonteCarloNode root)
		{
			MonteCarloNode selectedNode = root;
			while (!selectedNode.IsLeaf)
			{
				selectedNode = selectedNode
					.Children.OrderByDescending(c => Helper.upperConfidenceBound(c)).First();

			}
			return selectedNode;
		}

		private void expand(MonteCarloNode selectedNode)
		{
			selectedNode.Children = selectedNode
				.AvailableActions.Select(t => new MonteCarloNode(selectedNode.GameState, t, selectedNode)).ToList();
		}

		private MonteCarloNode greedySimulate(MonteCarloNode expandedNode)
		{
			MonteCarloNode child;
			if (expandedNode.Children.Count < 1)
			{
				return expandedNode;
			}

			MonteCarloNode simulationChild = child = expandedNode
				.Children.OrderByDescending(c => c.BoardValue).First();

			int counter = 0;
			while (counter++ < Hyperparameters.SIMILATION_DEPTH
			       && (!simulationChild.IsEndTurn && simulationChild.IsRunning))
			{
				expand(simulationChild);
				simulationChild = simulationChild
					.Children.OrderByDescending(c => c.BoardValue).First();
			}

			if (child.Children?.Any() ?? false)
			{
				child.Children = null;
			}

			return simulationChild;
		}


		protected void backpropagate(MonteCarloNode leafNode, double score)
		{
			MonteCarloNode parent = leafNode;
			while (parent != null)
			{
				parent.NumberOfVisits++;
				if (parent.Reward < score)
				{
					parent.Reward = score;
				}
				parent = parent.Parent;
			}
		}

	}
}
