
namespace SabberStoneCoreAi.MCTS
{
	public struct Hyperparameters
	{
		public static int SIMILATION_DEPTH = 5;

		public static double MAX_SIMULATION_TIME = 15000;

		public static double SAFETY_MARGIN = 500;

		public static double UCT_CONSTANT = 10000;
	}
}
