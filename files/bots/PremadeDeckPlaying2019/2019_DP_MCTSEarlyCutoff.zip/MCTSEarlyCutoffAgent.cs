using System;
using System.Collections.Generic;
using System.Diagnostics;
using SabberStoneCore.Enums;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.MCTS;
using SabberStoneCoreAi.Score;

namespace SabberStoneCoreAi.Agent
{
	class MCTSEarlyCutoffAgent: AbstractAgent
	{
		private Queue<PlayerTask> _currentSolutions;

		private Stopwatch _watch;

		private Score.Score _scoreEvaluator;
		private Stopwatch Watch
		{
			get
			{
				if (_watch == null)
				{
					_watch = new Stopwatch();
				}
				return _watch;
			}
		}

		private MonteCarloTree _monteCarloTree;
		public override void InitializeAgent()
		{
		}

		private MonteCarloTree initTree(int playerID, Score.Score scoring)
		{
			return new MonteCarloTree(playerID, scoring)
			{
				Watch = Watch
			};
		}

		public MCTSEarlyCutoffAgent()
		{
			var scoring = new MyScore();
			this._scoreEvaluator = scoring;
		}

		private List<PlayerTask> getSolutions(POGame.POGame game, int playerID, Score.Score scoring)
		{
			if (_monteCarloTree == null)
			{
				_monteCarloTree = initTree(playerID, scoring);
			}

			if (Watch.Elapsed.TotalMilliseconds <= Hyperparameters.MAX_SIMULATION_TIME - Hyperparameters.SAFETY_MARGIN)
			{
				return _monteCarloTree.retrieveBestNode(game).GetSolution();
			}
			else
			{
				return new List<PlayerTask> { EndTurnTask.Any(game.CurrentPlayer) };
			}
		}

		public override void InitializeGame()
		{
			_currentSolutions = null;
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			if (!Watch.IsRunning)
			{
				Watch.Start();
			}

			_scoreEvaluator = Helper.getStrategy(poGame.CurrentPlayer.HeroClass);

			if (_currentSolutions == null)
			{
				_currentSolutions = new Queue<PlayerTask>();
			}

			Controller currentPlayer = poGame.CurrentPlayer;
			if (_currentSolutions != null && _currentSolutions.Count < 1)
			{
				List<PlayerTask> solutions = getSolutions(poGame, currentPlayer.Id, _scoreEvaluator);
				foreach (PlayerTask solution in solutions)
				{
					_currentSolutions.Enqueue(solution);
				}
			}
			PlayerTask result = _currentSolutions.Dequeue();

			if (result.PlayerTaskType == PlayerTaskType.CHOOSE
			    && poGame.CurrentPlayer.Choice == null)
			{
				result = EndTurnTask.Any(currentPlayer);
			}

			if (poGame.Simulate(new List<PlayerTask>() {result})[result] == null)
			{
				result = EndTurnTask.Any(currentPlayer);
			}

			if (result.PlayerTaskType == PlayerTaskType.END_TURN
			    || poGame.State == State.COMPLETE
			    || poGame.State == State.INVALID)
			{
				Watch.Reset();
			}
			return result;
		}

		public override void FinalizeAgent() { }
		public override void FinalizeGame() { }
	}
}
