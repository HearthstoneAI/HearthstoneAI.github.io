﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class ScoreWatson : Score
	{
		public int Rate(int turnCount)
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			int result = 0;

			// calcluate value for player
			double playerVal = 0.0;

			playerVal += 2 * Math.Sqrt(HeroHp);

			if (HandCnt <= 3)
				playerVal += HandCnt * 3;
			else
				playerVal += 9 + (HandCnt - 3) * 2;

			playerVal += DeckCnt > 0 ? Math.Sqrt(DeckCnt) : -3;

			foreach (Minion minion in BoardZone)
			{
				playerVal += (minion.Health + minion.AttackDamage);
				if (minion.HasBattleCry || minion.HasDeathrattle || minion.HasDivineShield || minion.HasInspire || minion.HasStealth)
					playerVal += 3;
				if (minion.HasTaunt)
					playerVal += 3 * minion.Health;
				if (minion.HasCharge || minion.HasLifeSteal || minion.HasWindfury)
					playerVal += 3 * minion.AttackDamage;
			}

			if (OpBoardZone.Count == 0)
				playerVal += 2 + Math.Min(10, turnCount);



			// calcluate value for bot

			double botVal = 0.0;

			botVal += 2 * Math.Sqrt(OpHeroHp);

			if (OpHandCnt <= 3)
				botVal += OpHandCnt * 3;
			else
				botVal += 9 + (OpHandCnt - 3) * 2;

			botVal += OpDeckCnt > 0 ? Math.Sqrt(OpDeckCnt) : -3;

			foreach (Minion minion in OpBoardZone)
			{
				botVal += (minion.Health + minion.AttackDamage);
				if (minion.HasBattleCry || minion.HasDeathrattle || minion.HasDivineShield || minion.HasInspire || minion.HasStealth)
					botVal += 3;
				if (minion.HasTaunt)
					botVal += 3 * minion.Health;
				if (minion.HasCharge || minion.HasLifeSteal || minion.HasWindfury)
					botVal += 3 * minion.AttackDamage;
			}

			if (BoardZone.Count == 0)
				botVal += 2 + Math.Min(10, turnCount);


			// score value is the difference between player value and bot value calculated above
			result = (int)(playerVal - botVal);

			return result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
