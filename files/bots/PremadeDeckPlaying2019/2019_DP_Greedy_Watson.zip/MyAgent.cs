﻿using System;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using System.Collections.Generic;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.Agent;


namespace SabberStoneCoreAi.Competition.Agents
{
	class BotWatson: AbstractAgent
	{
		private Random Rnd = new Random();

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			Controller player = poGame.CurrentPlayer;

			// Get all simulation results for simulations that didn't fail
			IEnumerable<KeyValuePair<PlayerTask, POGame.POGame>> validOpts = poGame.Simulate(player.Options()).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}

		private int Score(POGame.POGame state, int playerId)
		{
			Controller p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			return new ScoreWatson { Controller = p }.Rate(state.Turn);
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}
	}
}
