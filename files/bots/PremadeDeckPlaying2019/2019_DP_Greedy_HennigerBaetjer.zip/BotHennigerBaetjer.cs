﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;

//Autor: Hans Ulrich Bätjer, André Henniger

namespace SabberStoneCoreAi.Competition.Agents
{
	class BotHennigerBaetjer : AbstractAgent
	{
		public override void InitializeAgent() { }
		public override void InitializeGame() { }
		public override void FinalizeGame() { }
		public override void FinalizeAgent() { }

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			var player = poGame.CurrentPlayer;

			// Get all simulation results for simulations that didn't fail
			var validOpts = MySimulate(player.Options(),poGame).Where(x => x.Value != null);

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return validOpts.Any() ?
				validOpts.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key :
				player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);

			return poGame.CurrentPlayer.Options()[0];
		}
		// Calculate different scores based on our hero's class
		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new MyAggroScore { Controller = p }.Rate();
				case CardClass.MAGE: return new MyScore { Controller = p }.Rate();
				case CardClass.SHAMAN: return new MyMidrangeScore { Controller = p }.Rate();
				default: return new MyScore { Controller = p }.Rate();
			}
		}
		public Dictionary<PlayerTask, POGame.POGame> MySimulate(List<PlayerTask> tasksToSimulate, POGame.POGame Game)
		{
			Dictionary<PlayerTask, POGame.POGame> simulated = new Dictionary<PlayerTask, POGame.POGame>();
			foreach (PlayerTask task in tasksToSimulate)
			{
				var copy = Game.getCopy();
				while (true)
				{
					try
					{
						copy = Game.getCopy();
						break;
					}
					catch (Exception)
					{
					}
				}
				try
				{

					copy.Process(task);
					simulated.Add(task, copy);
				}
				catch (Exception)
				{
					simulated.Add(task, null);
				}
			}
			return simulated;

		}


	}

}
