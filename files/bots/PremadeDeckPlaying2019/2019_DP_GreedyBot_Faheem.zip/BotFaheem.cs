﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using System.Diagnostics;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Model;


namespace SabberStoneCoreAi.Competition.Agents
{
	class BotFaheem : AbstractAgent
	{
		List<PlayHistoryEntry> opponentHistory = new List<PlayHistoryEntry>();
		bool playedFlameStrike, playedBlizzard, isPlayer1, playedLightningStorm, playedMindControl;
		int currentMana, currentHp, currentOpHp;
		int boardZoneCount, oPboardZoneCount;
		MageScore ms = null;
		ShamanScore ss = null;
		private CardClass cardClass;

		public Score.Score Control { get; private set; }

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			//variables
			cardClass = poGame.CurrentPlayer.HeroClass;
			isPlayer1 = poGame.CurrentPlayer.PlayerId == 1 ? true : false;  //are we player 1 ?
			boardZoneCount = poGame.CurrentPlayer.BoardZone.Count;
			oPboardZoneCount = poGame.CurrentOpponent.BoardZone.Count;
			currentHp = poGame.CurrentPlayer.Hero.Health;
			currentOpHp = poGame.CurrentOpponent.Hero.Health;
			currentMana = poGame.CurrentPlayer.PlayerId == 1 ? poGame.CurrentPlayer.BaseMana : poGame.CurrentPlayer.BaseMana+1;


			//check for opponent played flamestrike and blizzard as they do AOE damage. be careful on board until opponent uses them
			opponentHistory = poGame.CurrentOpponent.PlayHistory;
			foreach (PlayHistoryEntry hist in opponentHistory)
			{
				if (hist.SourceCard.Name == "Flamestrike")
					playedFlameStrike = true;
				if (hist.SourceCard.Name == "Blizzard")
					playedBlizzard = true;
				if (hist.SourceCard.Name == "Lightning Storm")
				{
					playedLightningStorm = true;
				}
				if (hist.SourceCard.Name == "Mind Control Tech")
				{
					playedMindControl = true;
				}
			}
		

		
			//if (poGame.CurrentPlayer.CardsPlayedThisTurn.Count > 0)
			//Console.WriteLine(poGame.CurrentPlayer.CardsPlayedThisTurn[poGame.CurrentPlayer.CardsPlayedThisTurn.Count-1]);
			//Console.WriteLine(boardZoneCount+ " " + currentHp + " " + currentOpHp + " " + oPboardZoneCount + " "+ currentMana);

			//Console.WriteLine(poGame.CurrentPlayer.Hero.Health);


			
			return GreedyBestOption(cardClass,poGame);
		}

		private PlayerTask GreedyBestOption(CardClass cs, POGame.POGame poGame)
		{
			float bestScore = Single.MinValue;
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			PlayerTask option = options[0];
			foreach (PlayerTask opt in options)
			{
				if (opt.PlayerTaskType != PlayerTaskType.CONCEDE && opt.PlayerTaskType != PlayerTaskType.END_TURN)
				{
					try
					{
						Dictionary<PlayerTask, POGame.POGame> dict = poGame.Simulate(new List<PlayerTask> { opt });
						if (cardClass == CardClass.SHAMAN)
							ss.Controller = dict[opt].CurrentPlayer;
						else
							ms.Controller = dict[opt].CurrentPlayer;

						
						if (cardClass == CardClass.SHAMAN)
						{
							if (playedLightningStorm == false && opt.Source.Card.Health <= 3 && boardZoneCount >= 2 && opt.PlayerTaskType == PlayerTaskType.PLAY_CARD && opt.Source.Card.Type == CardType.MINION)
								continue;
							if (ss.SetManaAndGetRate(currentMana,  currentHp, isPlayer1) > bestScore)
							{
								//Console.WriteLine("shaman, best opt");
								option = opt;
								bestScore = ss.SetManaAndGetRate(currentMana,  currentHp, isPlayer1);
							}
						}
						else
						{
							if (poGame.CurrentPlayer.HeroClass.Equals(CardClass.MAGE))
							{

								//play safe and try not lose many cards from flamestrike and blizzard
								if (playedFlameStrike == false && opt.Source.Card.Health <= 4 && boardZoneCount >= 3 && currentMana >= 7 && opt.PlayerTaskType == PlayerTaskType.PLAY_CARD && opt.Source.Card.Type == CardType.MINION)
									continue;
								if (playedMindControl == false  && boardZoneCount >= 3 && currentMana >= 3 && opt.PlayerTaskType == PlayerTaskType.PLAY_CARD && opt.Source.Card.Type == CardType.MINION)
									continue;
								if (currentMana >= 6 && boardZoneCount >= 2 && opt.PlayerTaskType == PlayerTaskType.PLAY_CARD && opt.Source.Card.Type == CardType.MINION && playedBlizzard == false && opt.Source.Card.Health <= 2)
									continue;
							}
							
							if (ms.SetManaAndGetRate(currentMana,  currentHp, isPlayer1) > bestScore)
							{
								//Console.WriteLine("mage, best opt");
								option = opt;
								bestScore = ms.SetManaAndGetRate(currentMana,  currentHp, isPlayer1);
							}
						}
					}
					catch (Exception e)
					{
						continue;
					}
				}
			}
			return option ?? options[0];
		}

		public override void InitializeAgent()
		{
			ms = new MageScore();
			ss = new ShamanScore();
			playedFlameStrike = false;
			playedBlizzard = false;
			playedLightningStorm = false;
			playedMindControl = false;
		}

		public override void InitializeGame()
		{
		}
	}
}
