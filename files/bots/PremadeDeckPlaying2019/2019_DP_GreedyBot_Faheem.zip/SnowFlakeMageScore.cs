﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class MageScore : Score
	{
		private int mana, currentHp;

	
		public int SetManaAndGetRate(int mana,  int hp, bool Player1)
		{
			this.currentHp = hp;		
			this.mana = mana;

			return Rate();
		}
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			int result = 0;


			if (mana <= 6)	//if we are player1 or (mana is less than 6) or (reno jackson is not in deck) then play defensive
			{
				result += (HeroHp - OpHeroHp);
			}
			else
			{		//Player 2 with reno card present must play a little offensive to gain lead
				result -= (OpHeroHp) * 20;
			}
			if (currentHp <= 10 )
				result += HeroHp * 1000;

			//keep control of board, the rest is being controlled by agent itself
			result += (BoardZone.Count - OpBoardZone.Count) * 2000;
			result += (MinionTotAtk - OpMinionTotAtk);
			result += MinionTotHealthTaunt - OpMinionTotHealthTaunt;
			result += (MinionTotHealth - OpMinionTotHealth);
			return result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
