﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Model.Entities;

namespace SabberStoneCoreAi.Score
{
	public class ShamanScore : Score
	{
		private int currentHp;
		private bool  player1;


		public int SetManaAndGetRate(int mana,  int hp, bool Player1)
		{
			this.player1 = Player1; //will tell if we are player1 or player2
			this.currentHp = hp;

			return Rate();
		}
		public override int Rate()
		{
			if (OpHeroHp < 1)
				return Int32.MaxValue;

			if (HeroHp < 1)
				return Int32.MinValue;

			int result = 0;

			result += (HeroHp - OpHeroHp);
			if (currentHp <= 10 && !player1)
				result += HeroHp * 1000;
			result -= OpBoardZone.Count * 200;
			result += (MinionTotAtk - OpMinionTotAtk) * 100;
			result += MinionTotHealthTaunt - OpMinionTotHealthTaunt;
			result += (MinionTotHealth - OpMinionTotHealth);
			return result;
		}

		public override Func<List<IPlayable>, List<int>> MulliganRule()
		{
			return p => p.Where(t => t.Cost > 3).Select(t => t.Id).ToList();
		}
	}
}
