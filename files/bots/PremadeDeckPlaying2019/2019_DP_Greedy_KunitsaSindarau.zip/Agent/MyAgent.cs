﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCore.Model;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Model.Entities;
using SabberStoneCoreAi.Agent;


namespace SabberStoneCoreAi.Competition.Agents
{
	class BotKunitsaSindarau : AbstractAgent
	{

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> simulatedActions = new List<PlayerTask>();
			simulatedActions.AddRange(poGame.CurrentPlayer.Options());
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> sim = poGame.Simulate(simulatedActions);

			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame>.KeyCollection keyColl = sim.Keys;

			PlayerTask selectedMove = simulatedActions.Find(
				x => x.PlayerTaskType == PlayerTaskType.END_TURN);
			int selectedRate = int.MinValue;

			foreach (PlayerTask key in keyColl)
			{
				if (key.PlayerTaskType == PlayerTaskType.END_TURN)
					continue;

				Controller controller = sim.First(x => x.Key == key).Value?.CurrentPlayer;

				if(controller != null)
				{
					var scoreType = Score(poGame, controller).GetType().Name;

					if((scoreType == "ControlScore" || scoreType == "RampScore") &&  
							isTaskSkipped(key, poGame))
						continue;

					var currentRate = Score(poGame, controller).Rate();

					if (selectedRate < currentRate)
					{
						selectedRate = currentRate;
						selectedMove = key;
					}
				}
			}

			return selectedMove;
		}

		private bool isTaskSkipped(PlayerTask key, SabberStoneCoreAi.POGame.POGame poGame)
		{
			bool skipTask = false;

			if (poGame.CurrentPlayer.HandZone.Count <= 2 &&
					poGame.CurrentPlayer.BoardZone.Count >= 3 && 
					key.PlayerTaskType == PlayerTaskType.PLAY_CARD && 
					key.Source.Card.Type == CardType.MINION)
				skipTask = true;

			return skipTask;
		}

		private static IScore Score( POGame.POGame poGame, Controller controller )
		{
			switch ( poGame.CurrentPlayer.HeroClass )
			{
				case CardClass.WARRIOR: return new ControlScore { Controller = controller };
				case CardClass.MAGE: 	return new RampScore { Controller = controller };
				default: 				return new MidRangeScore { Controller = controller };
			}
		}


		public override void InitializeAgent()
		{
		}

		public override void InitializeGame()
		{
		}

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}
	}
}
