using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Config;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent.ExampleAgents;
using SabberStoneCoreAi.Agent;
using SabberStoneCore.Model;

namespace SabberStoneCoreAi.Challenge.Control
{
	class ChlgGameConfig
	{

            public static GameConfig Mirror_RenoKazakusMage => new GameConfig()
		{
                  Player1HeroClass = CardClass.MAGE,
                  Player2HeroClass = CardClass.MAGE,
                  FillDecks = false,
                  Player1Deck = Meta.Decks.RenoKazakusMage,
                  Player2Deck = Meta.Decks.RenoKazakusMage,
                  Shuffle = true,
                  Logging = false
		};

            public static GameConfig Mirror_MidrangeJadeShaman => new GameConfig()
		{
                  Player1HeroClass = CardClass.SHAMAN,
                  Player2HeroClass = CardClass.SHAMAN,
                  FillDecks = false,
                  Player1Deck = Meta.Decks.MidrangeJadeShaman,
                  Player2Deck = Meta.Decks.MidrangeJadeShaman,
                  Shuffle = true,
                  Logging = false
		};

            public static GameConfig Mirror_AggroPirateWarrior => new GameConfig()
	      {
                  Player1HeroClass = CardClass.WARRIOR,
                  Player2HeroClass = CardClass.WARRIOR,
                  FillDecks = false,
                  Player1Deck = Meta.Decks.AggroPirateWarrior,
                  Player2Deck = Meta.Decks.AggroPirateWarrior,
                  Shuffle = true,
                  Logging = false
		};

            public static GameConfig GeneratedDecks => new GameConfig()
	      {
                  Player1HeroClass = CardClass.SHAMAN,
                  Player2HeroClass = CardClass.SHAMAN,
                  FillDecks = true,
                  Shuffle = true,
                  Logging = false
		};
	}
}
