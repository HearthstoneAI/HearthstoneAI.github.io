using System;
using System.Collections.Generic;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.Agent.ExampleAgents;
using SabberStoneCore.Config;
using SabberStoneCoreAi.POGame;


namespace SabberStoneCoreAi.Challenge.Control
{
    class ChlgMatchupsController
    {
        private static AbstractAgent opponent = new GreedyAgent();
		private static AbstractAgent agent = new LarsBot();
        private static int STATIC_ID = 0;
        private Dictionary<int, POGameHandler> handlerDict = new Dictionary<int, POGameHandler>();


        public ChlgMatchupsController()
        {
        }

        private List<int> CreateNewGameHandler(GameConfig gameConfig, List<int> handlersId, int startPlayer) 
        {
            gameConfig.StartPlayer = startPlayer;
            handlerDict.Add(STATIC_ID, new POGameHandler(gameConfig, opponent, agent, repeatDraws:false));
            handlersId.Add(STATIC_ID);
            STATIC_ID++;
            return handlersId;
        }

        private List<int> CreateAlternatelyHandlers(GameConfig gameConfig)
        {
            List<int> handlersId = new List<int>();
            handlersId = CreateNewGameHandler(gameConfig, handlersId, 1);
            handlersId = CreateNewGameHandler(gameConfig, handlersId, 2);

            return handlersId;
        }

        public List<int> PlayGames(GameConfig gameConfig, int nr_of_games, 
                bool addResultToGameStats=true, bool splitGamesByStartPlayer=true, bool debug=false) {
            List<int> handlersId = new List<int>();
            if (splitGamesByStartPlayer)
            {
                handlersId = CreateAlternatelyHandlers(gameConfig);
                int hlf_nr_of_games = nr_of_games / 2 + nr_of_games % 2;
                int rev_nr_of_games = nr_of_games - hlf_nr_of_games;
                
                handlerDict[handlersId[0]].PlayGames(hlf_nr_of_games, addResultToGameStats, debug);
                handlerDict[handlersId[1]].PlayGames(rev_nr_of_games, addResultToGameStats, debug);
            }
            else
            {
                handlersId = CreateNewGameHandler(gameConfig, handlersId, 1);
                handlerDict[handlersId[0]].PlayGames(nr_of_games, addResultToGameStats, debug);
            }
            return handlersId;
        }

        public GameStats GameStats(int gameHandlerID)
		{
			return handlerDict[gameHandlerID].getGameStats();
		}
    }
}
