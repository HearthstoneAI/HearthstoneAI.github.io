﻿using System;
using System.Collections.Generic;
using SabberStoneCore.Enums;
using SabberStoneCoreAi.Score;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Linq;
using System.Collections;

namespace SabberStoneCoreAi.Competition.Agents
{
	class BotMohammed : AbstractAgent
	{


		private Random Rnd = new Random();

		public override void InitializeAgent()
		{
		}

		public override void FinalizeAgent()
		{
			//Nothing to do here
		}

		public override void FinalizeGame()
		{
			//Nothing to do here
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			return getBestMove(poGame, options);
		}



		public override void InitializeGame()
		{
			//Nothing to do here
		}

		public PlayerTask getBestMove(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> options)
		{
			#region Declarations
			bool summonMinionThisTurn = false;
			SabberStoneCore.Model.Zones.BoardZone oppoMinions = poGame.CurrentOpponent.BoardZone;
			SabberStoneCore.Model.Zones.BoardZone myMinions = poGame.CurrentPlayer.BoardZone;
			PlayerTask goodSummonMinion = null;

			List<PlayerTask> minionAttacks = new List<PlayerTask>();
			List<PlayerTask> heroAttacks = new List<PlayerTask>();
			List<PlayerTask> summonMinions = new List<PlayerTask>();
			List<PlayerTask> heroPower = new List<PlayerTask>();

			Dictionary<PlayerTask, POGame.POGame> minAttacksSims = null;
			Dictionary<PlayerTask, POGame.POGame> heroAttacksSims = null;
			Dictionary<PlayerTask, POGame.POGame> sumMinSimulations = null;
			Dictionary<PlayerTask, POGame.POGame> heroPowerSimulations = null;

			KeyValuePair<PlayerTask, POGame.POGame> goodMinionSimulations;
			KeyValuePair<PlayerTask, POGame.POGame> goodHeroSimulations;
			KeyValuePair<PlayerTask, POGame.POGame> goodheroPowerSimulations;
			#endregion
			if (options.Count == 1)
				return options[0];

			#region Classify Tasks
			foreach (PlayerTask task in options)
			{
				if (task.PlayerTaskType == PlayerTaskType.MINION_ATTACK)
				{
					minionAttacks.Add(task);
				}
				else if (task.PlayerTaskType == PlayerTaskType.HERO_ATTACK)
				{
					heroAttacks.Add(task);
				}
				else if (task.PlayerTaskType == PlayerTaskType.HERO_POWER)
					heroPower.Add(task);
				else if (task.PlayerTaskType == PlayerTaskType.PLAY_CARD)
					summonMinions.Add(task);
			}
			#endregion

			#region Simulate Tasks
			if (minionAttacks.Count > 0)
				minAttacksSims = poGame.Simulate(minionAttacks);
			if (heroAttacks.Count > 0)
				heroAttacksSims = poGame.Simulate(heroAttacks);
			if (summonMinions.Count > 0)
				sumMinSimulations = poGame.Simulate(summonMinions);
			if (heroPower.Count > 0)
				heroPowerSimulations = poGame.Simulate(heroPower);
			#endregion


			try
			{
				#region Evaluate Summon Minions
				if (summonMinions != null)
				{
					if (summonMinions.Count > 0)
					{

						if (summonMinions.Count == (options.Count - 1))
						{
						//summonMinions and End_Turn is the only  option left
						summonMinionThisTurn = true;
						}
						
					}

				}
				if (summonMinionThisTurn)
				{
					goodSummonMinion = evaluateSummonMinions(poGame, summonMinions, sumMinSimulations, options);
					return goodSummonMinion;
				}
				#endregion
				#region Evaluate MinionAttacks
				if (minionAttacks.Count > 0)
				{
					if (minAttacksSims.Count != 0)
					{
						goodMinionSimulations = evaluateSimulations(poGame, minionAttacks, minAttacksSims, options);
					}
				}
				#endregion
				#region Evaluate HeroAttacks
				if (heroAttacks.Count > 0)
				{
					if (heroAttacksSims.Count != 0)
					{
						goodHeroSimulations = evaluateSimulations(poGame, heroAttacks, heroAttacksSims, options);
					}
				}
				#endregion
				#region Evaluate HeroPower
				if (heroPower.Count > 0)
				{
					if (heroPowerSimulations.Count != 0)
					{
						goodheroPowerSimulations = evaluateSimulations(poGame, heroPower, heroPowerSimulations, options);
					}
				}
				#endregion

				if(minionAttacks.Count >0)
				{
					if (goodMinionSimulations.Key.Target == poGame.CurrentOpponent.Hero)
						return goodMinionSimulations.Key;
				}
				if (heroAttacks.Count > 0)
				{
					if (goodHeroSimulations.Key.Target == poGame.CurrentOpponent.Hero)
					{
						if (goodHeroSimulations.Key.Target.Damage > poGame.CurrentOpponent.Hero.Health)
							return goodHeroSimulations.Key;
					}
				}
				if (heroPower.Count > 0)
				{
					if (goodheroPowerSimulations.Key.Target == poGame.CurrentOpponent.Hero)
					{
						if (goodheroPowerSimulations.Key.Target.Damage > poGame.CurrentOpponent.Hero.Health)
							return goodheroPowerSimulations.Key;
					}
				}
				if (summonMinionThisTurn)
				{
					return goodSummonMinion;
				}
				if (minionAttacks.Count > 0)
				{
					return goodMinionSimulations.Key;
				}
				if (heroPower.Count > 0) return goodheroPowerSimulations.Key;
				if (heroAttacks.Count > 0) return goodHeroSimulations.Key;

			}
			catch (Exception e)
			{
				#region GreedyAgent
				var player = poGame.CurrentPlayer;
				//return options.Any() ? options.OrderBy(x => Score(x.Value, player.PlayerId)).Last().Key : player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
			}
			#endregion

			Random rnd = new Random();
			int r = rnd.Next(options.Count);
			return options[r];

		}
		public KeyValuePair<PlayerTask, POGame.POGame> evaluateSimulations(SabberStoneCoreAi.POGame.POGame poGame, List<PlayerTask> validTasks, Dictionary<PlayerTask, POGame.POGame> validTaskSims, List<PlayerTask> options)
		{
			int totalHealth, maxDamage=-1, damage;
			KeyValuePair<PlayerTask, POGame.POGame> goodTask;
			KeyValuePair<PlayerTask, POGame.POGame> DestroyOppoTask;


			//var oppoMinionWithTaunt = (SabberStoneCore.Model.Zones.BoardZone) oppoMinions.Where(x => x.HasTaunt == true);
			//var minionToAttackOppoTaunt = (SabberStoneCore.Model.Zones.BoardZone) options.Where(x => x.Target == oppoMinionWithTaunt);

			foreach (KeyValuePair<PlayerTask, POGame.POGame> simulation in validTaskSims)
			{
				totalHealth = -1;


				if (simulation.Key.HasTarget)
				{
					damage = simulation.Key.Target.Damage;
					totalHealth += simulation.Key.Target.BaseHealth;
					totalHealth += simulation.Key.Target.Health;
					if (damage > maxDamage)
					{
						maxDamage = damage;
						goodTask = simulation;
					}

					if (simulation.Key.Target == poGame.CurrentOpponent.Hero)
					{
						return simulation;
					}

					if (totalHealth - damage <= 0)
					{
						DestroyOppoTask = simulation;
						return DestroyOppoTask;
					}

				}
			}
			return goodTask;
		}

		public PlayerTask evaluateSummonMinions(POGame.POGame poGame, List<PlayerTask> summonMinions, Dictionary<PlayerTask, POGame.POGame> sumMinSimulations, List<PlayerTask> options)
		{
			Random rnd = new Random();
			PlayerTask goodMinion = null;
			int score, maxScore = -1, r = 0;
			try
			{
				if (summonMinions.Count == 1)
					return summonMinions[0];
				else
				{
					foreach (PlayerTask sumMin in summonMinions)
					{
						score = -1;
						try
						{
							score += sumMin.Source.Card.Health;

							if (score > maxScore)
							{
								maxScore = score;
								goodMinion = sumMin;
							}
						}
						catch (Exception e)
						{
							Console.WriteLine(e.Message);
						}
					}
				}
				if (goodMinion != null)
					return goodMinion;
				else
				{
					r = rnd.Next(summonMinions.Count);
					return summonMinions[r];
				}
			}
			catch (Exception e)
			{
				Console.WriteLine(e.Message);
				return summonMinions[0];
			}
		}

		// Calculate different scores based on our hero's class
		private static int Score(POGame.POGame state, int playerId)
		{
			var p = state.CurrentPlayer.PlayerId == playerId ? state.CurrentPlayer : state.CurrentOpponent;
			switch (state.CurrentPlayer.HeroClass)
			{
				case CardClass.WARRIOR: return new AggroScore { Controller = p }.Rate();
				case CardClass.MAGE: return new ControlScore { Controller = p }.Rate();
				default: return new MidRangeScore { Controller = p }.Rate();
			}
		}
	}

}
