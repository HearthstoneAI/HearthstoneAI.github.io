﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Enums;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Score;
using SabberStoneCore.Tasks.PlayerTasks;


namespace SabberStoneCoreAi.Competition.Agents
{
	class MyScore : Score.Score
	{
		int HeroArmor => Controller.Hero.Armor;
		int OpHeroArmor => Controller.Hero.Armor;
		int Possible_Mana_Consum => HandTotCost + (Controller.HeroPowerActivationsThisTurn > 0 ? 0 : Controller.Hero.HeroPower.Cost);
		int SectretCount => Controller.SecretZone.Count;
		int OpSectretCount => Controller.Opponent.SecretZone.Count;
		int SpellPower => Controller.CurrentSpellPower;
		int OpSpellPower => Controller.Opponent.CurrentSpellPower;
		int OverLoad => Controller.OverloadOwed;
		int OpOverLoad => Controller.Opponent.OverloadOwed;


		public override int Rate()
		{
			// If we win it is the best possible value but not Int32.MaxValue to avoid overflow of averaging
			if (OpHeroHp < 1)
				return 10000000;
			// If we lost it is very bad but not Int32.MinValue to avoid underflow of averaging
			if (HeroHp < 1)
				return -10000000;

			int res = 0;

			//If we have minions but the enemy has not it is good
			if (OpBoardZone.Count == 0 && BoardZone.Count > 0)
			{
				res += BoardDominance();
			}
			//Mid Range
			res += (BoardZone.Count - OpBoardZone.Count) * WeightBoardZoneDiff();
			res += OpMinionTotHealthTaunt * WeightOpTaunt();
			res += MinionTotAtk * WeightMinionTotAtt();
			res += (MinionTotHealth - OpMinionTotHealth) * WeightMinionHealthDiff();
			res += (MinionTotAtk - OpMinionTotAtk) * WeightMinionAttackDiff();
			//Continue own implementation

			//Weigh the possible damage against the taunt health from the enemy
			res += (MinionTotAtk - OpMinionTotHealthTaunt) * WeightMinionAttack();
			//Weigh the damage we could resieve from enemey minions (play safe -> more important than the damage output)
			res += (MinionTotHealthTaunt - OpMinionTotAtk) * WeightMinionDefense();
			//More Hand Cards -> you are better off than the enemy
			res += (HandCnt - OpHandCnt) * WeightHandCard();
			//If you have more Health + Armor than the enemy it is a good sign
			res += (HeroHp + HeroArmor - OpHeroArmor - OpHeroHp) * WeightHealthynesse();
			//Make it hard to clear your board
			res += (MinionTotHealth) * WeightMinionHealth() + MinionTotHealthTaunt*WeightTauntHealth();
			//If Hero has AttackDamage that is a good thing^^
			res += HeroAtk * WeightHeroAttack();
			//If you have Secrets it is probably a good thing
			res += SectretCount * WeightSecrets();
			//If you have more Spell-Damage than the enemy it is a good thing
			res += (SpellPower - OpSpellPower) * WeightSpellDamage();

			res += Math.Max(0, OverLoad - Controller.BaseMana - 1) * WeightOverLoad();

			return res;
		}

		private int WeightOverLoad()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return -6;
				default:
					return 0;
			}
		}

		private int WeightMinionAttackDiff()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 10;
				default:
					return 0;
			}
		}

		private int WeightMinionHealthDiff()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 10;
				default:
					return 0;
			}
		}

		private int WeightMinionTotAtt()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 2;
				default:
					return 0;
			}
		}

		private int WeightOpTaunt()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return -1000;
				default:
					return 0;
			}
		}

		private int WeightBoardZoneDiff()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 7;
				default:
					return 0;
			}
		}

		private int BoardDominance()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 7000;
				default:
					return 1000;
			}
		}

		private int WeightMinionAttack()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 2;
				default:
					return 200;
			}
		}

		private int WeightMinionDefense()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 250;
			}
		}

		private int WeightHandCard()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				case CardClass.MAGE:
					return 200;
				default:
					return 150;
			}
		}

		private int WeightHealthynesse()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 10;
				default:
					return 200;
			}
		}

		private int WeightMinionHealth()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 100;
			}
		}

		private int WeightTauntHealth()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 50;
			}
		}

		private int WeightHeroAttack()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 100;
			}
		}

		private int WeightSecrets()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 0;
			}
		}

		private int WeightSpellDamage()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 0;
			}
		}

		private int WeightManaGain()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 5;
				default:
					return 2000;
			}
		}

		private int WeightManaOverConsume()
		{
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					return 0;
				default:
					return 1000;
			}
		}

		public int Rate(in SabberStoneCore.Model.Entities.Controller player_last_time)
		{
			int res = Rate();
			if (res == Int32.MaxValue || res == Int32.MinValue)
			{
				return res;
			}

			if(Controller.RemainingMana > player_last_time.RemainingMana)
			{
				if(Possible_Mana_Consum >= Controller.RemainingMana)
				{
					res += WeightManaGain() * (Controller.RemainingMana - player_last_time.RemainingMana);
				}
				else
				{
					//Having to much Mana is probably a waist of gaining it
					res += WeightManaOverConsume() * (Possible_Mana_Consum - Controller.RemainingMana);
				}
			}
			/*
			switch (Controller.HeroClass)
			{
				case CardClass.SHAMAN:
					res += (Controller.NumTotemSummonedThisGame - player_last_time.NumTotemSummonedThisGame) * 200;
					break;
				default:
					break;
			}
			*/
			return res;
		}

	}

	class BotEbertHeck: AbstractAgent
	{
		private Random rnd;
		private MyScore scorer;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override void InitializeAgent()
		{
			rnd = new Random();
			scorer = new MyScore();
		}

		public override void InitializeGame()
		{
		}

		private int Score(POGame.POGame before, POGame.POGame simulated, int playerID, int depth = 0, int maxDepth = 1)
		{
			var player = before.CurrentPlayer.PlayerId == playerID ? before.CurrentPlayer : before.CurrentOpponent;
			var p = simulated.CurrentPlayer.PlayerId == player.PlayerId ? simulated.CurrentPlayer : simulated.CurrentOpponent;
			scorer.Controller = p;

			if (depth == maxDepth || p.PlayerId == simulated.CurrentOpponent.PlayerId)
				return scorer.Rate(player);

			scorer.Controller = p;
			var validOpts = simulated.Simulate(p.Options()).Where(x => x.Value != null);
			var scores = validOpts.Select(x => Score(simulated, x.Value, playerID, depth + 1));
			return scores.Any() ? scores.OrderBy(x => x).Last() : scorer.Rate(player);
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			var player = poGame.CurrentPlayer;
			int k = 10;
			var average_score = new Dictionary<PlayerTask, int>();

			for(int i = 0; i < k; ++i)
			{
				var validOpts = poGame.Simulate(player.Options()).Where(x => x.Value != null).ToList();
				for(int j = 0; j < validOpts.Count; ++j)
				{
					if (average_score.ContainsKey(validOpts[j].Key))
					{
						average_score[validOpts[j].Key] += Score(poGame, validOpts[j].Value, player.PlayerId);
					}
					else
					{
						average_score.Add(validOpts[j].Key, Score(poGame, validOpts[j].Value, player.PlayerId));
					}
				}
			}

			// If all simulations failed, play end turn option (always exists), else best according to score function
			return average_score.Any() ? average_score.OrderBy(x => (float)x.Value/(float)k).Last().Key : player.Options().First(x => x.PlayerTaskType == PlayerTaskType.END_TURN);
		}
	}
}
