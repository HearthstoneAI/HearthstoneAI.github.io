﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using System.Linq;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Enums;


// Developed by Philipp Holz
namespace SabberStoneCoreAi.Agent
{
	class BotPhilippHolz : AbstractAgent
	{
		public BotPhilippHolz(){
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}

		private static List<PlayerTask> bestAction;
		private const int populationSize = 30;
		private const int matingPoolSize = 15;
		private const int tournamentSize = 5;
		private const int Iterations = 100;
		private static int action = 0;
		private static int turn = 0;
		private static Random Rnd = new Random();

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> PlayerOptions = poGame.CurrentPlayer.Options();
			PlayerOptions.RemoveAll(p => p.PlayerTaskType == PlayerTaskType.END_TURN);
			PlayerOptions.TrimExcess();
			if (poGame.Turn > turn && PlayerOptions.Count > 0)
			{
				turn = poGame.Turn;
				bestAction = OnlineEvolution(new List<PlayerTask>(PlayerOptions), poGame);
				PlayerTask EOT = poGame.CurrentPlayer.Options().Find(p => p.PlayerTaskType == PlayerTaskType.END_TURN);
				bestAction.Add(EOT);
				action = 0;
			}
			if (bestAction.Count > 0 && action < bestAction.Count)
				return bestAction[action++];
			else
				return poGame.CurrentPlayer.Options()[0];
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
			bestAction = new List<PlayerTask>();
		}
		private static List<PlayerTask> OnlineEvolution(List<PlayerTask> options, SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> bestIndividual = new List<PlayerTask>();
			int bestIndividualFitness = Int32.MinValue;
			List<PlayerTask>[] population = new List<PlayerTask>[populationSize];
			Dictionary<List<PlayerTask>, int> populationFitness = new Dictionary<List<PlayerTask>, int>(populationSize);
			int random = 0, n = 0, index = 0;
			//randomly initialize the population of size populationSize
			for (index = 0; index < populationSize; index++)
			{
				population[index] = new List<PlayerTask>(0);
				for (int j = 0; j < options.Count; j++)
				{
					random = Rnd.Next(0, options.Count);
					if (!population[index].Contains(options[random]))
						population[index].Add(options[random]);


				}
				if (!populationFitness.ContainsKey(population[index]))
					populationFitness.Add(population[index], 0);
			}
			
			

			while(n < Iterations)
			{
				//simualte games
				// evaluate the fitness of the population to choose individuals for recreation, save the best individual
				Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> simulatedGames = new Dictionary<PlayerTask, POGame.POGame>();
				for (int i = 0; i < populationSize; i++)
				{
					long sumFitness = 0;
					int tmpFitness = 0;
					simulatedGames = poGame.Simulate(population[i]);
					foreach (KeyValuePair<PlayerTask, SabberStoneCoreAi.POGame.POGame> p in simulatedGames)
					{
						tmpFitness += evaluate(poGame, p.Value);
					}
					//tmpFitness = (int)sumFitness / population[i].Count;
					if (populationFitness.ContainsKey(population[i]))
						populationFitness[population[i]] = tmpFitness;
					else
						populationFitness.Add(population[i], tmpFitness);
					if (bestIndividualFitness < tmpFitness)
					{
						bestIndividualFitness = tmpFitness;
						bestIndividual = new List<PlayerTask>(population[i]);
					}
				}
				// end of eval

				//Tournament Selection
				List<PlayerTask>[] matingPool = tournamentSelection(populationFitness, population);
				
				//crossover
				List<PlayerTask>[] offsprings = new List<PlayerTask>[matingPoolSize*2];
				List<PlayerTask>[] temp = new List<PlayerTask>[2];
				temp = crossover(matingPool[0], matingPool[matingPoolSize - 1]);
				offsprings[2 * matingPoolSize - 2] = new List<PlayerTask>(temp[0]);
				offsprings[2 * matingPoolSize - 1] = new List<PlayerTask>(temp[1]);
				for (int i = 0; i < matingPoolSize - 1; i++)
				{
					temp = crossover(matingPool[i], matingPool[i + 1]);
					offsprings[2 * i] = new List<PlayerTask>(temp[0]);
					offsprings[2 * i + 1] = new List<PlayerTask>(temp[1]);

				}
				
				//mutate
				for(int i = 0; i < 2*matingPoolSize; i++)
					mutate(options, offsprings[i]);

				//evaluation of the parent population and the next generation to choose which individual will survive
				for (int i = 0; i < 2 * matingPoolSize; i++)
				{
					//long sumFitness = 0;
					int tmpFitness = 0;
					simulatedGames = poGame.Simulate(offsprings[i]);
					foreach (KeyValuePair<PlayerTask, SabberStoneCoreAi.POGame.POGame> p in simulatedGames)
					{
						tmpFitness += evaluate(poGame, p.Value);
					}
					//tmpFitness = (int)sumFitness / offsprings[i].Count;
					if (!populationFitness.ContainsKey(offsprings[i]))
						populationFitness.Add(offsprings[i], tmpFitness);
					else
						populationFitness[offsprings[i]] = tmpFitness;
					if (bestIndividualFitness < tmpFitness)
					{
						bestIndividualFitness = tmpFitness;
						bestIndividual = new List<PlayerTask>(offsprings[i]);
					}
				}
				// end of eval

				//natural selection of populationSize many individuals from populationSize+2*matingPoolSize
				// parents and offsprings
				List<PlayerTask>[] survivors = naturalSelection(populationFitness,population,offsprings);
				population = new List<PlayerTask>[populationSize];
				for(int i = 0; i< populationSize; i++)
					population[i] = new List<PlayerTask>(survivors[i]);
				n++;
			}
			return bestIndividual;
		}

		// simulation is the game state after playing the strategies of one individual starting at state poGame
		private static int evaluate(SabberStoneCoreAi.POGame.POGame poGame, SabberStoneCoreAi.POGame.POGame simulation)
		{
			int reward = 0;
			if (simulation.CurrentPlayer.Hero.Health <= 0 || simulation.CurrentPlayer.Game.State.Equals(SabberStoneCore.Enums.PlayState.LOST)
						|| simulation.CurrentPlayer.Game.State.Equals(SabberStoneCore.Enums.PlayState.INVALID))
				return Int32.MinValue;
			if (simulation.CurrentOpponent.Hero.Health <= 0)
				return Int32.MaxValue;

			int CardsDrawn = simulation.CurrentPlayer.NumCardsDrawnThisTurn;
			int CardsPlayed = simulation.CurrentPlayer.NumCardsPlayedThisTurn;
			int TempMana = simulation.CurrentPlayer.TemporaryMana;
			int MinionsPlayed = simulation.CurrentPlayer.BoardZone.Count - poGame.CurrentPlayer.BoardZone.Count;
			int DamageToMinions = poGame.CurrentOpponent.BoardZone.Sum(p => p.Health) - simulation.CurrentOpponent.BoardZone.Sum(p => p.Health);
			int DamageBuffed = simulation.CurrentPlayer.BoardZone.Sum(p => p.AttackDamage) - poGame.CurrentPlayer.BoardZone.Sum(p => p.AttackDamage);
			int EnemyMinions = simulation.CurrentOpponent.BoardZone.Count+1;
			int weaponsPlayed = simulation.CurrentPlayer.Hero.EquippedWeapon - simulation.CurrentPlayer.Hero.EquippedWeapon >= 0 ? simulation.CurrentPlayer.Hero.EquippedWeapon - simulation.CurrentPlayer.Hero.EquippedWeapon:0;
			int MinionsKilled = poGame.CurrentOpponent.BoardZone.Count - simulation.CurrentOpponent.BoardZone.Count >= 0 ? poGame.CurrentOpponent.BoardZone.Count - simulation.CurrentOpponent.BoardZone.Count : 0;
			int minionHeroFocus = 0;
			int HeroHealed = simulation.CurrentPlayer.Hero.Health - poGame.CurrentPlayer.Hero.Health;
			int armor = simulation.CurrentPlayer.Hero.Armor - poGame.CurrentPlayer.Hero.Armor;
			foreach(var p in simulation.CurrentPlayer.BoardZone)
			{
				if (p.IsValidAttackTarget(simulation.CurrentOpponent.Hero))
					minionHeroFocus++;
			}
			int HeroMinionFocus = 0;
			if (poGame.CurrentOpponent.Hero.IsAttacking && (simulation.CurrentOpponent.BoardZone.Count < poGame.CurrentOpponent.BoardZone.Count))
			{
				HeroMinionFocus = 3;
			}
			int weaponsOnHandPre = 0;
			foreach (var c in poGame.CurrentOpponent.HandZone)
			{
				if (c.Card.Type == SabberStoneCore.Enums.CardType.WEAPON)
					weaponsOnHandPre++;
			}
			int HealthReduced = simulation.CurrentOpponent.Hero.Health > poGame.CurrentOpponent.Hero.Health ? 0 : poGame.CurrentOpponent.Hero.Health - simulation.CurrentOpponent.Hero.Health;
			int controlled = 0;
			if (simulation.CurrentOpponent.Hero.IsSilenced || simulation.CurrentOpponent.Hero.IsFrozen || simulation.CurrentOpponent.HeroPowerDisabled)
				controlled = 1;
			reward = MinionsKilled * 10 + HealthReduced * 30 + MinionsPlayed * 65 + DamageBuffed * 25
				+ weaponsPlayed * 20 + CardsDrawn * 20 + CardsPlayed * 25 + TempMana * 10 + controlled * 10
				+ armor * 80 + HeroHealed*100;
			return reward;
		}

		// removes and then adds a random option
		// swaps 2 options within individual
		private static void mutate(List<PlayerTask> options, List<PlayerTask> individual)
		{
			int pos = 0, pos1 = 0, pos2 = 0, random = 0;
			List<PlayerTask> copy = new List<PlayerTask>(individual);

			pos = Rnd.Next(0, copy.Count);
			copy.RemoveAt(pos);
			for (int i = 0; i < options.Count; i++)
			{
				random = Rnd.Next(0, options.Count);
				if (!copy.Contains(options[random]))
					copy.Insert(pos, options[random]);
			}
			
			copy = new List<PlayerTask>(copy);
			if(copy.Count > 1)
			{
				pos1 = Rnd.Next(0, copy.Count);
				while(pos1 == pos2)
					pos2 = Rnd.Next(0, copy.Count);
				PlayerTask tmp = copy[pos1];
				copy[pos1] = copy[pos2];
				copy[pos2] = tmp;
			}
			copy.TrimExcess();

			foreach (var a in copy)
			{
				if (copy.FindAll(p => p.Equals(a)).Count == 1)
					individual = new List<PlayerTask>(copy);
			}
			

			
		}
		private static List<PlayerTask>[] crossover(List<PlayerTask> individual1, List<PlayerTask> individual2)
		{
			List<PlayerTask>[] offspring = new List<PlayerTask>[2];
			offspring[0] = new List<PlayerTask>(0);
			offspring[1] = new List<PlayerTask>(0);
			int max = individual1.Count < individual2.Count ? individual1.Count : individual2.Count;
			int random = Rnd.Next(1, max);
			for(int i = 0; i < random; i++)
			{
				offspring[0].Add(individual1[i]);
				offspring[1].Add(individual2[i]);
			}
			for (int i = random; i < individual1.Count; i++)
			{
				if (!offspring[1].Contains(individual1[i]))
					offspring[1].Add(individual1[i]);
			}
			for (int i = random; i < individual2.Count; i++)
			{
				if (!offspring[0].Contains(individual2[i]))
					offspring[0].Add(individual2[i]);
			}
			for (int i = 0; i < 2; i++)
				offspring[i].TrimExcess();
			return offspring;
		}
		private static List<PlayerTask>[] tournamentSelection(Dictionary<List<PlayerTask>, int> populationFitness, List<PlayerTask>[] population)
		{
			List<PlayerTask>[] matingPool = new List<PlayerTask>[matingPoolSize];
			Dictionary<List<PlayerTask>, int> copyOfFitness = new Dictionary<List<PlayerTask>, int>(populationFitness);
			KeyValuePair<List<PlayerTask>, int> best = new KeyValuePair<List<PlayerTask>, int>();
			
			for(int i = 0; i < matingPoolSize; i++)
			{
				int[] tournamentIndices = new int[tournamentSize];
				int j = 1;
				for (int num = 0; num < tournamentIndices.Length; num++)
					tournamentIndices[num] = 0;
				tournamentIndices[0] = Rnd.Next(0, populationSize);
				while(j < tournamentIndices.Length)
				{
					tournamentIndices[j] = Rnd.Next(0, populationSize);
					if(!(tournamentIndices[j] == tournamentIndices[j - 1]))
						j++;
				}
				best = new KeyValuePair<List<PlayerTask>, int>(population[tournamentIndices[0]],copyOfFitness[population[tournamentIndices[0]]]);
				foreach(int num in tournamentIndices)
				{
					KeyValuePair<List<PlayerTask>, int> rndInd = new KeyValuePair<List<PlayerTask>, int>(population[num], copyOfFitness[population[num]]);
					if (best.Value > rndInd.Value)
						best = new KeyValuePair<List<PlayerTask>, int>(new List<PlayerTask>(rndInd.Key), rndInd.Value);
				}
				matingPool[i] = new List<PlayerTask>(best.Key);
				copyOfFitness[best.Key] = Int32.MinValue;
			}
			return matingPool;
		}
		private static List<PlayerTask>[] naturalSelection(Dictionary<List<PlayerTask>, int> populationFitness, List<PlayerTask>[] population, List<PlayerTask>[] offspring)
		{
			Dictionary<List<PlayerTask>, int> copyOfFitness = new Dictionary<List<PlayerTask>, int>(populationFitness);
			List<PlayerTask>[] newGen = new List<PlayerTask>[populationSize];
			for(int i = 0; i < populationSize; i++)
			{
				KeyValuePair<List<PlayerTask>, int> bestInd = new KeyValuePair<List<PlayerTask>, int>(population[0], copyOfFitness[population[0]]);
				foreach (var p in population)
				{
					if (copyOfFitness[p] > bestInd.Value)
						bestInd = new KeyValuePair<List<PlayerTask>, int>(new List<PlayerTask>(p), copyOfFitness[p]);
				}
				foreach (var p in offspring)
				{
					if (copyOfFitness[p] > bestInd.Value)
						bestInd = new KeyValuePair<List<PlayerTask>, int>(new List<PlayerTask>(p), copyOfFitness[p]);
				}
				copyOfFitness[bestInd.Key] = int.MinValue;
				newGen[i] = new List<PlayerTask>(bestInd.Key);
			}
			return newGen;
		}
	}
	
}
