﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using SabberStoneCore.Enums;
using SabberStoneCore.Exceptions;
using SabberStoneCore.Model;
using SabberStoneCore.Model.Entities;
using SabberStoneCore.Model.Zones;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.IkarusOld;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Tasks.PlayerTasks;


//Developed by Anonymous Author (Thanduriel)
namespace SabberStoneCoreAi.Agent
{
	class Ikarus : AbstractAgent
	{



		class Node
		{

			public PlayerTask task;
			public int numSimulations;
			public int numWins;
			//	public int currentPlayerId;

			public Node[] childs;
			public int numChilds;
		}

		class TreeState
		{
			public TreeState(Node _node, CompactGameStateOld _gameState)
			{
				gameState = _gameState;
				parents = new HashSet<Node> { _node };
			}
			public CompactGameStateOld gameState;
			public HashSet<Node> parents;
		}

		private Random Rnd = new Random();
		private int playerId;
		private double turnTime;
		private Stopwatch turnWatch;
		private int gameCount = 0;
		// cache with possible gamestates
		private Dictionary<int, List<TreeState>> previousStates;
		private DeckTracker deckTracker;
		private int currentTurn = -1;
		public bool useRandomSelection = false;


		public GameStateLogOld log = new GameStateLogOld();

		public int numHits = 0;
		public int numMisses = 0;

		public Ikarus(double _turnTime = 65.0, bool _useRandomSelection = false)
		{
			turnTime = _turnTime;
			useRandomSelection = _useRandomSelection;
			previousStates = new Dictionary<int, List<TreeState>>();
			turnWatch = new Stopwatch();
		}

		public Ikarus() : this(10.0, true) {
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
			++gameCount;
		//	Console.WriteLine($"{numHits}, {numMisses}");
		//	Console.WriteLine($"per simulation: {timeTakenSim}; per check: {timeTakenCheck}");
		//	Console.WriteLine(gameCount);
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			if (deckTracker == null)
			{
				deckTracker = new DeckTracker(poGame.CurrentOpponent.HeroClass);
			}
			// new turn
			if(poGame.Turn != currentTurn)
			{
				turnWatch.Restart();
				previousStates.Clear();
				log.Advance();
				currentTurn = poGame.Turn;
				deckTracker.Update(poGame.CurrentOpponent.PlayHistory);
			}
			int numSims = 0;

			// remember self
			playerId = poGame.CurrentPlayer.PlayerId;

			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			// needs to be done once so that game process works
			Dictionary<PlayerTask, POGame.POGame> simStates = poGame.Simulate(options);
			Node root = new Node();

			Expand(root, options);

			double begin = turnWatch.Elapsed.TotalSeconds;
			double timeLeft = turnTime - turnWatch.Elapsed.TotalSeconds;
			double end = 2.0 + timeLeft * 0.4;
			turnTime = begin + timeLeft;
			if (turnTime > 74.0) turnTime = timeLeft * 0.5;
		//	Console.WriteLine(timeLeft);
			do
			{
				for (int i = 0; i < 8; ++i)
				{
					Node node = Select(root);
					GameResult result = Playout(node, poGame);
					// back-propagate
					foreach (TreeState treeState in statesVisited)
					{
						++treeState.gameState.numSimulations;
						if (treeState.gameState.currentPlayerId == (int)result) ++treeState.gameState.numWins;
					}
					++numSims;
					++root.numSimulations;

					foreach (Node n in relevantActions) ++n.numSimulations;
					if (playerId == (int)result /*|| result == GameResult.TIE*/)
					{
						foreach (Node n in relevantActions)
							++n.numWins;
					}
				}
				
			} while (turnWatch.Elapsed.TotalSeconds < turnTime);

			float max = 0f;
			PlayerTask maxTask = options[0];//RandomPlay(options);
			for(int i = 1; i < root.numChilds; ++i)
			{
				float r = (float)root.childs[i].numWins / root.childs[i].numSimulations;
				if(r > max)
				{
					max = r;
					maxTask = root.childs[i].task;
				}
			}
		//	Console.WriteLine(numSims);
			return maxTask;
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
		}

		public override void InitializeGame()
		{
		}

		private void Expand(Node node, List<PlayerTask> playerTasks)
		{
			node.childs = new Node[playerTasks.Count];
			node.numChilds = playerTasks.Count;

			for (int i = 0; i < playerTasks.Count; ++i)
			{
				node.childs[i] = new Node();
				node.childs[i].task = playerTasks[i];
				node.childs[i].numSimulations = 1;
			}
		}

		private Node Select(Node node)
		{
			if(useRandomSelection) return node.childs[Rnd.Next(node.numChilds)];

			float max = 0f;
			float numSimsLog = (float)Math.Log(node.numSimulations);
			int maxInd = 0;
			for(int i = 0; i < node.numChilds; ++i)
			{
				float f = (float)node.childs[i].numWins / node.childs[i].numSimulations
					+ 1.41f * (float)Math.Sqrt(numSimsLog / node.childs[i].numSimulations);

				if(f > max)
				{
					max = f;
					maxInd = i;
				}
			}
			return node.childs[maxInd];
		}

		private enum GameResult
		{
			TIE = 0,
			FIRSTPLAYER = 1,
			SECONDPLAYER = 2
		}

		private int numSims = 0;
		private double timeTakenSim = 0.0;
		private double timeTakenCheck = 0.0;

		// all states visited in the current play out
		private HashSet<TreeState> statesVisited = new HashSet<TreeState>();
		// all actions that could result in the current state
		private HashSet<Node> relevantActions = new HashSet<Node>();

		private GameResult Playout(Node node, POGame.POGame initialState)
		{
			statesVisited.Clear();
			relevantActions.Clear();
			relevantActions.Add(node);
			DeckTracker localTracker = new DeckTracker(deckTracker);
			localTracker.Shuffle();
			Game gameState = null;
			try
			{
				gameState = node.task.Game.Clone();
			}
			catch (Exception) { return PredictResult(node.task.Game); }
			try
			{
				
				RecoverOpponentCards(gameState, localTracker);
				gameState.Process(node.task);
			} catch(Exception) { return PredictResult(gameState); }

			int count = 0;
			while (true)
			{
				++count;
				if (gameState.State == State.COMPLETE)
				{
					// determine end
					if(gameState.CurrentPlayer.PlayState == PlayState.WON)
						return (GameResult)gameState.CurrentPlayer.PlayerId;
					if (gameState.CurrentOpponent.PlayState == PlayState.WON)
						return (GameResult)gameState.CurrentOpponent.PlayerId;
					return GameResult.TIE;
				}
				if (count > 13) return PredictResult(gameState);
				// advance game state
				List<PlayerTask> tasks = gameState.CurrentPlayer.Options();
				if (tasks.Count == 0) return GameResult.TIE;
				try
				{
					++numSims;
					Stopwatch sw = new Stopwatch();
					sw.Start();
					gameState.Process(RandomPlay(tasks));
					timeTakenSim += sw.Elapsed.TotalSeconds;
					sw.Reset();
					if (gameState.Turn == currentTurn)
					{
					//	log.Add(gameState);
						int key = GameHash(gameState);
						List<TreeState> possibleMatches;
						CompactGameStateOld newState = new CompactGameStateOld(gameState);
						if (previousStates.TryGetValue(key, out possibleMatches))
						{
							TreeState found = possibleMatches.Find(game => game.gameState == newState);
							if (found == null)
							{
								possibleMatches.Add(new TreeState(node, newState));
							}
							else
							{
								// previously unknown parent
								if (found.parents.Add(node))
								{
									node.numSimulations += found.gameState.numSimulations;
									node.numWins += found.gameState.numWins;
								}
								foreach (Node n in found.parents)
								{
									relevantActions.Add(n);
								}
								statesVisited.Add(found);
							}
						}
						else
						{
							List<TreeState> states = new List<TreeState>();
							states.Add(new TreeState(node, newState));
							previousStates.Add(key, states);
						}
					}
					timeTakenCheck += sw.Elapsed.TotalSeconds;
				}
				catch (Exception)
				{
					return PredictResult(gameState);
				}
			}
		}

		// Return a uniform random play from the list
		private PlayerTask RandomPlay(List<PlayerTask> playerTasks)
		{
			return playerTasks[Rnd.Next(playerTasks.Count)];
		}

		private void FilterTasks(List<PlayerTask> playerTasks)
		{
		//	playerTasks.RemoveAll(t => try { return t.Source.Id; } )
		}

		private int GameHash(Game game)
		{
			int s = game.CurrentPlayer.NumOptionsPlayedThisTurn | (game.CurrentOpponent.Hero.Health << 4)
				| (game.CurrentPlayer.Hero.Health << 9)
				| (game.CurrentPlayer.UsedMana << 28);
			int shift = 14;
			foreach (SabberStoneCore.Model.Entities.Minion entity in game.Minions)
			{
				s ^= entity.Health << shift;
				shift += 2;
			}
			return s;
		}

		private void AddCardToZone(IZone zone, Card card, Controller player, Game game)
		{
			Entity.FromCard(player, card, null, zone);
		}

		private void RecoverOpponentCards(Game game, DeckTracker deckTracker)
		{
			int numCardsDeck = game.CurrentOpponent.DeckZone.Count;
			int numCardsHand = game.CurrentOpponent.HandZone.Count;

			game.CurrentOpponent.DeckCards = deckTracker.Deck;
			game.CurrentOpponent.HandZone = new HandZone(game.CurrentOpponent);
			game.CurrentOpponent.DeckZone = new DeckZone(game.CurrentOpponent);

			for (int i = 0; i < numCardsHand; ++i)
			{
				Card c = deckTracker.Draw();
				if (c == null) break;
				AddCardToZone(game.CurrentOpponent.HandZone, c, game.CurrentOpponent, game);
			}

			for (int i = 0; i < deckTracker.CardsLeft.Count; ++i)
			{
				AddCardToZone(game.CurrentOpponent.DeckZone, deckTracker.CardsLeft[i], game.CurrentOpponent, game);
			}
		}


		const float cardWeight = 2f;
		const float healthWeight = 0.2f;
		const float manaWeight = 0.8f;
		Tuple<float,float> Evaluate(Game game)
		{


			float valueA = game.CurrentPlayer.HandZone.Count * cardWeight + game.CurrentPlayer.Hero.Health * healthWeight
				+ game.CurrentPlayer.RemainingMana * manaWeight;
			float valueB = game.CurrentOpponent.HandZone.Count * cardWeight + game.CurrentOpponent.Hero.Health * healthWeight;

			foreach(Minion minion in game.Minions)
			{
				float v = minion.Health + minion.Damage;
				if (minion.Controller.PlayerId == game.CurrentPlayer.PlayerId) valueA += v;
				else valueB += v;
			}

			return new Tuple<float, float>(valueA, valueB);
		}

		GameResult PredictResult(Game game)
		{
			Tuple<float, float> values = Evaluate(game);

			return (GameResult)(Rnd.NextDouble() * values.Item1 > Rnd.NextDouble() * values.Item2 ? game.CurrentPlayer.PlayerId : game.CurrentOpponent.PlayerId);
		}

		private bool IsEqual(Game game1, Game game2)
		{
			if (game1.Minions.Count != game2.Minions.Count) return false;

			for(int i = 0; i < game1.Minions.Count; ++i)
			{
				SabberStoneCore.Model.Entities.Minion entity1 = game1.Minions[i];
				SabberStoneCore.Model.Entities.Minion entity2 = game2.Minions[i];

				if (entity1.Health != entity2.Health || entity1.AttackDamage != entity2.AttackDamage
					|| entity1.Card.Id != entity2.Card.Id)
					return false;
			}
	/*		foreach(SabberStoneCore.Model.Entities.Minion entity in game1.Minions)
			{
				totalHealth += entity.Health;
				totalPower += entity.AttackDamage;
			}
			foreach (SabberStoneCore.Model.Entities.Minion entity in game2.Minions)
			{
				totalHealth -= entity.Health;
				totalPower -= entity.AttackDamage;
			}*/
			bool b = game1.Turn == game2.Turn
				&& game1.CurrentPlayer.NumOptionsPlayedThisTurn == game2.CurrentPlayer.NumOptionsPlayedThisTurn
				&& game1.CurrentPlayer.Hero.Health == game2.CurrentPlayer.Hero.Health
				&& game1.CurrentOpponent.Hero.Health == game2.CurrentOpponent.Hero.Health
				&& game1.CurrentPlayer.TotalManaSpentThisGame == game2.CurrentPlayer.TotalManaSpentThisGame;

			return b;
		}
	}
}
