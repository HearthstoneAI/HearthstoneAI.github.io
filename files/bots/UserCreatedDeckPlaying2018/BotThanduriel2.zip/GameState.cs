﻿using SabberStoneCore.Model;
using System.Collections.Generic;

namespace SabberStoneCoreAi.IkarusOld
{

	struct CompactMinionOld
	{
		public CompactMinionOld(int _health, int _damage, string _cardId)
		{
			health = _health;
			damage = _damage;
			cardId = _cardId;
		}

		public int health;
		public int damage;
		public string cardId;
	}

	class GameStateLogOld
	{
		List<List<CompactGameStateOld>> history = new List<List<CompactGameStateOld>>();

		public void Add(Game game)
		{
		//	history[history.Count - 1].Add(new CompactGameState(game));
		}
		public void Advance()
		{
			history.Add(new List<CompactGameStateOld>());
		}

		public float Test(HashFunction function)
		{
			int numHits = 0;
			int numMisses = 0;

			Dictionary<int, CompactGameStateOld> dict = new Dictionary<int, CompactGameStateOld>();
			foreach (List<CompactGameStateOld> turn in history)
			{
				dict.Clear();
				foreach (CompactGameStateOld state in turn)
				{
					int key = function.Hash(state);
					CompactGameStateOld g;
					if (dict.TryGetValue(key, out g))
					{
						if (state != g)
							++numMisses;//Console.WriteLine("collision");
						else ++numHits;
					}
					else dict.Add(key, state);
				}
			}

			float r = (float)numHits / numMisses;

		//	System.Console.WriteLine($"{numHits} / {numMisses} = {r}");

			return r;
		}
	}

	class CompactGameStateOld
	{
		public CompactGameStateOld(Game game)
		{
			minions = new List<CompactMinionOld>();
			minions.Capacity = game.Minions.Count;
			foreach (SabberStoneCore.Model.Entities.Minion entity in game.Minions)
			{
				minions.Add(new CompactMinionOld(entity.Health, entity.AttackDamage, entity.Card.Id));
			}

			currentPlayerHealth = game.CurrentPlayer.Hero.Health;
			currentOpponentHealth = game.CurrentOpponent.Hero.Health;
			currentPlayerMana = game.CurrentPlayer.RemainingMana;
			optionsPlayed = game.CurrentPlayer.NumOptionsPlayedThisTurn;

			currentPlayerId = game.CurrentPlayer.PlayerId;
		}

		public static bool operator== (CompactGameStateOld lhs, CompactGameStateOld rhs)
		{
			if (lhs.currentPlayerHealth != rhs.currentPlayerHealth) return false;
			if (lhs.currentOpponentHealth != rhs.currentOpponentHealth) return false;
			if (lhs.currentPlayerMana != rhs.currentPlayerMana) return false;
			if (lhs.optionsPlayed != rhs.optionsPlayed) return false;
			if (lhs.minions.Count != rhs.minions.Count) return false;

			for (int i = 0; i < lhs.minions.Count; ++i)
			{
				CompactMinionOld entity1 = lhs.minions[i];
				CompactMinionOld entity2 = rhs.minions[i];

				if (entity1.health != entity2.health || entity1.damage != entity2.damage
					|| entity1.cardId != entity2.cardId)
					return false;
			}
			return true;
		}

		public static bool operator !=(CompactGameStateOld lhs, CompactGameStateOld rhs)
		{
			return !(lhs == rhs);
		}

		public List<CompactMinionOld> minions;
		public List<int> playerCards;
		public List<int> opponentCards;
		public int currentPlayerHealth;
		public int currentOpponentHealth;
		public int currentPlayerMana;
		public int optionsPlayed;

		public int currentPlayerId;

		public int numSimulations = 0;
		public int numWins = 0;
	}

	class HashFunction
	{
		public const int NUM_ARGS = 18;
		public int[] shifts;

		// generate new
		public HashFunction()
		{
			System.Random rng = new System.Random();
			shifts = new int[NUM_ARGS];
			for(int i = 0; i < NUM_ARGS; ++i)
			{
				shifts[i] = rng.Next(32);
			}
		}

		public int Hash(CompactGameStateOld state)
		{
			int h = 0;

			h ^= state.currentPlayerHealth << shifts[0];
			h ^= state.currentOpponentHealth << shifts[1];
			h ^= state.optionsPlayed << shifts[2];
			h ^= state.currentPlayerMana << shifts[3];
			for(int i = 0; i <state.minions.Count; ++i)
			{
				h ^= state.minions[i].health << shifts[4+i];
			}

			return h;
		}

		public override string ToString()
		{
			string s = "";
			for (int i = 0; i < NUM_ARGS; ++i)
			{
				s += shifts[i];
				s += ", ";
			}

			return s;
		}
	}
}
