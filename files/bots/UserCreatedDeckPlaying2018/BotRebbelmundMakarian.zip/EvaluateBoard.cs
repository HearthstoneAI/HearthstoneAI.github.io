﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SabberStoneCoreAi.Agent
{
    class EvaluateBoard
    {
		/********parameter to evaluate board:******************
		 * 
		 * x0 = own healthpoints
		 * x1 = enemy hp
		 * x2 = friendly minion that died this turn
		 * x3 = sum of attackvalue of minions
		 *		enemy attack sum
		 * x5 = sum of defence value of minions
		 *		enemy defence sum
		 * x7 =

		 * 
		 ***********************************/

		

		public static double evaluate(POGame.POGame poGame, double[] weights)
		{
			double[] x_table = calcX_Table(poGame);
			return calc_Vvalue(x_table, weights);
		}

		public static double[] calcX_Table(POGame.POGame poGame)
		{
			double[] tmp_x_table = new double[10];
			tmp_x_table[1] = poGame.CurrentPlayer.Hero.Health;
			tmp_x_table[0] = poGame.CurrentOpponent.Hero.Health;

			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.Minions)
			{
				if (minion.Controller == poGame.CurrentPlayer.Hero.Controller)
				{
					tmp_x_table[3]++;
					tmp_x_table[5] += minion.AttackDamage;
					tmp_x_table[7] += minion.Health;
				}
				else
				{
					tmp_x_table[2]++;
					tmp_x_table[4] += minion.AttackDamage;
					tmp_x_table[6] += minion.Health;
				}
			}
			return tmp_x_table;
		}

		//Calculate V-value
		static double calc_Vvalue(double[] x_table,double[] weights)
		{
			double V = 0;
			for (int i = 0; i < x_table.Length; i++)
			{
				V += x_table[i] * weights[i];
			}
			return V;
		}
	}
}
