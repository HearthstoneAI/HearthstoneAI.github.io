﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCore.Model;

//Developed by Jonas Rebbelmund und Nepomuk Markarian
namespace SabberStoneCoreAi.Agent
{
	class BotRebbelmundMakarian : AbstractAgent
	{
		List<Card> deck;
		CardClass hero;

		public BotRebbelmundMakarian(){
			deck = Decks.RenoKazakusMage;
			hero = CardClass.MAGE;
		}
		
		private Random Rnd = new Random();

		//Initialisation Variables/////////////////////////////////////////////////////////////
		//maximum number of generatet PlayerTask-Lists
		//has a huge performance impact!!!
		int maxNumberOfLists = 1000;
		//weight vector
		double[] weights = { 2, -4, 2, -10, 0.1, -0.2, 0.1, -0.2, 1, -1 };
		//allow prints during simulation
		bool verbose = false;
		/// ////////////////////////////////////////////////////////////////////

		//Other Purpose Variables////////////////////////////////////////////////////////////////
		int turn = -1;  //counts turns
		int game = 0;	//counts games
		List<POGame.POGame> boardList = new List<POGame.POGame>(); //list of stored states during game
		List<double> v_list = new List<double>();                   //list of stored v values
		List<PlayerTask> tasklist = new List<PlayerTask>(); //list of Tasks to do during turn
		

		public override void FinalizeAgent()
		{
			//seems to get never called
			//Console.WriteLine("-----------------FinalizeAgent() called------------------");
		}

		public override void FinalizeGame() //called after every game
		{
			/*
			 * do learning task (update w_i's)
			 * store to .csv
			 */
			if (false)
			{
				/*
				Console.WriteLine("-----------------FinalizeGame() called------------------");
				Console.WriteLine("hero dead? " + boardList[boardList.Count - 1].CurrentPlayer.Hero.IsDead);
				Console.WriteLine("hero to be destroyed? " + boardList[boardList.Count - 1].CurrentPlayer.Hero.ToBeDestroyed);
				Console.WriteLine("hero hp: " + boardList[boardList.Count - 1].CurrentPlayer.Hero.Health);
				Console.WriteLine("enemy hero hp: " + boardList[boardList.Count - 1].CurrentOpponent.Hero.Health);
				Console.WriteLine("state: " + boardList[boardList.Count - 1].CurrentPlayer.PlayState); */

			}

		}

		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			
			
			if(true)//(tasklist.Count == 0)
			{

				turn++;
				tasklist = calcTaskList(poGame);
				
				if (false && verbose)
				{
					//Console.WriteLine("--------------Turn: " + turn + ", tasklist updated-----------");
					//Console.WriteLine("v_value: " + v_list[v_list.Count - 1]);
				}
				
				
			}
			PlayerTask task = tasklist[0];
			tasklist.RemoveAt(0);
			if (false && verbose)
			{
				//print chosen option
				//Console.WriteLine(task.FullPrint());
				if (task.PlayerTaskType == PlayerTaskType.END_TURN)
				{
					//Console.WriteLine("------------------------------------------------------------");
				}
			}

			return task;

		}

		List<PlayerTask> calcTaskList(POGame.POGame poGame)
		{
			int numberOfLists = (int)Math.Pow(poGame.CurrentPlayer.Options().Count , 3);
			if (numberOfLists > maxNumberOfLists) //Cap for number of lists to be generated
			{
				numberOfLists = maxNumberOfLists;
			}

			double[] v_table = new double[numberOfLists];
			int best = 0; //best candidate from v_table
			POGame.POGame best_poGame = poGame;
			

			//1. generate thousand taskslists
			//2. evaluate them
			//3. execute best tasklist

			//init lists
			List<List<PlayerTask>> tasklist_list = new List<List<PlayerTask>>();
			for(int i = 0; i < numberOfLists; i++)
			{
				tasklist_list.Add(new List<PlayerTask>());
			}

			//print options
			if (false && verbose)
			{
				//Console.WriteLine("------------------------possible Options-----------------------");
				foreach (PlayerTask task in poGame.CurrentPlayer.Options())
				{
					//Console.WriteLine(task.FullPrint());
				}
			}
			
			//produce tasklists
			for (int i = 0; i < numberOfLists; i++)
			{
				POGame.POGame tmp_poGame = poGame.getCopy(false);
				List<PlayerTask> tasklist = tasklist_list[i];
				PlayerTask next_option = null;

				//initialize bestGame
				if (i == 0)
				{
					best_poGame = tmp_poGame;
				}
				try
				{
					while (next_option == null || next_option.PlayerTaskType != PlayerTaskType.END_TURN)
					{
						//generate
						List<PlayerTask> option_list = tmp_poGame.CurrentPlayer.Options();
						next_option = option_list[Rnd.Next(option_list.Count)];
						tasklist.Add(next_option);
						tmp_poGame.Process(next_option);
					}
					//evaluate
					v_table[i] = EvaluateBoard.evaluate(tmp_poGame, weights);
				}
				catch(Exception e)
				{
					//Console.WriteLine(e.Message);
					//Console.WriteLine(e.StackTrace);
					v_table[i] = 0;
					continue;
				}
				//look for better tasklist
				if (v_table[best] < v_table[i])
				{
					best = i;
					best_poGame = tmp_poGame;
				}

				//print tasklists
				if (false && verbose)
				{
					//Console.WriteLine("-----------------------Tasklist--------------------------");
					for (int j = 0; j < tasklist.Count; j++)
					{
						//Console.WriteLine(tasklist[j].FullPrint());
					}
					//Console.WriteLine("points: " + v_table[i]);
				}
			}

			

			//store board and value
			boardList.Add(poGame.getCopy(false));
			v_list.Add(EvaluateBoard.evaluate(poGame, weights));

			//print chosen Tasklist
			if (false && verbose)
			{
				//Console.WriteLine("-----------------------Chosen Tasklist--------------------------");
				for (int j = 0; j < tasklist_list[best].Count; j++)
				{
					//Console.WriteLine(tasklist_list[best][j].FullPrint());
				}
				//Console.WriteLine("points: " + v_table[best]);
			}

			//print own and enemy hero hp
			if (true && verbose)
			{
				//Console.WriteLine("Hero Hp, before" + poGame.CurrentPlayer.Hero.Health + " and after " + best_poGame.CurrentOpponent.Hero.Health);
				//Console.WriteLine("Enemy Hero Hp, before" + poGame.CurrentOpponent.Hero.Health + " and after " + best_poGame.CurrentPlayer.Hero.Health);
				//Console.WriteLine();
			}

			return tasklist_list[best];
		}

		public override void InitializeAgent()
		{
			//Console.WriteLine("-----------------InitializeAgent() called------------------");
			Rnd = new Random();

	
		}

		public override void InitializeGame()  //called before every game
		{
			//Console.WriteLine("-----------------"+ game++ +" InitializeGame() called------------------");
			turn = -1;
			//lade gewichte aus .csv
			//falls keine vorhanden initialisiere mit random werten [-1,1]
		}

	}
}
