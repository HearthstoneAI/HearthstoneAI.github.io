using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Tasks.PlayerTasks;
using System.Security.Cryptography;


// Developed by Anonymous Author (Motochris)
namespace SabberStoneCoreAi.Agent
{
	class BruteCore_V3 : AbstractAgent
	{
		
		public BruteCore_V3(){
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}

		public Dictionary<int, Dictionary<int, double>> stateTaskValues = new Dictionary<int, Dictionary<int, double>>();
		public Dictionary<int, List<int>> countTask = new Dictionary<int, List<int>>();

		private double gameLen = 0;
		private int gameCou = 0;

		private int myhealth = 0;
		private int ophealth = 0;

		bool learn = false;

		// HELPER FUNCTION

		public static int GetStableHashCode(string str) // CREDIT TO Scott Chamberlain at: https://stackoverflow.com/questions/36845430/persistent-hashcode-for-strings 
		{
			unchecked
			{
				int hash1 = 5381;
				int hash2 = hash1;

				for (int i = 0; i < str.Length && str[i] != '\0'; i += 2)
				{
					hash1 = ((hash1 << 5) + hash1) ^ str[i];
					if (i == str.Length - 1 || str[i + 1] == '\0')
						break;
					hash2 = ((hash2 << 5) + hash2) ^ str[i + 1];
				}

				return hash1 + (hash2 * 1566083941);
			}
		}
		

		class Values
		{
			BruteCore_V3 instance;
			public string state = "";

			public Values(BruteCore_V3 agent, POGame.POGame poGame)
			{
				instance = agent;
				List<PlayerTask> opt = poGame.CurrentPlayer.Options();
				state = poGame.CurrentPlayer.HeroClass.ToString() + poGame.CurrentOpponent.HeroClass.ToString();}

			public int getHash(PlayerTask pt)
			{
				return GetStableHashCode(pt.FullPrint() + state);
			}

			public double valueof(PlayerTask pt)
			{
				int key = getHash(pt);
				int kkey = GetStableHashCode(state);
				if (instance.stateTaskValues.ContainsKey(kkey))
				{
					if (instance.stateTaskValues[kkey].ContainsKey(key)) return instance.stateTaskValues[kkey][key];
					else return new Random().NextDouble() / 10.0;

				}
				else return new Random().NextDouble() / 10.0;
			}


		}


		public override void InitializeAgent()
		{
			if (learn)
			{
				if (!File.Exists("weights.txt"))
				{
					File.Create("weights.txt");
				}
				else
				{
					if (stateTaskValues.Count > 0) return;

					string lastLine = "";

					lastLine = File.ReadLines("weights.txt").Last();
					string[] strs = lastLine.Split('~');

					for (int i = 1; i < strs.Length; i++)
					{
						string[] splitstrs = strs[i].Split(':');

						string key = splitstrs[0];

						for (int j = 1; j < splitstrs.Length; j++)
						{
							string[] splitstrspls = splitstrs[j].Split('+');
							if (!stateTaskValues.ContainsKey(Convert.ToInt32(key)))
							{
								Dictionary<int, double> en = new Dictionary<int, double>();

								en.Add(Convert.ToInt32(splitstrspls[0]), Convert.ToDouble(splitstrspls[1]));
								stateTaskValues.Add(Convert.ToInt32(key), en);
							}
							else
							{
								stateTaskValues[Convert.ToInt32(key)].Add(Convert.ToInt32(splitstrspls[0]), Convert.ToDouble(splitstrspls[1]));
							}
						}
					}

				}
			} else
			{
				if (stateTaskValues.Count > 0) return;

				string lastLine = "~1352966462:1152701271+-874305,976744131:496707478+61756,0161290326:1990955235+29742,0238095235:32415244+678482,01265818:670843326+266503,027777774:103277461+95783,0166666677:-1836992810+4418,02000000003:-47843918+-14,9896907216495:-1747040423+288928,019230765:1893596375+25956,0163934428:474265024+13,0120481927711:1667849073+63848,0285714287:747081401+483133,017857124:-18231555+272601,0263158:-189430405+181157,024390244:816798844+26200,02:-1108658168+27757,0192307692:-1361068407+16553,0204081633:-614900125+249732,03333334:710467821+138553,031250001:-1509882377+889,014925373136:767444412+230734,020408163:-572407055+29365,0384615383:864674603+222069,018867924:1893137487+21602,0256410257:-1325032278+34254,0256410259:-2073472543+239392,032258069:-1350772880+77542,0384615373:-1648745698+29699,0212765959:1056995744+-4,97959183673469:216645797+-44,9677419354839:-165714514+14612,0175438598:-1547045539+776,01923076923:-1934810558+8982,01754385954:-513718515+21674,0357142858:-670280166+272389,025641035:1225129555+4361,01694915254:-364138266+27,0277777777778:295883936+-124,954545454545:981007804+142555,029411763:2012152737+19131,0263157894:-1300741697+21194,0172413792:-57960958+38279,0344827588:1831784102+27,0384615384615:914616592+15247,0270270271:-798706976+25,0344827586207:-1836793664+1132,03125:-2129800895+73254,0399999996:263383532+28,0294117647059:91318386+4328,02564102564:2109970485+17017,0217391305:-1709072408+24188,0250000001:-53598250+-856815,987341719:-1256466644+11999,0126582279:-36243817+486119,019607854:319300735+78355,0294117659:1444970822+307242,024390247:1440606349+269871,032258072:-703830806+244221,019607838:-1392905687+233718,026315794:555942180+-129,961538461538:368210565+319577,022222221:-254724762+25140,0204081633:1564234471+719018,024999999:-1512023141+267926,027027048:403780999+24682,0238095238:1797784332+-74,9772727272727:-918769067+18306,0192307693:-767360596+31319,0285714282:-389002781+249790,019230779:1317772446+159961,020833337:-202686438+28,0263157894737:501598747+30554,0312500001:850326977+25860,03125:-1311229837+2010,01785714286:-1018618277+27,0217391304348:1072530294+29220,0270270271:1718125794+981,033333333333:-521502133+65533,0256410261:-1659007054+212865,027027035:-165877576+64023,0303030311:836958889+-119,954545454545:2021468572+24268,027777778:644776587+27,030303030303:-858712842+48199,0277777777:93558023+11382,0192307691:147334237+148289,029411763:-570486282+8776,02564102563:648518657+128575,021739133:-103316291+17432,027027027:-1872412335+26717,0227272727:1259771164+4013,02272727274:-1210577014+81801,0263157907:-669542848+32259,0312499999:2040759773+64525,0322580653:1001735448+12869,025:-711763891+1082,0303030303:921121823+20718,0238095238:1129842350+-69,975:-1743998468+21,0227272727273:-2023820806+19052,0312499999:-1925215939+15235,0222222222:1848058389+30,0243902439024:1685659612+23,0277777777778:-43067788+3001,02702702703:834745924+12,016393442623:174192947+19,027027027027:-139474237+752,038461538461:1908055998+2966,02564102564:562620128+9807,03703703701:1881895925+2610,02173913044:1953464197+20637,0384615384:-84292749+15,025:-764503146+30,0232558139535:1343490448+27,0277777777778:-892453818+27,0434782608696:252372528+24234,0227272729:1947733881+10,025:1940196786+17,027027027027:1198609762+4034,02222222222:-1990798553+7,02702702702703:-405751976+28,0344827586207:-1095472331+774,029411764705:813733621+26,025641025641:2112089028+11,0188679245283:79829331+19,025641025641:-1675538021+5124,01785714286:436659313+1091,01639344262:1177142956+21,0263157894737:600655313+9134,01960784311:-1659782117+569,027027027027:-798782252+1952,02857142857:-877408320+24,025:1898025034+26,0344827586207:-284270876+11050,0222222223:-588050179+3455,02222222222:998874299+27,03125:402017562+16,0144927536232:1424730334+25,027027027027:-940508047+28,0322580645161:1506637979+27,0232558139535:340608366+27,0222222222222:1967366923+25,0263157894737:-1206475916+7824,03333333337:-722436353+1026,0243902439:1164802845+6735,01886792452:723467201+29,030303030303:-2038103413+30,0243902439024:-1358298129+24,0277777777778:-1895134554+29,04:-1917734907+811,028571428572:-675641832+29,0294117647059:-820338726+2878,03448275862:991969497+4767,025:-1127384681+30,0285714285714:590226511+29,025641025641:1012032845+221,037037037037:-539089955+1673,02857142857:1305940932+843,035714285714:1965125592+3431,03846153846:-1222162895+19,0238095238095:-1748391499+22,0217391304348:246789613+15,0138888888889:444063766+15460,03125:36696944+1230,02:-1824021906+20,015873015873:-632274877+8811,03448275862:120551972+14,0357142857143:-2053366920+3645,02380952381:1262620593+1809,01694915254:-176483281+786,050000000001:-950926276+21,0277777777778:779875450+1174,02:-1916029924+26,0285714285714:-488934858+22,0294117647059:-1453340958+15376,0370370371:1575674380+27,0285714285714:-472668534+4407,02000000003:-541630848+30,0322580645161:-1689289606+29,02:-1978316439+30,0526315789474:-637126942+13,0217391304348:-40170187+-34,975:-1399125453+5,01960784313725:1783044655+21,0204081632653:522971271+30,0384615384615:-1112521726+30,027027027027:-497043437+30,0322580645161:-1332394398+26,03125:459377704+25,0333333333333:509591835+30,0322580645161:-1504136680+664,025:773446130+28,030303030303:698473061+679,02:-793946407+30,027027027027:1161734177+4,01851851851852:591839058+21,0217391304348:-1850832319+26,0232558139535:179367093+25,027027027027:-471648386+12,0243902439024:350190276+6465,02777777776:65985825+30,0322580645161:750031147+29,0294117647059:-1204699327+21,0217391304348:-880935965+29,0357142857143:-141746734+1311,0303030303:1664335060+24,04:-365791903+3,03125:818169768+29,0277777777778:-1557141304+27,0277777777778:911563041+26,0238095238095:970413023+11,0185185185185:-1213467973+30,030303030303:-1328417815+30,0333333333333:1923865834+7,02040816326531:470061876+30,0238095238095:893932510+30,0243902439024:573663401+14,0222222222222:766756163+25,0238095238095:1920866219+24,0357142857143:-191142744+19,0222222222222:-1638522854+1537,02777777778:-528924132+631,022727272727:1262217058+7,02564102564103:1349709233+26,0294117647059:1276355819+25,0285714285714:755023845+29,0285714285714:-361954467+19,0232558139535:1078397212+26,0416666666667:481986056+24,0294117647059:21177075+1,02083333333333:-308816078+25,0344827586207:-929922273+30,0285714285714:968729948+29,0263157894737:-1267911962+30,0322580645161:-511949862+28,0294117647059:17716472+6,02777777777778:-29939919+26,02:1325267058+20,0243902439024:1303322618+28,0322580645161:-632733765+2992,03571428572:1972908098+30,0322580645161:-198039755+27,0285714285714:-2044189602+30,030303030303:415340412+30,0357142857143:-1436441258+24,0333333333333:1327961229+29,0263157894737:-530980585+3234,04000000001:-687311201+1588,03846153846:-1782745164+24,0192307692308:42695223+30,030303030303:-1492249348+28,0416666666667:836324060+1276,03125:756788559+30,027027027027:999510406+26,0357142857143:748617206+27,027027027027:774677951+20,04:-1119414461+24,0277777777778:973307869+24,0322580645161:877125554+18,0277777777778:-15325414+30,0322580645161:-150185058+21,037037037037:2139871543+14,027027027027:2000443320+24,0277777777778:1785111725+29,025641025641:-1793494821+1479,02777777778:-1736559841+27,025:-9345434+25,0243902439024:-1604749429+758,025:-968380869+11,0227272727273:147685181+-9,97560975609756:-1839070689+2,02083333333333:480815539+16,0238095238095";

				string[] strs = lastLine.Split('~');

				for (int i = 1; i < strs.Length; i++)
				{
					string[] splitstrs = strs[i].Split(':');

					string key = splitstrs[0];

					for (int j = 1; j < splitstrs.Length; j++)
					{
						string[] splitstrspls = splitstrs[j].Split('+');
						if (!stateTaskValues.ContainsKey(Convert.ToInt32(key)))
						{
							Dictionary<int, double> en = new Dictionary<int, double>();

							en.Add(Convert.ToInt32(splitstrspls[0]), Convert.ToDouble(splitstrspls[1]));
							stateTaskValues.Add(Convert.ToInt32(key), en);
						}
						else
						{
							stateTaskValues[Convert.ToInt32(key)].Add(Convert.ToInt32(splitstrspls[0]), Convert.ToDouble(splitstrspls[1]));
						}
					}
				}
			}
		}
		public override void InitializeGame()
		{
			
		}

		public override void FinalizeAgent()
		{

			if (learn)
			{
				File.Delete("weights.txt");

				using (System.IO.StreamWriter sw = System.IO.File.AppendText("weights.txt"))
				{

					foreach (KeyValuePair<int, Dictionary<int, double>> d in stateTaskValues)
					{
						sw.Write("~"); sw.Write(d.Key);
						foreach (KeyValuePair<int, double> dd in d.Value)
						{
							sw.Write(":" + (int)dd.Key + "+" + (double)dd.Value);
						}
					}
					sw.WriteLine();
				}
				System.Console.WriteLine();
				System.Console.WriteLine("SAVED!");
			}
		}
		/*public override void FinalizeGame(PlayState playState)
		{
			if (learn)
			{
				if (playState == SabberStoneCore.Enums.PlayState.WON) updateValues((1) * myhealth + (1.0 / gameLen));
				else if (playState == SabberStoneCore.Enums.PlayState.LOST) updateValues(-(5) * ophealth + (1.0 / gameLen));
			}
			gameLen = 0;
			gameCou++;
		}*/

		public override void FinalizeGame()
		{
			gameLen = 0;
			gameCou++;
		}


		public override PlayerTask GetMove(POGame.POGame poGame)
		{
			myhealth = poGame.CurrentPlayer.Hero.Health;
			ophealth = poGame.CurrentOpponent.Hero.Health;
			gameLen += 1;
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			Values values = new Values(this, poGame);

			int bestMove_ind = 0;
			double bestMove_val = 0;


			for (int i = 0; i < options.Count; i++)
			{
				double move_val = values.valueof(options[i]);

				if (move_val > bestMove_val)
				{
					bestMove_ind = i;
					bestMove_val = move_val;
				}
			}

			if (true)
			{
				if (!countTask.ContainsKey(GetStableHashCode(values.state)))
				{
					countTask.Add(GetStableHashCode(values.state), new List<int>());
					countTask[GetStableHashCode(values.state)].Add(0);
					countTask[GetStableHashCode(values.state)].Add(0);
				}

				countTask[GetStableHashCode(values.state)][0] = values.getHash(options[bestMove_ind]);
				countTask[GetStableHashCode(values.state)][1] += 1;
			}

			return options[bestMove_ind];
		}

		private void updateValues(double sig)
		{
			foreach (KeyValuePair<int, List<int>> e in countTask)
			{
				if (!stateTaskValues.ContainsKey(e.Key))
				{
					Dictionary<int, double> ptValue = new Dictionary<int, double>();
					ptValue.Add(e.Value[0], sig);
					for (int i = 0; i < e.Value[1]; i++) ptValue[e.Value[0]] += sig;
					stateTaskValues.Add(e.Key, ptValue);
				}
				else
				{
					if (stateTaskValues[e.Key].ContainsKey(e.Value[0]))
					{
						for (int i = 0; i < e.Value[1]; i++) stateTaskValues[e.Key][e.Value[0]] += sig;
					}
					else
					{
						stateTaskValues[e.Key].Add(e.Value[0], sig);
					}

				}
			}

			countTask = new Dictionary<int, List<int>>();
		}
	}
}
