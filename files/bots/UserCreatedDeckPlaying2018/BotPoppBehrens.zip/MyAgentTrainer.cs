﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;
using System.IO;
using System.Text.RegularExpressions;

namespace SabberStoneCoreAi.Agent.ExampleAgents
{
	/*
	class myAgent : AbstractAgent
	{
		private Random Rnd = new Random();
		public Dictionary<string, Dictionary<string, double>> brain = new Dictionary<string, Dictionary<string, double>>();
		public List<Tuple<string, string>> visited = new List<Tuple<string, string>>();
		double cnt = 0;
		int cntgames = 0;
		PlayerTask last = null;
		int cntdec = 0;

		public override void InitializeAgent() {
			//bereits angelerntes brain aus Binärdatei laden
			var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			var fi = new System.IO.FileInfo(@"brain.bin");
			using (var binaryFile = fi.OpenRead())
			{
				brain = (Dictionary<string, Dictionary<string, double>>)binaryFormatter.Deserialize(binaryFile);
			}
		}
		public override void FinalizeAgent()
		{
			cntdec+=1;
			Console.WriteLine("");
			Console.WriteLine("WK: " + (100 / (cntdec / 2 + 1)));
			Console.WriteLine("");
		}
		public override void FinalizeGame() { }

		public string createactionstring(PlayerTask entry)
		{
			string pattern = @"\[(\d+)\]";
			//return entry.PlayerTaskType.ToString();
			string stat = Regex.Replace(entry.FullPrint().Replace("[Player1]", "").Replace("[Player2]", "").Replace("PlayCardTask", "").Replace("HeroPowerTask", "").Replace("play", "").Replace("using", "").Replace("=>", "").Replace("MinionAttackTask", "").Replace(" ", ""), pattern, "");

			//Console.WriteLine(entry.FullPrint());
			return stat;
 				//string taskstring = removed(entry.FullPrint().Replace("[Player1]", "").Replace("[Player2]", ""));
		}


		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{

			if (poGame.Turn > 100)
				Console.WriteLine(poGame.Turn);
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			if (last == null)
				last = options[0];
			cnt++;
			PlayerTask move = options[0];

			string statString = createStatString(poGame);
			//Console.WriteLine(statString);


			if (!brain.ContainsKey(statString))
			{
				//wenn keine Aktion bekannt ist, dann verhält sich der Agent so, wie RandomAgentLateEnd
				List<PlayerTask> validTasks = new List<PlayerTask>();
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType != PlayerTaskType.END_TURN)
						validTasks.Add(task);
				}
				if (validTasks.Count > 0)
					move = validTasks[Rnd.Next(validTasks.Count)];
				else
					move = options[0];
			}
			else
			{
				double bestV = Double.MinValue;
				PlayerTask bestmove = null;
				foreach (PlayerTask entry in options)
				{
					string taskstring = createactionstring(entry);
					//Console.WriteLine(taskstring);
					if (brain[statString].ContainsKey(taskstring))
					{
						if (brain[statString][taskstring] > bestV && entry.PlayerTaskType != PlayerTaskType.END_TURN)
						{
							//Console.WriteLine(taskstring);
							bestV = brain[statString][taskstring];
							bestmove = entry;
						}
					}
				}
				if (bestmove == null)
				{
					List<PlayerTask> validTasks = new List<PlayerTask>();
					foreach (PlayerTask task in options)
					{
						if (task.PlayerTaskType != PlayerTaskType.END_TURN)
							validTasks.Add(task);
					}
					if (validTasks.Count > 0)
						move = validTasks[Rnd.Next(validTasks.Count)];
					else
						move = options[0];
				}
				else
				{
					int wk = 300 / (cntdec / 2 + 1);
					int zufall = Rnd.Next(0, 100);
					if (false)
					{
						List<PlayerTask> validTasks = new List<PlayerTask>();
						foreach (PlayerTask task in options)
						{
							if (task.PlayerTaskType != PlayerTaskType.END_TURN)
								validTasks.Add(task);
						}
						if (validTasks.Count > 0)
							move = validTasks[Rnd.Next(validTasks.Count)];
						else
							move = options[0];
					}
					else
					{
						move = bestmove;
					}
				}

			}

			visited.Add(new Tuple<string, string>(statString, createactionstring(move)));
			last = move;

			return move;

		}


		public string createStatString(SabberStoneCoreAi.POGame.POGame poGame)
		{

			List<SabberStoneCore.Model.PlayHistoryEntry> bla2 = poGame.CurrentOpponent.PlayHistory;
			int cnthist = 0;
			string test2 = "";
			foreach (SabberStoneCore.Model.PlayHistoryEntry entry in bla2)
			{
				test2 += nametonumber(entry.SourceCard.Type.ToString());
				cnthist++;
				if (cnthist == 3) break;
			}

			List<SabberStoneCore.Model.PlayHistoryEntry> bla = poGame.CurrentPlayer.PlayHistory;
			cnthist = 0;
			string test = "";


				foreach (SabberStoneCore.Model.PlayHistoryEntry entry in bla)
				{
					test += nametonumber(entry.SourceCard.Type.ToString());
					cnthist++;
					if (cnthist == 4) break;
				}
			
			//Console.WriteLine(poGame.CurrentPlayer.Id);
			return test2;
		}

		public string nametonumber(string name)
		{
			if (name == "INVALID")
				return "0";
			if (name == "GAME")
				return "1";
			if (name == "PLAYER")
				return "2";
			if (name == "HERO")
				return "3";
			if (name == "MINION")
				return "4";
			if (name == "SPELL")
				return "5";
			if (name == "ENCHANTMENT")
				return "6";
			if (name == "WEAPON")
				return "7";
			if (name == "ITEM")
				return "8";
			if (name == "TOKEN")
				return "9";
			if (name == "HERO_POWER")
				return "A";

			return "B";
		}

		public override void FinalizeGame(PlayState playState)
		{
			//Console.WriteLine(playState);
			foreach (Tuple<string, string> entry in visited)
			{
				if (brain.ContainsKey(entry.Item1))
				{
					if (!brain[entry.Item1].ContainsKey(entry.Item2))
					{
						brain[entry.Item1].Add(entry.Item2, 0);
					}
					if (playState == PlayState.LOST)
					{
						brain[entry.Item1][entry.Item2] += -1.0;//(-1.1 / (3 * cnt)); //-1.1
					}
					if (playState == PlayState.WON)
					{
						brain[entry.Item1][entry.Item2] +=0.5;//(0.1 / (3 * cnt)); //0.1
					}
				}
				else
				{
					Dictionary<string, double> newdict = new Dictionary<string, double>();
					newdict.Add(entry.Item2, 0.0);
					brain.Add(entry.Item1, newdict);
					if (playState == PlayState.LOST)
					{
						brain[entry.Item1][entry.Item2] += -1.0;//(-1.1 / (3 * cnt));
					}
					if (playState == PlayState.WON)
					{
						brain[entry.Item1][entry.Item2] +=0.5;//(0.1 / (3 * cnt));
					}
				}
			}
			cntgames++;
			if (cntgames > 10000)
			{
				var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

				var fi = new System.IO.FileInfo(@"brain.bin");

				using (var binaryFile = fi.Create())
				{
					binaryFormatter.Serialize(binaryFile, brain);
					binaryFile.Flush();
				}
				cntgames = 0;
				Console.WriteLine("saved");
			}
			//Console.WriteLine(brain[""].Count);
		}


		public override void InitializeGame()
		{
			visited = new List<Tuple<string, string>>();
			cnt = 0;
		}


	}*/
}
