- put brain.bin in the main folder of the project

GameConfig gameConfig = new GameConfig
{
   StartPlayer = 1,
   Player1Deck = Meta.Decks.MidrangeJadeShaman,
   Player2Deck = Meta.Decks.MidrangeJadeShaman,
   Player1HeroClass = CardClass.SHAMAN,
   Player2HeroClass = CardClass.SHAMAN,
   FillDecks = true,
   Logging = false
};
