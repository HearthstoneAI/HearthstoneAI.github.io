﻿using System;
using System.Collections.Generic;
using System.Linq;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Agent;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;
using SabberStoneCoreAi.Score;
using System.IO;
using System.Text.RegularExpressions;
using SabberStoneCoreAi.Meta;
using SabberStoneCore;


// Developed by Martin Popp and Johannes Behrens
namespace SabberStoneCoreAi.Agent
{
	class MartinJohannes : AbstractAgent
	{
		public MartinJohannes(){
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}
		

		private Random Rnd = new Random();
		public Dictionary<string, Dictionary<string, double>> brain = new Dictionary<string, Dictionary<string, double>>(); //brain beinhaltet Werte für viele Status/Aktions Kombinationen

		public override void InitializeAgent()
		{
			//bereits angelerntes brain aus Binärdatei laden
			var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			var fi = new System.IO.FileInfo(@"brain.bin");
			using (var binaryFile = fi.OpenRead())
			{
				brain = (Dictionary<string, Dictionary<string, double>>)binaryFormatter.Deserialize(binaryFile);
			}
		}


		public string createactionstring(PlayerTask entry)
		{
			//Aktion wird über String identifiziert, hierfür überflüssige Informationen entfernen
			string pattern = @"\[(\d+)\]";
			string stat = Regex.Replace(entry.FullPrint().Replace("[Player1]", "").Replace("[Player2]", "").Replace("PlayCardTask", "").Replace("HeroPowerTask", "").Replace("play", "").Replace("using", "").Replace("=>", "").Replace("MinionAttackTask", "").Replace(" ", ""), pattern, "");
			return stat;
		}

		public string createStatString(SabberStoneCoreAi.POGame.POGame poGame)
		{
			//Status setzt sich aus den letzten 3 Zügen (Type des Tasks) des Gegners zusammen
			List<SabberStoneCore.Model.PlayHistoryEntry> historyOpponent = poGame.CurrentOpponent.PlayHistory;
			int cnthist = 0;
			string historyStringOpponent = "";
			foreach (SabberStoneCore.Model.PlayHistoryEntry entry in historyOpponent)
			{
				historyStringOpponent += nametonumber(entry.SourceCard.Type.ToString());
				cnthist++;
				if (cnthist == 3) break;
			}

			return historyStringOpponent;
		}

		public string nametonumber(string name)
		{
			if (name == "INVALID")
				return "0";
			if (name == "GAME")
				return "1";
			if (name == "PLAYER")
				return "2";
			if (name == "HERO")
				return "3";
			if (name == "MINION")
				return "4";
			if (name == "SPELL")
				return "5";
			if (name == "ENCHANTMENT")
				return "6";
			if (name == "WEAPON")
				return "7";
			if (name == "ITEM")
				return "8";
			if (name == "TOKEN")
				return "9";
			if (name == "HERO_POWER")
				return "A";

			return "B";
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			PlayerTask move = options[0];

			string statString = createStatString(poGame);

			if (!brain.ContainsKey(statString))
			{
				//wenn keine Aktion bekannt ist, dann verhält sich der Agent so, wie RandomAgentLateEnd
				List<PlayerTask> validTasks = new List<PlayerTask>();
				foreach (PlayerTask task in options)
				{
					if (task.PlayerTaskType != PlayerTaskType.END_TURN)
						validTasks.Add(task);
				}
				if (validTasks.Count > 0)
					move = validTasks[Rnd.Next(validTasks.Count)];
				else
					move = options[0];
			}
			else
			{
				double bestV = Double.MinValue;
				PlayerTask bestmove = null;
				foreach (PlayerTask entry in options)
				{
					string taskstring = createactionstring(entry);
					//Console.WriteLine(taskstring);
					if (brain[statString].ContainsKey(taskstring))
					{
						if (brain[statString][taskstring] > bestV && entry.PlayerTaskType != PlayerTaskType.END_TURN)
						{
							//wähle beste bekannte Aktion aus
							bestV = brain[statString][taskstring];
							bestmove = entry;
						}
					}
				}
				if (bestmove == null)
				{
					//Wenn er nichts findet, dann agiere so, wie RandomAgentLAteEnd
					List<PlayerTask> validTasks = new List<PlayerTask>();
					foreach (PlayerTask task in options)
					{
						if (task.PlayerTaskType != PlayerTaskType.END_TURN)
							validTasks.Add(task);
					}
					if(validTasks.Count>0)
						move = validTasks[Rnd.Next(validTasks.Count)];
					else
						move = options[0];
				}
				else
				{
					move = bestmove;
				}
			}
			return move;
		}
		public override void InitializeGame(){}
		public override void FinalizeAgent() { }
		public override void FinalizeGame() { }

	}
}
