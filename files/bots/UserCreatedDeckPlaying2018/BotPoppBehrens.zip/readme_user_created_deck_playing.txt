- use the following GameConfig for using bots of the UserCreatedDeckPlayingDeck

GameConfig gameConfig = new GameConfig
{
	StartPlayer = 1,
	Player1HeroClass = player1.hero,
	Player2HeroClass = player2.hero,
	Player1Deck = player1.deck,
	Player2Deck = player2.deck,
};