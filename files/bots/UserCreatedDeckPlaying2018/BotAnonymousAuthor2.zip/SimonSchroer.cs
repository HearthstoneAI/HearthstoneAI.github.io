﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Meta;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;


// Developed by Anonymous Author
namespace SabberStoneCoreAi.Agent
{
	struct StateValues
	{
		public int Mana;
		public int EnemyHealth;
		public int PlayerHealth;
		public int PlayerAttack;
		public int EnemyAttack;
		public int PlayerDefense;
		public int EnemyDefense;
	}

	class BotAnonymousAuthor : AbstractAgent
	{

		public BotAnonymousAuthor(){
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}

		private Random Rnd = new Random();
		private Dictionary<PlayerTask, double> actionValues;
		private Dictionary<PlayerTask, int> countActionVisited;
		public static int MaxIteration = 0;

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		private double calculateReturnRandomly(POGame.POGame poGame)
		{
			POGame.POGame currentState = poGame;
			PlayerTask option = null;
			List<PlayerTask> options = new List<PlayerTask>();
			int iteration = 0;
			do
			{
				iteration++;
				if (iteration > MaxIteration)
					MaxIteration = iteration;
				options = currentState.CurrentPlayer.Options();
				//Remove end turn
				foreach (PlayerTask opt in options)
				{
					if (opt.PlayerTaskType == PlayerTaskType.END_TURN)
					{
						options.Remove(opt);
						break;
					}
				}
				if (options.Count == 0)
					return getReturnValue(ConstructState(currentState));
				else
					option = options[Rnd.Next(options.Count)];
				List<PlayerTask> simulateStates = new List<PlayerTask>();
				simulateStates.Add(option);
				Dictionary<PlayerTask, POGame.POGame> results = new Dictionary<PlayerTask, POGame.POGame>();
				try
				{
					results = currentState.Simulate(simulateStates);
				} catch (Exception ex)
				{
					return getReturnValue(ConstructState(currentState));
				}
				currentState = results[option];
				if (currentState.NextStep == SabberStoneCore.Enums.Step.FINAL_GAMEOVER)
					return getReturnValue(ConstructState(currentState));
			} while (option.PlayerTaskType != PlayerTaskType.END_TURN);
			return getReturnValue(ConstructState(currentState));
		}

		private double getReturnValue(StateValues newState)
		{
			double sum = 0.0;
			double manaFactor = 1.0, enemyHealthFactor = -1.0, playerHealthFactor = 1.0, playerAttackFactor = 1.0, playerDefenseFactor = 1.0, enemyAttackFactor = -1.0, enemyDefenseFactor = -1.0;

			//Calculate the scores
			sum += manaFactor * newState.Mana;
			sum += enemyHealthFactor * newState.EnemyHealth;
			sum += playerHealthFactor * newState.PlayerHealth;
			sum += playerAttackFactor * newState.PlayerAttack;
			sum += playerDefenseFactor * newState.PlayerDefense;
			sum += enemyAttackFactor * newState.EnemyAttack;
			sum += enemyDefenseFactor * newState.EnemyDefense;
			return sum;
		}

		private StateValues ConstructState(POGame.POGame poGame)
		{
			//Construct current state
			StateValues stateValues = new StateValues();
			stateValues.Mana = poGame.CurrentPlayer.RemainingMana;
			stateValues.PlayerHealth = poGame.CurrentPlayer.Hero.Health;
			stateValues.EnemyHealth = poGame.CurrentOpponent.Hero.Health;
			int sumPlayerDamage = 0, sumEnemyDamage = 0, sumPlayerDefense = 0, sumEnemyDefense = 0;
			foreach (SabberStoneCore.Model.Entities.Minion minion in poGame.Minions)
			{
				if (minion.Controller.Name == poGame.CurrentPlayer.Name)
				{
					sumPlayerDamage += minion.Damage;
					sumPlayerDefense += minion.Health;
				}
				else if (minion.Controller.Name == poGame.CurrentOpponent.Name)
				{
					sumEnemyDamage += minion.Damage;
					sumEnemyDefense += minion.Health;
				}
			}
			stateValues.PlayerAttack = sumPlayerDamage;
			stateValues.PlayerDefense = sumPlayerDefense;
			stateValues.EnemyAttack = sumEnemyDamage;
			stateValues.EnemyDefense = sumEnemyDefense;

			return stateValues;
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			double epsilon = 0.1;
			PlayerTask turn = null;
			double bestValue = Double.MinValue;
			List<PlayerTask> options = poGame.CurrentPlayer.Options();
			PlayerTask endTurn = null;
			//Remove the end turn task
			foreach (PlayerTask option in options)
			{
				if (option.PlayerTaskType == PlayerTaskType.END_TURN)
				{
					endTurn = option;
					options.Remove(option);
					break;
				}
			}
			if (options.Count == 0)
				return endTurn;
			//Process turn
			Dictionary<PlayerTask, POGame.POGame> results = poGame.Simulate(options);
			foreach (PlayerTask key in options)
			{
				//Update values
				if (actionValues.ContainsKey(key))
				{
					countActionVisited[key]++;
					actionValues[key] = actionValues[key] * (countActionVisited[key] - 1) / countActionVisited[key] + calculateReturnRandomly(results[key]) / countActionVisited[key];
				}
				else
				{
					countActionVisited.Add(key, 1);
					actionValues.Add(key, calculateReturnRandomly(results[key]));
				}
			}
			//Pick option with best value (Exploitation)
			foreach (PlayerTask option in options)
			{
				if (actionValues[option] > bestValue)
				{
					turn = option;
					bestValue = actionValues[option];
				}
			}
			//In case no option is yet registered, explore
			if (turn == null)
				turn = options[Rnd.Next(options.Count)];
			return turn;
		}

		public override void InitializeAgent()
		{
			Rnd = new Random();
			actionValues = new Dictionary<PlayerTask, double>();
			countActionVisited = new Dictionary<PlayerTask, int>();
		}

		public override void InitializeGame()
		{
		}
	}
}
