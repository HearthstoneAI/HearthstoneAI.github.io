﻿using System;
using System.Collections.Generic;
using System.Text;
using SabberStoneCore.Tasks;
using SabberStoneCoreAi.Agent;
using SabberStoneCoreAi.POGame;
using SabberStoneCoreAi.Meta;
using SabberStoneCore;
using SabberStoneCore.Enums;
using SabberStoneCore.Tasks.PlayerTasks;


// Developed by Christian Wustrau
namespace SabberStoneCoreAi.Agent
{
	class BotChristianWustrau : AbstractAgent
	{
		private Random Rnd = new Random();

		public BotChristianWustrau(){
			deck = Decks.MidrangeJadeShaman;
			hero = CardClass.SHAMAN;
		}
		

		public override void FinalizeAgent()
		{
		}

		public override void FinalizeGame()
		{
		}

		public override PlayerTask GetMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			//Console.WriteLine("Beginne Auszurollen");
			PlayerTask move = GetBestMove(poGame);
			if (move == null)
			{
				move = poGame.CurrentPlayer.Options()[0];
			}
			//Console.WriteLine("Spiele");
			return move;
		}

		public PlayerTask GetBestMove(SabberStoneCoreAi.POGame.POGame poGame)
		{
			PlayerTask BestMove = null;
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> SimulationData = SimulateGame(poGame);
			BestMove = EvaluateSimulation(SimulationData, poGame);
			return BestMove;
		}

		public Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> SimulateGame(SabberStoneCoreAi.POGame.POGame poGame)
		{
			Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame> Simulation = poGame.Simulate(poGame.CurrentPlayer.Options());
			return Simulation;
		}

		public PlayerTask EvaluateSimulation(Dictionary<PlayerTask, SabberStoneCoreAi.POGame.POGame>  SimulationData, SabberStoneCoreAi.POGame.POGame poGame)
		{
			PlayerTask BestTask = null;
			double BestTempo = CalculateTempo(poGame);
			foreach (KeyValuePair<PlayerTask, SabberStoneCoreAi.POGame.POGame> task in SimulationData)
			{
				if (task.Key.PlayerTaskType == SabberStoneCore.Tasks.PlayerTasks.PlayerTaskType.END_TURN)
				{
					continue;
				}
				double Tempo = CalculateTempo(task.Value);
				if ( Tempo > BestTempo)
				{
					BestTempo = Tempo;
					BestTask = task.Key;
				}
			}
			return BestTask;
		}

		public double CalculateTempo(SabberStoneCoreAi.POGame.POGame poGame)
		{
			if(poGame == null)
			{
				return -999;
			}
			if(poGame.CurrentOpponent.Hero.Health == 0)
			{
				return 999;
			}
			if (poGame.CurrentPlayer.Hero.Health == 0)
			{
				return -999;
			}

			double Alpha = 0.2; double Beta = 0.6; double Gamma = 0; double Delta = 0.7; double Epsilon = 0; double Zeta = 0;
			double Theta = 0.3; double Iota = 0.1;

			if (poGame.CurrentPlayer.HeroClass == SabberStoneCore.Enums.CardClass.MAGE)
			{
				Alpha = 0.4; Beta = 0.2; Gamma = 0.1; Delta = 0.35; Epsilon = 0.2; Zeta = 0.2; Theta = 0.35; Iota = 0;
			} else if (poGame.CurrentPlayer.HeroClass == SabberStoneCore.Enums.CardClass.SHAMAN)
			{
				Alpha = 0.4; Beta = 0.2; Gamma = 0; Delta = 0.35; Epsilon = 0.1; Zeta = 0; Theta = 0.35; Iota = 0.1;
			}else if (poGame.CurrentPlayer.HeroClass == SabberStoneCore.Enums.CardClass.WARRIOR &&
				      poGame.CurrentOpponent.HeroClass == SabberStoneCore.Enums.CardClass.WARRIOR)
			{
				Alpha = 0.4; Beta = 0.2; Gamma = 0; Delta = 0.35; Epsilon = 0; Zeta = 0; Theta = 0.35; Iota = 0.05;
			}

			double OpponentBoardValue = 0;
			for (int i = 0; i < poGame.CurrentOpponent.BoardZone.Count; ++i)
			{
				OpponentBoardValue += Alpha * poGame.CurrentOpponent.BoardZone[i].AttackDamage;
				OpponentBoardValue += Alpha * poGame.CurrentOpponent.BoardZone[i].Health;
				if(poGame.CurrentOpponent.Hero.Weapon != null)
				{
					OpponentBoardValue += 0 * poGame.CurrentOpponent.Hero.Weapon.AttackDamage;
				}
			}
			double OpponentTempo = Beta * (poGame.CurrentOpponent.Hero.Health + poGame.CurrentOpponent.Hero.Armor ) + OpponentBoardValue + Gamma * poGame.CurrentOpponent.HandZone.Count;

			double PlayerBoardValue = 0;
			for (int i = 0; i < poGame.CurrentPlayer.BoardZone.Count; ++i)
			{
				PlayerBoardValue += Delta * poGame.CurrentPlayer.BoardZone[i].AttackDamage;
				PlayerBoardValue += Theta * poGame.CurrentPlayer.BoardZone[i].Health;
				if (poGame.CurrentPlayer.Hero.Weapon != null)
				{
					PlayerBoardValue += Iota * poGame.CurrentPlayer.Hero.Weapon.AttackDamage;
				}
			}
			double PlayerTempo = Epsilon * (poGame.CurrentPlayer.Hero.Health + poGame.CurrentPlayer.Hero.Armor) + PlayerBoardValue + Zeta * poGame.CurrentPlayer.HandZone.Count; ;

			double Tempo = PlayerTempo - OpponentTempo;

			return Tempo;
		}

		public override void InitializeAgent()
		{
		}

		public override void InitializeGame()
		{
		}
	}
}
